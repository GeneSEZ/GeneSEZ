package org.genesez.example.java.BankTutorial.Server.businessLogic;

/* 
 *	Do not place import/include statements above this comment, just below. 
 * 	@FILE-ID : (_16_0_129203bc_1271098798359_533997_578) 
 */

/**
 * A BankSelectionException is thrown if a problem occurs with the selection of a bank
 */

public class BankSelectionException extends RuntimeException {
	
	/* PROTECTED REGION ID(java.class.own.code.implementation._16_0_129203bc_1271098798359_533997_578) ENABLED START */
	// TODO: put your own implementation code here
	/* PROTECTED REGION END */
}
