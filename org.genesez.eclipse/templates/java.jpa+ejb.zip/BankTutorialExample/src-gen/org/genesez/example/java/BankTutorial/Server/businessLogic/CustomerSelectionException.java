package org.genesez.example.java.BankTutorial.Server.businessLogic;

/* 
 *	Do not place import/include statements above this comment, just below. 
 * 	@FILE-ID : (_16_0_129203bc_1271098808703_21163_602) 
 */

/**
 * A CustomerSelectionException is thrown if a problem occurs with the selection of a customer
 */

public class CustomerSelectionException extends RuntimeException {
	
	/* PROTECTED REGION ID(java.class.own.code.implementation._16_0_129203bc_1271098808703_21163_602) ENABLED START */
	// TODO: put your own implementation code here
	/* PROTECTED REGION END */
}
