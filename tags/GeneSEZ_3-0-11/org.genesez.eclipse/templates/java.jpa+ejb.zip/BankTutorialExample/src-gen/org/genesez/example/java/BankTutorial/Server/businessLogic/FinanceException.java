package org.genesez.example.java.BankTutorial.Server.businessLogic;

/* 
 *	Do not place import/include statements above this comment, just below. 
 * 	@FILE-ID : (_16_0_129203bc_1271186256453_959902_717) 
 */

/**
 * A FinanceException is thrown if a problem occurs during an account operation
 */

public class FinanceException extends RuntimeException {
	
	/* PROTECTED REGION ID(java.class.own.code.implementation._16_0_129203bc_1271186256453_959902_717) ENABLED START */
	// TODO: put your own implementation code here
	/* PROTECTED REGION END */
}
