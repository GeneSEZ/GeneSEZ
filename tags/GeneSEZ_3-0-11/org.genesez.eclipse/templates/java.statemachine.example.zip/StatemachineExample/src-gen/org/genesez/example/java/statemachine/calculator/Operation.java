package org.genesez.example.java.statemachine.calculator;

/* 
 *	Do not place import/include statements above this comment, just below. 
 * 	@FILE-ID : (_15_5_1_6340215_1232981000430_912204_1054) 
 */

/**
 * Please describe the responsibility of your class in your modeling tool.
 */
public enum Operation {
	
	ADD, SUB, MUL, DIV, POW, NOP;
	
	/* PROTECTED REGION ID(java.enumeration.own.code.implementation._15_5_1_6340215_1232981000430_912204_1054) ENABLED START */
	// TODO: put your own implementation code here
	/* PROTECTED REGION END */
}
