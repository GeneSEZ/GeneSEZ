package org.openarchitectureware.util.stdlib;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent2;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

/**
 * Prints a message to the log.
 */
public class MessageLogger extends AbstractWorkflowComponent2 {
	private static final Log LOG = LogFactory.getLog(MessageLogger.class);

	private static final String COMPONENT_NAME = "Message Logger";

	private String message;

	/**
	 * Sets the message.
	 * 
	 * @param msg
	 *            the message
	 */
	public void setMessage(String msg) {
		message = msg;
	}

	@Override
	protected void checkConfigurationInternal(Issues issues) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void invokeInternal(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
		LOG.info(message);
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getComponentName()
	 */
	public String getComponentName() {
		return COMPONENT_NAME;
	}
}
