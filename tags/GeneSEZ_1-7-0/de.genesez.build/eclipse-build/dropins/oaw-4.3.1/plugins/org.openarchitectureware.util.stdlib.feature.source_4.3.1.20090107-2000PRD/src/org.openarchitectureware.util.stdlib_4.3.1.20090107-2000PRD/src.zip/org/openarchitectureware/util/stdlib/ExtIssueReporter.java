package org.openarchitectureware.util.stdlib;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.WorkflowInterruptedException;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent2;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

/**
 * Java helper class for Stdlib extension <tt>org::openarchitectureware::util::stdlib::issues</tt>.
 */
public class ExtIssueReporter extends AbstractWorkflowComponent2 {
	private static final String ERROR_CONFIGURE = "You must run the org.openarchitectureware.util.stdlib.ExtIssueReporter component before using the issue reporting utilities.";

	private static final String COMPONENT_NAME = "External Issue Reporter";

	static ThreadLocal<Issues> tl = new ThreadLocal<Issues>();

	@Override
	protected void checkConfigurationInternal(Issues arg0) {
	}

	@Override
	protected void invokeInternal(WorkflowContext ctx, ProgressMonitor mon, Issues issues) {
		tl.set(issues);
	}

	/**
	 * @see org.openarchitectureware.workflow.lib.AbstractWorkflowComponent#getLogMessage()
	 */
	@Override
	public String getLogMessage() {
		return "setting up issue logging from within .ext and .xpt files";
	}

	/**
	 * Reports an error.
	 * 
	 * @param message
	 *            the error message
	 * @return the passed in error message
	 */
	public static String reportError(String message) {
		getIssues().addError(message);
		return message;
	}

	private static Issues getIssues() {
		Issues issues = ((Issues) tl.get());
		if (issues == null) {
			throw new WorkflowInterruptedException(ERROR_CONFIGURE);
		}
		return issues;
	}

	/**
	 * Reports a warning.
	 * 
	 * @param message
	 *            the warning message
	 * @return the passed in warning message
	 */
	public static String reportWarning(String message) {
		getIssues().addWarning(message);
		return message;
	}

	/**
	 * Reports an error.
	 * 
	 * @param qfn
	 *            a qualified filename
	 * @param message
	 *            the error message
	 * @return the passed in error message
	 */
	public static String reportError(String qfn, String message) {
		if (tl.get() == null) {
			System.err
					.println(ERROR_CONFIGURE);
		}
		getIssues().addError("[" + qfn + "] " + message);
		return message;
	}

	/**
	 * Reports a warning.
	 * 
	 * @param qfn
	 *            a qualified filename
	 * @param message
	 *            the warning message
	 * @return the passed in warning message
	 */
	public static String reportWarning(String qfn, String message) {
		if (tl.get() == null) {
			System.err
					.println(ERROR_CONFIGURE);
		}
		getIssues().addWarning("[" + qfn + "] " + message);
		return message;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getComponentName()
	 */
	public String getComponentName() {
		return COMPONENT_NAME;
	}
}
