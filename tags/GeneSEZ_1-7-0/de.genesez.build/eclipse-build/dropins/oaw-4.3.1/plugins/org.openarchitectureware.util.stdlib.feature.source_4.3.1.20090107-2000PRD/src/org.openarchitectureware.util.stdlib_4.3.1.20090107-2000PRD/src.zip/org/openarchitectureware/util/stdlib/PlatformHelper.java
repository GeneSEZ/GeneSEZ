package org.openarchitectureware.util.stdlib;

import org.eclipse.mwe.emf.StandaloneSetup;

public class PlatformHelper {

	public static String getPlatformRootPath(Object ctx) {
		return StandaloneSetup.getPlatformRootPath();
	}
	
}
