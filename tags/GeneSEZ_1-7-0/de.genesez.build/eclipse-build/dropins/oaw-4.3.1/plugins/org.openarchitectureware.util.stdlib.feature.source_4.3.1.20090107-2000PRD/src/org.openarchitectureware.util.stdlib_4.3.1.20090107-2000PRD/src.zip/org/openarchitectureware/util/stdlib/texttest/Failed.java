package org.openarchitectureware.util.stdlib.texttest;

public class Failed extends RuntimeException {

	public Failed() {
		super();
	}
	
	public Failed(String msg) {
		super(msg);
	}
	
	
	
}
