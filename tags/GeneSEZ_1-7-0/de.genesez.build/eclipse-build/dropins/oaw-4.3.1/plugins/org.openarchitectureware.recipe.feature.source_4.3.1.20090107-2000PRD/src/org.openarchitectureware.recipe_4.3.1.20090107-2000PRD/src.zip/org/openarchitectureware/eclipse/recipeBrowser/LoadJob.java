/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Markus Voelter and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Markus Voelter - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.eclipse.recipeBrowser;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.progress.IWorkbenchSiteProgressService;
import org.openarchitectureware.recipe.core.EvalTrigger;
import org.openarchitectureware.recipe.eval.EvaluationContext;
import org.openarchitectureware.recipe.io.CannotLoadChecksException;
import org.openarchitectureware.recipe.io.CheckRegistry;

public class LoadJob extends Job {
	
	private TreeViewer treeViewer;
	private boolean evaluate;
	private IWorkbenchSiteProgressService siteService;
	
	public LoadJob( TreeViewer treeViewer, IWorkbenchSiteProgressService ss, boolean evaluate ) {
		super("Loading Recipe File");
		this.treeViewer = treeViewer;
		this.evaluate = evaluate;
		this.siteService = ss;
	}
	
	protected IStatus run(IProgressMonitor monitor) {
		monitor.beginTask( "Evaluating Recipes", IProgressMonitor.UNKNOWN );
		try {
			CheckRegistry.loadFromFile();
		} catch (final CannotLoadChecksException e) {
			Display.getDefault().asyncExec( new Runnable() {
				public void run() {
					MessageDialog.openError( null, "Error loading recipe file", "Reason: "+e.getMessage() );
				}
			});
		}
		Display.getDefault().asyncExec( new Runnable() {
			public void run() {
				treeViewer.setInput( CheckRegistry.getChecks() );
				siteService.warnOfContentChange();
			}
		});
		monitor.done();
		if ( evaluate ) {
			EvaluationContext ctx = new EvaluationContext();
			ctx.setEvaluateAll( true );
			ctx.setTrigger( EvalTrigger.ON_REQUEST );
			siteService.schedule(new EvalJob(CheckRegistry.getChecks(), treeViewer, siteService, ctx ), 0 , true );
		}
		return Status.OK_STATUS;
	}

}

