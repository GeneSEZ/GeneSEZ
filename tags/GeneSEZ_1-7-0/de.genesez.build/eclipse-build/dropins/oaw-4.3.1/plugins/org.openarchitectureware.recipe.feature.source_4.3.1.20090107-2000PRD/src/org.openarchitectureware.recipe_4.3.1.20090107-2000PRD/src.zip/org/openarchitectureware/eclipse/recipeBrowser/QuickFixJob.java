/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Markus Voelter and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Markus Voelter - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.eclipse.recipeBrowser;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.ui.PlatformUI;
import org.openarchitectureware.eclipse.recipeBrowser.providers.QuickFixerProvider;
import org.openarchitectureware.recipe.core.Check;
import org.openarchitectureware.recipe.core.CompositeCheck;
import org.openarchitectureware.recipe.core.EvalStatus;
import org.openarchitectureware.recipe.eclipseChecks.quickFixers.QuickFixer;
import org.openarchitectureware.recipe.eval.CheckEvaluationListener;

public class QuickFixJob extends Job implements CheckEvaluationListener {

	private IProgressMonitor monitor;
	private Check check = null;
	private TreeViewer treeViewer;

	public QuickFixJob(TreeViewer v) {
		super("Evaluating Recipes");
		this.treeViewer = v;
	}

	public QuickFixJob(Check check, TreeViewer v) {
		super("Evaluating Recipes");
		this.check = check;
		this.treeViewer = v;
	}

	protected IStatus run(IProgressMonitor monitor) {
		IStatus result = Status.OK_STATUS;

		// due to the way checks are structured, we only fix composite checks, no
		// atomic ones.

		CompositeCheck cc = (CompositeCheck) check;

		QuickFixerProvider qfp = new QuickFixerProvider();
				
		for (Check c : cc.getChildren())
			if (c.getStatus() == EvalStatus.FAILED)
				if (((QuickFixer) (qfp.getQuickFixer(c))).quickFixAndEvaluate().equals(
						Status.CANCEL_STATUS))
					result = Status.CANCEL_STATUS;
		
		
		
		
		/* Refreshing explicitly the recipe view to avoid the long delay (this a bad MVC practice) TODO: change it when watcher will be more synchronized to the workspace*/
		
		PlatformUI.getWorkbench().getDisplay().asyncExec(new Runnable(){

			public void run() {
				treeViewer.refresh();
				
			}
			
		});
		


		return result;

	}

	public void evaluated(Check check, boolean evaluated) {
		monitor.worked(check.getCheckCount());
	}

}
