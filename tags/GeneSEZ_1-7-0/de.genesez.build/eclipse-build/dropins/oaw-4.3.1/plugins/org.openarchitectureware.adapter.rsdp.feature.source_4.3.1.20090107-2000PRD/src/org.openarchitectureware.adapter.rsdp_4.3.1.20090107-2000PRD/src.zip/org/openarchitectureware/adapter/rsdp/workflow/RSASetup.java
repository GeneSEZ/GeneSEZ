package org.openarchitectureware.adapter.rsdp.workflow;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openarchitectureware.emf.Mapping;
import org.openarchitectureware.uml2.Setup;
import org.openarchitectureware.workflow.WorkflowComponent;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.ast.parser.Location;
import org.openarchitectureware.workflow.container.CompositeComponent;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class RSASetup extends Setup implements WorkflowComponent {
	private static final String COMPONENT_NAME = "RSA Setup";

	private CompositeComponent container;

	private List<UmlExtensionProject> extensionProjects = new ArrayList<UmlExtensionProject>();

	private List<PathMapEntry> pathMapEntries = new ArrayList<PathMapEntry>();

	private static Log logger = LogFactory.getLog(RSASetup.class);

	private Location location = null;

	/**
	 * Register a plugin containing uml2 / rsa profiles.
	 * 
	 * @param plugin
	 *            plugin to register
	 */
	public void addUmlExtensionProject(UmlExtensionProject plugin) {
		extensionProjects.add(plugin);
	}

	/**
	 * Adds a path map entry.
	 * 
	 * @param pathMapEntry
	 *            the path map entry.
	 */
	public void addPathMapEntry(PathMapEntry pathMapEntry) {
		pathMapEntries.add(pathMapEntry);
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#checkConfiguration(org.openarchitectureware.workflow.issues.Issues)
	 */
	public void checkConfiguration(Issues issues) {
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getContainer()
	 */
	public CompositeComponent getContainer() {
		return container;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#invoke(org.openarchitectureware.workflow.WorkflowContext,
	 *      org.openarchitectureware.workflow.monitor.ProgressMonitor,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	public void invoke(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
	}

	/**
	 * Registers all necessary resources.
	 * 
	 * @param b
	 *            Initialization occurs only if <code>true</code> is passed.
	 */
	public void setInit(boolean b) {
		super.setStandardUML2Setup(b);

		// Add RSA/RSM specific uml file extensions
		addExtensionMap(new Mapping("emx", "org.eclipse.uml2.uml.resource.UMLResource"));
		addExtensionMap(new Mapping("epx", "org.eclipse.uml2.uml.resource.UMLResource"));

		// Add plugins containing profiles or type libraries
		addUriMaps(extensionProjects);

		// Add pathmap entry
		addUriMaps(pathMapEntries);
	}

	private void addUriMaps(List<? extends AbstractURIMapEntry> mapEntries) {
		for (Iterator<? extends AbstractURIMapEntry> ipp = mapEntries.iterator(); ipp.hasNext();) {
			AbstractURIMapEntry plugin = ipp.next();
			File location = new File(plugin.getPath());

			if (location.exists() == false || location.isDirectory() == false) {
				logger.error("Location " + location + " doesn't exist or is not a valid directory");
			}
			else {
				URI locationURI = location.toURI();
				String mappedURI = plugin.getMappedURI();

				addUriMap(new Mapping(mappedURI, locationURI.toString()));
				logger.info("Added URI mapping " + locationURI + " as " + mappedURI);
			}
		}
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#setContainer(org.openarchitectureware.workflow.container.CompositeComponent)
	 */
	public void setContainer(CompositeComponent container) {
		this.container = container;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getLocation()
	 */
	public Location getLocation() {
		return location;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#setLocation(org.openarchitectureware.workflow.ast.parser.Location)
	 */
	public void setLocation(Location location) {
		this.location = location;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getComponentName()
	 */
	public String getComponentName() {
		return COMPONENT_NAME;
	}
}
