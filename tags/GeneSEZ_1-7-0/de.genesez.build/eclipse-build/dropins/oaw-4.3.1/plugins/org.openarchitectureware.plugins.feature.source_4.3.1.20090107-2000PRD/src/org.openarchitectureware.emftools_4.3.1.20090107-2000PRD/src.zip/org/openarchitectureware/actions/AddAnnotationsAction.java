/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.actions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.eclipse.emf.common.util.TreeIterator;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EParameter;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.EcoreUtil;

public class AddAnnotationsAction extends AbstractCoreModelTransformerAction {

    @SuppressWarnings("unchecked")
	@Override
    public void transform(final Resource r) {
        final Iterator<EObject> iter = r.getAllContents();
        while (iter.hasNext()) {
            final EObject object = iter.next();
            if (object instanceof EOperation) {
                final EOperation op = (EOperation) object;
                EAnnotation anno = op.getEAnnotation(ANNO_SOURCE);
                if (anno == null) {
                    anno = EcorePackage.eINSTANCE.getEcoreFactory().createEAnnotation();
                    anno.setSource(ANNO_SOURCE);
                }
                final String body = getBody(op);
                anno.getDetails().put(ANNO_KEY, body);
                op.getEAnnotations().add(anno);
            }
        }
    }

    @SuppressWarnings("unchecked")
	private String getBody(final EOperation op) {
        final StringBuffer buff = new StringBuffer();
        List<EClass> allClasses = getSubClasses(op.getEContainingClass());
        sortByHierarchy(allClasses);
        for (EClass class1 : allClasses) {
        	buff.append("if (this instanceof ").append(class1.getName()).append("Impl) { ");
        	delegationCallForClass(op, class1, buff);
        	buff.append("} else ");
		}
        buff.append("{");
        delegationCallForClass(op, op.getEContainingClass(), buff);
        buff.append("}");
        return buff.toString();
    }

	private void delegationCallForClass(final EOperation op, EClass class1, final StringBuffer buff) {
		if (op.getEType() != null) {
			buff.append("return ");
		}
		buff.append(getExtensionClassName(op)).append(".");
		buff.append(op.getName());
		buff.append("((").append(class1.getName()).append("Impl) this");
		final List<EParameter> params = op.getEParameters();
		for (final Iterator<EParameter> iter = params.iterator(); iter.hasNext();) {
			final EParameter element = iter.next();
			buff.append(", ");
			buff.append(element.getName());
		}
		buff.append(");");
	}

    private void sortByHierarchy(List<EClass> allClasses) {
		Collections.sort(allClasses, new Comparator<EClass>(){

			public int compare(EClass o1, EClass o2) {
				if (o1.getEAllSuperTypes().contains(o2)) {
					return -1;
				} else if (o2.getEAllSuperTypes().contains(o1)) {
					return 1;
				}
				return 0;
			}});
	}

	private List<EClass> getSubClasses(EClass containingClass) {
    	List<EClass> result = new ArrayList<EClass>();
		EObject rootContainer = EcoreUtil.getRootContainer(containingClass, true);
		TreeIterator<Object> contents = EcoreUtil.getAllProperContents(rootContainer, false);
		while (contents.hasNext()) {
			EObject o = (EObject) contents.next();
			if (o instanceof EClass && ((EClass)o).getEAllSuperTypes().contains(containingClass)) {
				result.add((EClass) o);
			}
		}
		return result;
	}

	private String getExtensionClassName(final EOperation op) {
        return toFirstUpper(op.getEContainingClass().getEPackage().getName() + "Util");
    }

	private String toFirstUpper(String name) {
		return name.substring(0,1).toUpperCase()+name.substring(1);
	}

}
