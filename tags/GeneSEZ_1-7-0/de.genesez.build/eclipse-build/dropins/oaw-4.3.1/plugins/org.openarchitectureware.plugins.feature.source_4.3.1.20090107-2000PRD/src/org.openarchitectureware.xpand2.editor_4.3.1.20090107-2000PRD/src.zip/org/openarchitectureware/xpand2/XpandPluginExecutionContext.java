/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xpand2;

import java.util.HashMap;
import java.util.Map;

import org.openarchitectureware.core.IOawProject;
import org.openarchitectureware.expression.Resource;
import org.openarchitectureware.expression.ResourceManager;
import org.openarchitectureware.expression.ResourceParser;
import org.openarchitectureware.expression.TypeSystemImpl;
import org.openarchitectureware.expression.Variable;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;
import org.openarchitectureware.xpand2.output.Output;
import org.openarchitectureware.xpand2.pr.ProtectedRegionResolver;

public class XpandPluginExecutionContext extends XpandExecutionContextImpl {
    private final IOawProject project;

    public XpandPluginExecutionContext(final IOawProject xp) {
        this (new PluginResourceManager(xp), null, new TypeSystemImpl(), new HashMap<String, Variable>(), new HashMap<String, Variable>(), null, null, null, xp);
    }

    protected XpandPluginExecutionContext (ResourceManager resourceManager, Resource currentResource, TypeSystemImpl typeSystem, Map<String, Variable> vars,
            Map<String, Variable> globalVars, Output output, ProtectedRegionResolver prs, ProgressMonitor monitor, IOawProject xp) {
        super (resourceManager, currentResource, typeSystem, vars, globalVars, output, prs, monitor, null, null,null,null,null);
        this.project = xp;
    }
    
    @Override
    public XpandPluginExecutionContext cloneContext() {
        return new XpandPluginExecutionContext (resourceManager, currentResource(), typeSystem, getVisibleVariables(), getGlobalVariables(), output, protectedRegionResolver, getMonitor(), project);
    }

    public static class PluginResourceManager implements ResourceManager {
        private IOawProject project;

        public PluginResourceManager(final IOawProject project) {
            assert project!=null;
            this.project = project;
        }

        public Resource loadResource(final String fullyQualifiedName, final String extension) {
            return project.findOawResource(fullyQualifiedName,extension);
        }

        public void setFileEncoding(final String fileEncoding) {
        }

        public void registerParser(final String template_extension, final ResourceParser parser) {
        }
    };
}
