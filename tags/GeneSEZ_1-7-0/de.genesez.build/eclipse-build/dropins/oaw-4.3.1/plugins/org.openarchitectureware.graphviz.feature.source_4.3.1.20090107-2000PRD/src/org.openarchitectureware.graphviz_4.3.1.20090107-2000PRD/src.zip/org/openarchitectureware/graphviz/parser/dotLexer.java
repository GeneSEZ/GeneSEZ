// $ANTLR 3.0 ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g 2008-11-27 18:02:06

package org.openarchitectureware.graphviz.parser;

import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.parser.impl.AntlrUtil;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class dotLexer extends Lexer {
    public static final int T21=21;
    public static final int RULE_ML_COMMENT=9;
    public static final int T14=14;
    public static final int T29=29;
    public static final int RULE_ID=5;
    public static final int T33=33;
    public static final int T22=22;
    public static final int T11=11;
    public static final int RULE_STRING=6;
    public static final int T12=12;
    public static final int T28=28;
    public static final int T23=23;
    public static final int RULE_DOT_ID=4;
    public static final int T13=13;
    public static final int T34=34;
    public static final int T20=20;
    public static final int T25=25;
    public static final int T18=18;
    public static final int RULE_WS=8;
    public static final int T26=26;
    public static final int T15=15;
    public static final int RULE_INT=7;
    public static final int EOF=-1;
    public static final int T32=32;
    public static final int T17=17;
    public static final int Tokens=35;
    public static final int T31=31;
    public static final int T16=16;
    public static final int T27=27;
    public static final int RULE_SL_COMMENT=10;
    public static final int T30=30;
    public static final int T24=24;
    public static final int T19=19;

    	 private List<ErrorMsg> errors = new ArrayList<ErrorMsg>();
    	public List<ErrorMsg> getErrors() {
    		return errors;
    	}

    	public String getErrorMessage(RecognitionException e, String[] tokenNames) {
    		String msg = super.getErrorMessage(e,tokenNames);
    		errors.add(AntlrUtil.create(msg,e,tokenNames));
    		return msg;
    	}

    public dotLexer() {;} 
    public dotLexer(CharStream input) {
        super(input);
    }
    public String getGrammarFileName() { return "..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g"; }

    // $ANTLR start T11
    public void mT11() throws RecognitionException {
        try {
            int _type = T11;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:22:7: ( 'strict' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:22:7: 'strict'
            {
            match("strict"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T11

    // $ANTLR start T12
    public void mT12() throws RecognitionException {
        try {
            int _type = T12;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:23:7: ( '{' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:23:7: '{'
            {
            match('{'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T12

    // $ANTLR start T13
    public void mT13() throws RecognitionException {
        try {
            int _type = T13;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:24:7: ( '}' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:24:7: '}'
            {
            match('}'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T13

    // $ANTLR start T14
    public void mT14() throws RecognitionException {
        try {
            int _type = T14;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:25:7: ( ';' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:25:7: ';'
            {
            match(';'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T14

    // $ANTLR start T15
    public void mT15() throws RecognitionException {
        try {
            int _type = T15;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:26:7: ( '=' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:26:7: '='
            {
            match('='); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T15

    // $ANTLR start T16
    public void mT16() throws RecognitionException {
        try {
            int _type = T16;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:27:7: ( '[' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:27:7: '['
            {
            match('['); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T16

    // $ANTLR start T17
    public void mT17() throws RecognitionException {
        try {
            int _type = T17;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:28:7: ( ']' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:28:7: ']'
            {
            match(']'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T17

    // $ANTLR start T18
    public void mT18() throws RecognitionException {
        try {
            int _type = T18;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:29:7: ( ',' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:29:7: ','
            {
            match(','); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T18

    // $ANTLR start T19
    public void mT19() throws RecognitionException {
        try {
            int _type = T19;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:30:7: ( 'subgraph' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:30:7: 'subgraph'
            {
            match("subgraph"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T19

    // $ANTLR start T20
    public void mT20() throws RecognitionException {
        try {
            int _type = T20;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:31:7: ( ':' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:31:7: ':'
            {
            match(':'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T20

    // $ANTLR start T21
    public void mT21() throws RecognitionException {
        try {
            int _type = T21;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:32:7: ( '->' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:32:7: '->'
            {
            match("->"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T21

    // $ANTLR start T22
    public void mT22() throws RecognitionException {
        try {
            int _type = T22;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:33:7: ( '--' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:33:7: '--'
            {
            match("--"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T22

    // $ANTLR start T23
    public void mT23() throws RecognitionException {
        try {
            int _type = T23;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:34:7: ( 'graph' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:34:7: 'graph'
            {
            match("graph"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T23

    // $ANTLR start T24
    public void mT24() throws RecognitionException {
        try {
            int _type = T24;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:35:7: ( 'digraph' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:35:7: 'digraph'
            {
            match("digraph"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T24

    // $ANTLR start T25
    public void mT25() throws RecognitionException {
        try {
            int _type = T25;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:36:7: ( 'node' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:36:7: 'node'
            {
            match("node"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T25

    // $ANTLR start T26
    public void mT26() throws RecognitionException {
        try {
            int _type = T26;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:37:7: ( 'edge' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:37:7: 'edge'
            {
            match("edge"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T26

    // $ANTLR start T27
    public void mT27() throws RecognitionException {
        try {
            int _type = T27;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:38:7: ( 'n' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:38:7: 'n'
            {
            match('n'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T27

    // $ANTLR start T28
    public void mT28() throws RecognitionException {
        try {
            int _type = T28;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:39:7: ( 'ne' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:39:7: 'ne'
            {
            match("ne"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T28

    // $ANTLR start T29
    public void mT29() throws RecognitionException {
        try {
            int _type = T29;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:40:7: ( 'e' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:40:7: 'e'
            {
            match('e'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T29

    // $ANTLR start T30
    public void mT30() throws RecognitionException {
        try {
            int _type = T30;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:41:7: ( 'se' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:41:7: 'se'
            {
            match("se"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T30

    // $ANTLR start T31
    public void mT31() throws RecognitionException {
        try {
            int _type = T31;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:42:7: ( 's' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:42:7: 's'
            {
            match('s'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T31

    // $ANTLR start T32
    public void mT32() throws RecognitionException {
        try {
            int _type = T32;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:43:7: ( 'sw' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:43:7: 'sw'
            {
            match("sw"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T32

    // $ANTLR start T33
    public void mT33() throws RecognitionException {
        try {
            int _type = T33;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:44:7: ( 'w' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:44:7: 'w'
            {
            match('w'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T33

    // $ANTLR start T34
    public void mT34() throws RecognitionException {
        try {
            int _type = T34;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:45:7: ( 'nw' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:45:7: 'nw'
            {
            match("nw"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T34

    // $ANTLR start RULE_DOT_ID
    public void mRULE_DOT_ID() throws RecognitionException {
        try {
            int _type = RULE_DOT_ID;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:964:3: ( ( ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* ) | ( '\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\"' | '\\'' | '\\\\' ) | ~ ( '\"' ) )* '\"' ) | ( ( '-' )? ( '.' ( '0' .. '9' )+ | ( '0' .. '9' )+ ( '.' ( '0' .. '9' )* )? ) ) )
            int alt10=3;
            switch ( input.LA(1) ) {
            case 'A':
            case 'B':
            case 'C':
            case 'D':
            case 'E':
            case 'F':
            case 'G':
            case 'H':
            case 'I':
            case 'J':
            case 'K':
            case 'L':
            case 'M':
            case 'N':
            case 'O':
            case 'P':
            case 'Q':
            case 'R':
            case 'S':
            case 'T':
            case 'U':
            case 'V':
            case 'W':
            case 'X':
            case 'Y':
            case 'Z':
            case '^':
            case '_':
            case 'a':
            case 'b':
            case 'c':
            case 'd':
            case 'e':
            case 'f':
            case 'g':
            case 'h':
            case 'i':
            case 'j':
            case 'k':
            case 'l':
            case 'm':
            case 'n':
            case 'o':
            case 'p':
            case 'q':
            case 'r':
            case 's':
            case 't':
            case 'u':
            case 'v':
            case 'w':
            case 'x':
            case 'y':
            case 'z':
                {
                alt10=1;
                }
                break;
            case '\"':
                {
                alt10=2;
                }
                break;
            case '-':
            case '.':
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                {
                alt10=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("962:1: RULE_DOT_ID : ( ( ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* ) | ( '\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\"' | '\\'' | '\\\\' ) | ~ ( '\"' ) )* '\"' ) | ( ( '-' )? ( '.' ( '0' .. '9' )+ | ( '0' .. '9' )+ ( '.' ( '0' .. '9' )* )? ) ) );", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:964:3: ( ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:964:3: ( ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:964:4: ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:964:4: ( '^' )?
                    int alt1=2;
                    int LA1_0 = input.LA(1);

                    if ( (LA1_0=='^') ) {
                        alt1=1;
                    }
                    switch (alt1) {
                        case 1 :
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:964:5: '^'
                            {
                            match('^'); 

                            }
                            break;

                    }

                    if ( (input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                        input.consume();

                    }
                    else {
                        MismatchedSetException mse =
                            new MismatchedSetException(null,input);
                        recover(mse);    throw mse;
                    }

                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:964:34: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
                    loop2:
                    do {
                        int alt2=2;
                        int LA2_0 = input.LA(1);

                        if ( ((LA2_0>='0' && LA2_0<='9')||(LA2_0>='A' && LA2_0<='Z')||LA2_0=='_'||(LA2_0>='a' && LA2_0<='z')) ) {
                            alt2=1;
                        }


                        switch (alt2) {
                    	case 1 :
                    	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:
                    	    {
                    	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop2;
                        }
                    } while (true);


                    }


                    }
                    break;
                case 2 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:965:2: ( '\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\"' | '\\'' | '\\\\' ) | ~ ( '\"' ) )* '\"' )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:965:2: ( '\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\"' | '\\'' | '\\\\' ) | ~ ( '\"' ) )* '\"' )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:965:3: '\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\"' | '\\'' | '\\\\' ) | ~ ( '\"' ) )* '\"'
                    {
                    match('\"'); 
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:965:7: ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\"' | '\\'' | '\\\\' ) | ~ ( '\"' ) )*
                    loop3:
                    do {
                        int alt3=3;
                        int LA3_0 = input.LA(1);

                        if ( (LA3_0=='\\') ) {
                            int LA3_2 = input.LA(2);

                            if ( (LA3_2=='\"') ) {
                                int LA3_4 = input.LA(3);

                                if ( ((LA3_4>='\u0000' && LA3_4<='\uFFFE')) ) {
                                    alt3=1;
                                }

                                else {
                                    alt3=2;
                                }

                            }
                            else if ( (LA3_2=='\\') ) {
                                alt3=1;
                            }
                            else if ( (LA3_2=='\''||LA3_2=='b'||LA3_2=='f'||LA3_2=='n'||LA3_2=='r'||LA3_2=='t') ) {
                                alt3=1;
                            }
                            else if ( ((LA3_2>='\u0000' && LA3_2<='!')||(LA3_2>='#' && LA3_2<='&')||(LA3_2>='(' && LA3_2<='[')||(LA3_2>=']' && LA3_2<='a')||(LA3_2>='c' && LA3_2<='e')||(LA3_2>='g' && LA3_2<='m')||(LA3_2>='o' && LA3_2<='q')||LA3_2=='s'||(LA3_2>='u' && LA3_2<='\uFFFE')) ) {
                                alt3=2;
                            }


                        }
                        else if ( ((LA3_0>='\u0000' && LA3_0<='!')||(LA3_0>='#' && LA3_0<='[')||(LA3_0>=']' && LA3_0<='\uFFFE')) ) {
                            alt3=2;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:965:9: '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\"' | '\\'' | '\\\\' )
                    	    {
                    	    match('\\'); 
                    	    if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='b'||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t' ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;
                    	case 2 :
                    	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:965:52: ~ ( '\"' )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='\uFFFE') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);

                    match('\"'); 

                    }


                    }
                    break;
                case 3 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:2: ( ( '-' )? ( '.' ( '0' .. '9' )+ | ( '0' .. '9' )+ ( '.' ( '0' .. '9' )* )? ) )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:2: ( ( '-' )? ( '.' ( '0' .. '9' )+ | ( '0' .. '9' )+ ( '.' ( '0' .. '9' )* )? ) )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:3: ( '-' )? ( '.' ( '0' .. '9' )+ | ( '0' .. '9' )+ ( '.' ( '0' .. '9' )* )? )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:3: ( '-' )?
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0=='-') ) {
                        alt4=1;
                    }
                    switch (alt4) {
                        case 1 :
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:4: '-'
                            {
                            match('-'); 

                            }
                            break;

                    }

                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:9: ( '.' ( '0' .. '9' )+ | ( '0' .. '9' )+ ( '.' ( '0' .. '9' )* )? )
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0=='.') ) {
                        alt9=1;
                    }
                    else if ( ((LA9_0>='0' && LA9_0<='9')) ) {
                        alt9=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("966:9: ( '.' ( '0' .. '9' )+ | ( '0' .. '9' )+ ( '.' ( '0' .. '9' )* )? )", 9, 0, input);

                        throw nvae;
                    }
                    switch (alt9) {
                        case 1 :
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:10: '.' ( '0' .. '9' )+
                            {
                            match('.'); 
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:13: ( '0' .. '9' )+
                            int cnt5=0;
                            loop5:
                            do {
                                int alt5=2;
                                int LA5_0 = input.LA(1);

                                if ( ((LA5_0>='0' && LA5_0<='9')) ) {
                                    alt5=1;
                                }


                                switch (alt5) {
                            	case 1 :
                            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:14: '0' .. '9'
                            	    {
                            	    matchRange('0','9'); 

                            	    }
                            	    break;

                            	default :
                            	    if ( cnt5 >= 1 ) break loop5;
                                        EarlyExitException eee =
                                            new EarlyExitException(5, input);
                                        throw eee;
                                }
                                cnt5++;
                            } while (true);


                            }
                            break;
                        case 2 :
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:27: ( '0' .. '9' )+ ( '.' ( '0' .. '9' )* )?
                            {
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:27: ( '0' .. '9' )+
                            int cnt6=0;
                            loop6:
                            do {
                                int alt6=2;
                                int LA6_0 = input.LA(1);

                                if ( ((LA6_0>='0' && LA6_0<='9')) ) {
                                    alt6=1;
                                }


                                switch (alt6) {
                            	case 1 :
                            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:28: '0' .. '9'
                            	    {
                            	    matchRange('0','9'); 

                            	    }
                            	    break;

                            	default :
                            	    if ( cnt6 >= 1 ) break loop6;
                                        EarlyExitException eee =
                                            new EarlyExitException(6, input);
                                        throw eee;
                                }
                                cnt6++;
                            } while (true);

                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:38: ( '.' ( '0' .. '9' )* )?
                            int alt8=2;
                            int LA8_0 = input.LA(1);

                            if ( (LA8_0=='.') ) {
                                alt8=1;
                            }
                            switch (alt8) {
                                case 1 :
                                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:39: '.' ( '0' .. '9' )*
                                    {
                                    match('.'); 
                                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:43: ( '0' .. '9' )*
                                    loop7:
                                    do {
                                        int alt7=2;
                                        int LA7_0 = input.LA(1);

                                        if ( ((LA7_0>='0' && LA7_0<='9')) ) {
                                            alt7=1;
                                        }


                                        switch (alt7) {
                                    	case 1 :
                                    	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:966:44: '0' .. '9'
                                    	    {
                                    	    matchRange('0','9'); 

                                    	    }
                                    	    break;

                                    	default :
                                    	    break loop7;
                                        }
                                    } while (true);


                                    }
                                    break;

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;

            }
            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end RULE_DOT_ID

    // $ANTLR start RULE_ID
    public void mRULE_ID() throws RecognitionException {
        try {
            int _type = RULE_ID;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:971:3: ( ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:971:3: ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:971:3: ( '^' )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0=='^') ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:971:4: '^'
                    {
                    match('^'); 

                    }
                    break;

            }

            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:971:33: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>='0' && LA12_0<='9')||(LA12_0>='A' && LA12_0<='Z')||LA12_0=='_'||(LA12_0>='a' && LA12_0<='z')) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end RULE_ID

    // $ANTLR start RULE_STRING
    public void mRULE_STRING() throws RecognitionException {
        try {
            int _type = RULE_STRING;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:977:3: ( '\\\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\\"' ) )* '\\\"' | '\\'' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\'' ) )* '\\'' )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0=='\"') ) {
                alt15=1;
            }
            else if ( (LA15_0=='\'') ) {
                alt15=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("975:1: RULE_STRING : ( '\\\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\\"' ) )* '\\\"' | '\\'' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\'' ) )* '\\'' );", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:977:3: '\\\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\\"' ) )* '\\\"'
                    {
                    match('\"'); 
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:977:8: ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\\"' ) )*
                    loop13:
                    do {
                        int alt13=3;
                        int LA13_0 = input.LA(1);

                        if ( (LA13_0=='\\') ) {
                            alt13=1;
                        }
                        else if ( ((LA13_0>='\u0000' && LA13_0<='!')||(LA13_0>='#' && LA13_0<='[')||(LA13_0>=']' && LA13_0<='\uFFFE')) ) {
                            alt13=2;
                        }


                        switch (alt13) {
                    	case 1 :
                    	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:977:10: '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' )
                    	    {
                    	    match('\\'); 
                    	    if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='b'||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t' ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;
                    	case 2 :
                    	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:977:54: ~ ( '\\\\' | '\\\"' )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFE') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop13;
                        }
                    } while (true);

                    match('\"'); 

                    }
                    break;
                case 2 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:978:3: '\\'' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\'' ) )* '\\''
                    {
                    match('\''); 
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:978:8: ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\'' ) )*
                    loop14:
                    do {
                        int alt14=3;
                        int LA14_0 = input.LA(1);

                        if ( (LA14_0=='\\') ) {
                            alt14=1;
                        }
                        else if ( ((LA14_0>='\u0000' && LA14_0<='&')||(LA14_0>='(' && LA14_0<='[')||(LA14_0>=']' && LA14_0<='\uFFFE')) ) {
                            alt14=2;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:978:10: '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' )
                    	    {
                    	    match('\\'); 
                    	    if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='b'||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t' ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;
                    	case 2 :
                    	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:978:54: ~ ( '\\\\' | '\\'' )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFE') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop14;
                        }
                    } while (true);

                    match('\''); 

                    }
                    break;

            }
            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end RULE_STRING

    // $ANTLR start RULE_INT
    public void mRULE_INT() throws RecognitionException {
        try {
            int _type = RULE_INT;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:984:3: ( ( '-' )? ( '0' .. '9' )+ )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:984:3: ( '-' )? ( '0' .. '9' )+
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:984:3: ( '-' )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0=='-') ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:984:4: '-'
                    {
                    match('-'); 

                    }
                    break;

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:984:9: ( '0' .. '9' )+
            int cnt17=0;
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( ((LA17_0>='0' && LA17_0<='9')) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:984:10: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt17 >= 1 ) break loop17;
                        EarlyExitException eee =
                            new EarlyExitException(17, input);
                        throw eee;
                }
                cnt17++;
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end RULE_INT

    // $ANTLR start RULE_WS
    public void mRULE_WS() throws RecognitionException {
        try {
            int _type = RULE_WS;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:990:3: ( ( ' ' | '\\t' | '\\r' | '\\n' )+ )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:990:3: ( ' ' | '\\t' | '\\r' | '\\n' )+
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:990:3: ( ' ' | '\\t' | '\\r' | '\\n' )+
            int cnt18=0;
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( ((LA18_0>='\t' && LA18_0<='\n')||LA18_0=='\r'||LA18_0==' ') ) {
                    alt18=1;
                }


                switch (alt18) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||input.LA(1)=='\r'||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt18 >= 1 ) break loop18;
                        EarlyExitException eee =
                            new EarlyExitException(18, input);
                        throw eee;
                }
                cnt18++;
            } while (true);

            channel=HIDDEN;

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end RULE_WS

    // $ANTLR start RULE_ML_COMMENT
    public void mRULE_ML_COMMENT() throws RecognitionException {
        try {
            int _type = RULE_ML_COMMENT;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:996:3: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:996:3: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match("/*"); 

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:996:8: ( options {greedy=false; } : . )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0=='*') ) {
                    int LA19_1 = input.LA(2);

                    if ( (LA19_1=='/') ) {
                        alt19=2;
                    }
                    else if ( ((LA19_1>='\u0000' && LA19_1<='.')||(LA19_1>='0' && LA19_1<='\uFFFE')) ) {
                        alt19=1;
                    }


                }
                else if ( ((LA19_0>='\u0000' && LA19_0<=')')||(LA19_0>='+' && LA19_0<='\uFFFE')) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:996:36: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            match("*/"); 

            channel=HIDDEN;

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end RULE_ML_COMMENT

    // $ANTLR start RULE_SL_COMMENT
    public void mRULE_SL_COMMENT() throws RecognitionException {
        try {
            int _type = RULE_SL_COMMENT;
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1002:3: ( '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1002:3: '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n'
            {
            match("//"); 

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1002:8: (~ ( '\\n' | '\\r' ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( ((LA20_0>='\u0000' && LA20_0<='\t')||(LA20_0>='\u000B' && LA20_0<='\f')||(LA20_0>='\u000E' && LA20_0<='\uFFFE')) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1002:8: ~ ( '\\n' | '\\r' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFE') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1002:22: ( '\\r' )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0=='\r') ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1002:22: '\\r'
                    {
                    match('\r'); 

                    }
                    break;

            }

            match('\n'); 
            channel=HIDDEN;

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end RULE_SL_COMMENT

    public void mTokens() throws RecognitionException {
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:10: ( T11 | T12 | T13 | T14 | T15 | T16 | T17 | T18 | T19 | T20 | T21 | T22 | T23 | T24 | T25 | T26 | T27 | T28 | T29 | T30 | T31 | T32 | T33 | T34 | RULE_DOT_ID | RULE_ID | RULE_STRING | RULE_INT | RULE_WS | RULE_ML_COMMENT | RULE_SL_COMMENT )
        int alt22=31;
        alt22 = dfa22.predict(input);
        switch (alt22) {
            case 1 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:10: T11
                {
                mT11(); 

                }
                break;
            case 2 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:14: T12
                {
                mT12(); 

                }
                break;
            case 3 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:18: T13
                {
                mT13(); 

                }
                break;
            case 4 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:22: T14
                {
                mT14(); 

                }
                break;
            case 5 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:26: T15
                {
                mT15(); 

                }
                break;
            case 6 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:30: T16
                {
                mT16(); 

                }
                break;
            case 7 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:34: T17
                {
                mT17(); 

                }
                break;
            case 8 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:38: T18
                {
                mT18(); 

                }
                break;
            case 9 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:42: T19
                {
                mT19(); 

                }
                break;
            case 10 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:46: T20
                {
                mT20(); 

                }
                break;
            case 11 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:50: T21
                {
                mT21(); 

                }
                break;
            case 12 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:54: T22
                {
                mT22(); 

                }
                break;
            case 13 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:58: T23
                {
                mT23(); 

                }
                break;
            case 14 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:62: T24
                {
                mT24(); 

                }
                break;
            case 15 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:66: T25
                {
                mT25(); 

                }
                break;
            case 16 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:70: T26
                {
                mT26(); 

                }
                break;
            case 17 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:74: T27
                {
                mT27(); 

                }
                break;
            case 18 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:78: T28
                {
                mT28(); 

                }
                break;
            case 19 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:82: T29
                {
                mT29(); 

                }
                break;
            case 20 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:86: T30
                {
                mT30(); 

                }
                break;
            case 21 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:90: T31
                {
                mT31(); 

                }
                break;
            case 22 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:94: T32
                {
                mT32(); 

                }
                break;
            case 23 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:98: T33
                {
                mT33(); 

                }
                break;
            case 24 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:102: T34
                {
                mT34(); 

                }
                break;
            case 25 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:106: RULE_DOT_ID
                {
                mRULE_DOT_ID(); 

                }
                break;
            case 26 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:118: RULE_ID
                {
                mRULE_ID(); 

                }
                break;
            case 27 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:126: RULE_STRING
                {
                mRULE_STRING(); 

                }
                break;
            case 28 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:138: RULE_INT
                {
                mRULE_INT(); 

                }
                break;
            case 29 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:147: RULE_WS
                {
                mRULE_WS(); 

                }
                break;
            case 30 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:155: RULE_ML_COMMENT
                {
                mRULE_ML_COMMENT(); 

                }
                break;
            case 31 :
                // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:1:171: RULE_SL_COMMENT
                {
                mRULE_SL_COMMENT(); 

                }
                break;

        }

    }


    protected DFA22 dfa22 = new DFA22(this);
    static final String DFA22_eotS =
        "\1\uffff\1\35\11\uffff\2\23\1\45\1\47\1\50\1\uffff\1\23\2\uffff"+
        "\1\23\3\uffff\2\23\1\60\1\61\1\23\3\uffff\3\23\1\65\1\66\1\uffff"+
        "\1\23\7\uffff\2\23\2\uffff\3\23\2\uffff\2\23\2\uffff\4\23\1\110"+
        "\1\111\3\uffff\2\23\1\114\1\23\2\uffff\1\23\1\117\1\uffff\2\23\1"+
        "\uffff\1\122\1\123\2\uffff";
    static final String DFA22_eofS =
        "\124\uffff";
    static final String DFA22_minS =
        "\1\11\1\60\10\uffff\1\55\5\60\1\101\1\60\1\0\1\uffff\1\60\2\uffff"+
        "\1\52\5\60\3\uffff\5\60\1\uffff\1\60\2\uffff\2\0\3\uffff\2\60\2"+
        "\uffff\3\60\2\uffff\1\60\3\0\6\60\1\uffff\2\0\4\60\2\uffff\2\60"+
        "\1\uffff\2\60\1\uffff\2\60\2\uffff";
    static final String DFA22_maxS =
        "\1\175\1\172\10\uffff\1\76\7\172\1\ufffe\1\uffff\1\71\2\uffff\1"+
        "\57\5\172\3\uffff\5\172\1\uffff\1\172\2\uffff\2\ufffe\3\uffff\2"+
        "\172\2\uffff\3\172\2\uffff\1\172\3\ufffe\6\172\1\uffff\2\ufffe\4"+
        "\172\2\uffff\2\172\1\uffff\2\172\1\uffff\2\172\2\uffff";
    static final String DFA22_acceptS =
        "\2\uffff\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\12\11\uffff\1\31\1\uffff"+
        "\1\33\1\35\6\uffff\1\25\1\14\1\13\5\uffff\1\21\1\uffff\1\23\1\27"+
        "\2\uffff\1\31\1\36\1\37\2\uffff\1\26\1\24\3\uffff\1\30\1\22\12\uffff"+
        "\1\31\6\uffff\1\17\1\20\2\uffff\1\15\2\uffff\1\1\2\uffff\1\16\1"+
        "\11";
    static final String DFA22_specialS =
        "\124\uffff}>";
    static final String[] DFA22_transitionS = {
            "\2\26\2\uffff\1\26\22\uffff\1\26\1\uffff\1\22\4\uffff\1\25\4"+
            "\uffff\1\10\1\12\1\23\1\27\12\24\1\11\1\4\1\uffff\1\5\3\uffff"+
            "\32\21\1\6\1\uffff\1\7\1\20\1\21\1\uffff\3\21\1\14\1\16\1\21"+
            "\1\13\6\21\1\15\4\21\1\1\3\21\1\17\3\21\1\2\1\uffff\1\3",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\4\34\1\33\16\34\1"+
            "\31\1\30\1\34\1\32\3\34",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\36\1\23\1\uffff\12\24\4\uffff\1\37",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\21\34\1\40\10\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\10\34\1\41\21\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\4\34\1\44\11\34\1"+
            "\42\7\34\1\43\3\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\3\34\1\46\26\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "\32\21\4\uffff\1\21\1\uffff\32\21",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "\42\52\1\53\71\52\1\51\uffa2\52",
            "",
            "\12\24",
            "",
            "",
            "\1\54\4\uffff\1\55",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\1\34\1\56\30\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\21\34\1\57\10\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "",
            "",
            "",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\1\62\31\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\6\34\1\63\23\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\3\34\1\64\26\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\6\34\1\67\23\34",
            "",
            "",
            "\42\23\1\70\4\23\1\72\64\23\1\71\5\23\1\72\3\23\1\72\7\23\1"+
            "\72\3\23\1\72\1\23\1\72\uff8a\23",
            "\42\52\1\53\71\52\1\51\uffa2\52",
            "",
            "",
            "",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\6\34\1\73\23\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\10\34\1\74\21\34",
            "",
            "",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\17\34\1\75\12\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\21\34\1\76\10\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\4\34\1\77\25\34",
            "",
            "",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\4\34\1\100\25\34",
            "\42\52\1\53\71\52\1\51\uffa2\52",
            "\42\52\1\101\4\52\1\103\64\52\1\102\5\52\1\103\3\52\1\103\7"+
            "\52\1\103\3\52\1\103\1\52\1\103\uff8a\52",
            "\42\52\1\53\71\52\1\51\uffa2\52",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\21\34\1\104\10\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\2\34\1\105\27\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\7\34\1\106\22\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\1\107\31\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "",
            "\42\23\1\70\4\23\1\72\64\23\1\71\5\23\1\72\3\23\1\72\7\23\1"+
            "\72\3\23\1\72\1\23\1\72\uff8a\23",
            "\42\52\1\53\71\52\1\51\uffa2\52",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\1\112\31\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\23\34\1\113\6\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\17\34\1\115\12\34",
            "",
            "",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\17\34\1\116\12\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\7\34\1\120\22\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\7\34\1\121\22\34",
            "",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "\12\34\7\uffff\32\34\4\uffff\1\34\1\uffff\32\34",
            "",
            ""
    };

    static final short[] DFA22_eot = DFA.unpackEncodedString(DFA22_eotS);
    static final short[] DFA22_eof = DFA.unpackEncodedString(DFA22_eofS);
    static final char[] DFA22_min = DFA.unpackEncodedStringToUnsignedChars(DFA22_minS);
    static final char[] DFA22_max = DFA.unpackEncodedStringToUnsignedChars(DFA22_maxS);
    static final short[] DFA22_accept = DFA.unpackEncodedString(DFA22_acceptS);
    static final short[] DFA22_special = DFA.unpackEncodedString(DFA22_specialS);
    static final short[][] DFA22_transition;

    static {
        int numStates = DFA22_transitionS.length;
        DFA22_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA22_transition[i] = DFA.unpackEncodedString(DFA22_transitionS[i]);
        }
    }

    class DFA22 extends DFA {

        public DFA22(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 22;
            this.eot = DFA22_eot;
            this.eof = DFA22_eof;
            this.min = DFA22_min;
            this.max = DFA22_max;
            this.accept = DFA22_accept;
            this.special = DFA22_special;
            this.transition = DFA22_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T11 | T12 | T13 | T14 | T15 | T16 | T17 | T18 | T19 | T20 | T21 | T22 | T23 | T24 | T25 | T26 | T27 | T28 | T29 | T30 | T31 | T32 | T33 | T34 | RULE_DOT_ID | RULE_ID | RULE_STRING | RULE_INT | RULE_WS | RULE_ML_COMMENT | RULE_SL_COMMENT );";
        }
    }
 

}