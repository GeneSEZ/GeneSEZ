// $ANTLR 3.0 ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g 2008-11-27 18:02:05

package org.openarchitectureware.graphviz.parser;

import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.emf.ecore.EObject;

import org.openarchitectureware.xtext.parser.impl.AntlrUtil;
import org.openarchitectureware.xtext.XtextFile;
import org.openarchitectureware.xtext.parser.impl.EcoreModelFactory;
import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.parser.model.ParseTreeManagerNeu;
import org.openarchitectureware.xtext.parser.parsetree.Node;

import org.openarchitectureware.graphviz.MetaModelRegistration;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class dotParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_DOT_ID", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_WS", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "'strict'", "'{'", "'}'", "';'", "'='", "'['", "']'", "','", "'subgraph'", "':'", "'->'", "'--'", "'graph'", "'digraph'", "'node'", "'edge'", "'n'", "'ne'", "'e'", "'se'", "'s'", "'sw'", "'w'", "'nw'"
    };
    public static final int RULE_ML_COMMENT=9;
    public static final int RULE_ID=5;
    public static final int RULE_WS=8;
    public static final int EOF=-1;
    public static final int RULE_INT=7;
    public static final int RULE_STRING=6;
    public static final int RULE_SL_COMMENT=10;
    public static final int RULE_DOT_ID=4;

        public dotParser(TokenStream input) {
            super(input);
            ruleMemo = new HashMap[60+1];
         }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g"; }



    	private Token getLastToken() {
    		return input.LT(-1);
    	}

    	protected Object convert(Object arg) {
    		if (arg instanceof org.antlr.runtime.Token) {
    			Token t = (Token) arg;
    			String s = t.getText();
    			if (t.getType() == dotLexer.RULE_ID && s.startsWith("^")) {
    				return s.substring(1);
    			} else if (t.getType()==dotLexer.RULE_STRING) {
    				return s.substring(1,s.length()-1);
    			} else if (t.getType()==dotLexer.RULE_INT) {
    				return Integer.valueOf(s);
    			}
    			return s;
    		}
    		return arg;
    	}


    	private EcoreModelFactory factory = new EcoreModelFactory(MetaModelRegistration.getEPackage());
        private ParseTreeManagerNeu ptm = new ParseTreeManagerNeu();
    	private XtextFile xtextfile = MetaModelRegistration.getXtextFile();
    	
    	{
    		
    	}

    	public ParseTreeManagerNeu getResult() {
    		return ptm;
    	}

    	private List<ErrorMsg> errors = new ArrayList<ErrorMsg>();
    	public List<ErrorMsg> getErrors() {
    		return errors;
    	}

    	@Override
    	public void reportError(RecognitionException e) {
    		String msg = super.getErrorMessage(e,tokenNames);
    		errors.add(AntlrUtil.create(msg,e,tokenNames));
    		ptm.addError(msg, e);
    		// This doesn't work. ANTLR may simply report an superfluous token. In that case,
    		// two nodes will be finished instead of one.
    		// ptm.ruleFinished(null, end());
    	}

        private boolean skipCurrentToken;
        
    	@Override
    	protected boolean recoverFromMismatchedElement(IntStream arg0, RecognitionException arg1, BitSet arg2) {
    		skipCurrentToken = true;
    		return super.recoverFromMismatchedElement(arg0, arg1, arg2);
    	}



    // $ANTLR start parse
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:101:1: parse returns [Node r] : result= rulegraphvizmodel EOF ;
    public Node parse() throws RecognitionException {
        Node r = null;
        int parse_StartIndex = input.index();
        EObject result = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 1) ) { return r; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:102:3: (result= rulegraphvizmodel EOF )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:102:3: result= rulegraphvizmodel EOF
            {
            pushFollow(FOLLOW_rulegraphvizmodel_in_parse67);
            result=rulegraphvizmodel();
            _fsp--;
            if (failed) return r;
            if ( backtracking==0 ) {

              if (result != null)
                ptm.setModelElement(result);
              r = ptm.getCurrent();
              ptm.ruleFinished(result);
            }
            match(input,EOF,FOLLOW_EOF_in_parse78); if (failed) return r;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 1, parse_StartIndex); }
        }
        return r;
    }
    // $ANTLR end parse


    // $ANTLR start rulegraphvizmodel
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:112:1: rulegraphvizmodel returns [EObject result] : (temp_graph= rulegraph )* ;
    public EObject rulegraphvizmodel() throws RecognitionException {
        EObject result = null;
        int rulegraphvizmodel_StartIndex = input.index();
        EObject temp_graph = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 2) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:115:4: ( (temp_graph= rulegraph )* )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:115:4: (temp_graph= rulegraph )*
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "graphvizmodel");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:118:1: (temp_graph= rulegraph )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==11||(LA1_0>=23 && LA1_0<=24)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:118:2: temp_graph= rulegraph
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(0)).eContents().get(1)));
            	    }
            	    pushFollow(FOLLOW_rulegraph_in_rulegraphvizmodel106);
            	    temp_graph=rulegraph();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_graph != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_graph);
            	        factory.add(result,"graphs",convert(temp_graph),false);
            	        ptm.ruleFinished(temp_graph);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 2, rulegraphvizmodel_StartIndex); }
        }
        return result;
    }
    // $ANTLR end rulegraphvizmodel


    // $ANTLR start rulegraph
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:136:1: rulegraph returns [EObject result] : ( ( 'strict' )? (temp_graphtype= rulegraphtype ) ( RULE_DOT_ID )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' ) ) ;
    public EObject rulegraph() throws RecognitionException {
        EObject result = null;
        int rulegraph_StartIndex = input.index();
        Enumerator temp_graphtype = null;

        EObject temp_attr_list = null;

        EObject temp_stmt = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 3) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:139:4: ( ( ( 'strict' )? (temp_graphtype= rulegraphtype ) ( RULE_DOT_ID )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' ) ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:139:4: ( ( 'strict' )? (temp_graphtype= rulegraphtype ) ( RULE_DOT_ID )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "graph");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:142:1: ( ( 'strict' )? (temp_graphtype= rulegraphtype ) ( RULE_DOT_ID )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:142:2: ( 'strict' )? (temp_graphtype= rulegraphtype ) ( RULE_DOT_ID )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' )
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:142:2: ( 'strict' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==11) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:142:3: 'strict'
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,11,FOLLOW_11_in_rulegraph145); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        Token temp = getLastToken();
                        ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(1)).eContents().get(1)).eContents().get(0)));
                        factory.set(result,"strict",true);
                        ptm.ruleFinished(temp);
                      }
                    }

                    }
                    break;

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:152:1: (temp_graphtype= rulegraphtype )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:152:2: temp_graphtype= rulegraphtype
            {
            if ( backtracking==0 ) {
              ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(1)).eContents().get(1)).eContents().get(1)));
            }
            pushFollow(FOLLOW_rulegraphtype_in_rulegraph157);
            temp_graphtype=rulegraphtype();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              if (temp_graphtype != null) {
                hasContent = true;
                factory.set(result,"type",convert(temp_graphtype),false);
                ptm.ruleFinished(temp_graphtype);
              } else {
                ptm.destroyNode();
              }

            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:163:1: ( RULE_DOT_ID )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==RULE_DOT_ID) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:163:2: RULE_DOT_ID
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,RULE_DOT_ID,FOLLOW_RULE_DOT_ID_in_rulegraph166); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        Token temp = getLastToken();
                        ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(1)).eContents().get(1)).eContents().get(2)));
                        factory.set(result,"name",convert(temp),false);
                        ptm.ruleFinished(temp);
                      }
                    }

                    }
                    break;

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:173:1: (temp_attr_list= ruleattr_list )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==16) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:173:2: temp_attr_list= ruleattr_list
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(1)).eContents().get(1)).eContents().get(3)));
            	    }
            	    pushFollow(FOLLOW_ruleattr_list_in_rulegraph178);
            	    temp_attr_list=ruleattr_list();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_attr_list != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_attr_list);
            	        factory.add(result,"attributes",convert(temp_attr_list),false);
            	        ptm.ruleFinished(temp_attr_list);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:185:1: ( '{' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:185:2: '{'
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,12,FOLLOW_12_in_rulegraph187); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(1)).eContents().get(1)).eContents().get(4)));
                ptm.ruleFinished(getLastToken());
              }
            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:191:1: (temp_stmt= rulestmt )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_DOT_ID||LA5_0==12||LA5_0==16||LA5_0==19||LA5_0==23||(LA5_0>=25 && LA5_0<=26)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:191:2: temp_stmt= rulestmt
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(1)).eContents().get(1)).eContents().get(5)));
            	    }
            	    pushFollow(FOLLOW_rulestmt_in_rulegraph197);
            	    temp_stmt=rulestmt();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_stmt != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_stmt);
            	        factory.add(result,"stmts",convert(temp_stmt),false);
            	        ptm.ruleFinished(temp_stmt);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:203:1: ( '}' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:203:2: '}'
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,13,FOLLOW_13_in_rulegraph206); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(1)).eContents().get(1)).eContents().get(6)));
                ptm.ruleFinished(getLastToken());
              }
            }

            }


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 3, rulegraph_StartIndex); }
        }
        return result;
    }
    // $ANTLR end rulegraph


    // $ANTLR start rulestmt
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:216:1: rulestmt returns [EObject result] : ( ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) ) ( ';' )? ) ;
    public EObject rulestmt() throws RecognitionException {
        EObject result = null;
        int rulestmt_StartIndex = input.index();
        EObject temp_edge_stmt_node = null;

        EObject temp_edge_stmt_subgraph = null;

        EObject temp_node_stmt = null;

        EObject temp_attribute = null;

        EObject temp_attr_stmt = null;

        EObject temp_subgraph = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 4) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:219:4: ( ( ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) ) ( ';' )? ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:219:4: ( ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) ) ( ';' )? )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "stmt");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:1: ( ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) ) ( ';' )? )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:2: ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) ) ( ';' )?
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:2: ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) )
            int alt6=6;
            switch ( input.LA(1) ) {
            case RULE_DOT_ID:
                {
                int LA6_1 = input.LA(2);

                if ( (synpred6()) ) {
                    alt6=1;
                }
                else if ( (synpred8()) ) {
                    alt6=3;
                }
                else if ( (synpred9()) ) {
                    alt6=4;
                }
                else {
                    if (backtracking>0) {failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("222:2: ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) )", 6, 1, input);

                    throw nvae;
                }
                }
                break;
            case 19:
                {
                int LA6_2 = input.LA(2);

                if ( (synpred7()) ) {
                    alt6=2;
                }
                else if ( (true) ) {
                    alt6=6;
                }
                else {
                    if (backtracking>0) {failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("222:2: ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) )", 6, 2, input);

                    throw nvae;
                }
                }
                break;
            case 16:
                {
                int LA6_3 = input.LA(2);

                if ( (synpred7()) ) {
                    alt6=2;
                }
                else if ( (true) ) {
                    alt6=6;
                }
                else {
                    if (backtracking>0) {failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("222:2: ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) )", 6, 3, input);

                    throw nvae;
                }
                }
                break;
            case 12:
                {
                int LA6_4 = input.LA(2);

                if ( (synpred7()) ) {
                    alt6=2;
                }
                else if ( (true) ) {
                    alt6=6;
                }
                else {
                    if (backtracking>0) {failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("222:2: ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) )", 6, 4, input);

                    throw nvae;
                }
                }
                break;
            case 23:
            case 25:
            case 26:
                {
                alt6=5;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("222:2: ( (temp_edge_stmt_node= ruleedge_stmt_node ) | (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph ) | (temp_node_stmt= rulenode_stmt ) | (temp_attribute= ruleattribute ) | (temp_attr_stmt= ruleattr_stmt ) | (temp_subgraph= rulesubgraph ) )", 6, 0, input);

                throw nvae;
            }

            switch (alt6) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:3: (temp_edge_stmt_node= ruleedge_stmt_node )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:3: (temp_edge_stmt_node= ruleedge_stmt_node )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:4: temp_edge_stmt_node= ruleedge_stmt_node
                    {
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(0)));
                    }
                    pushFollow(FOLLOW_ruleedge_stmt_node_in_rulestmt248);
                    temp_edge_stmt_node=ruleedge_stmt_node();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      if (temp_edge_stmt_node != null) {
                        hasContent = true;
                        ptm.setModelElement(temp_edge_stmt_node);
                        ptm.ruleFinished(temp_edge_stmt_node);
                        result =temp_edge_stmt_node;
                      } else {
                        ptm.destroyNode();
                      }

                    }

                    }


                    }
                    break;
                case 2 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:235:1: (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:235:1: (temp_edge_stmt_subgraph= ruleedge_stmt_subgraph )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:235:2: temp_edge_stmt_subgraph= ruleedge_stmt_subgraph
                    {
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(1)));
                    }
                    pushFollow(FOLLOW_ruleedge_stmt_subgraph_in_rulestmt262);
                    temp_edge_stmt_subgraph=ruleedge_stmt_subgraph();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      if (temp_edge_stmt_subgraph != null) {
                        hasContent = true;
                        ptm.setModelElement(temp_edge_stmt_subgraph);
                        ptm.ruleFinished(temp_edge_stmt_subgraph);
                        result =temp_edge_stmt_subgraph;
                      } else {
                        ptm.destroyNode();
                      }

                    }

                    }


                    }
                    break;
                case 3 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:248:1: (temp_node_stmt= rulenode_stmt )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:248:1: (temp_node_stmt= rulenode_stmt )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:248:2: temp_node_stmt= rulenode_stmt
                    {
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(2)));
                    }
                    pushFollow(FOLLOW_rulenode_stmt_in_rulestmt276);
                    temp_node_stmt=rulenode_stmt();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      if (temp_node_stmt != null) {
                        hasContent = true;
                        ptm.setModelElement(temp_node_stmt);
                        ptm.ruleFinished(temp_node_stmt);
                        result =temp_node_stmt;
                      } else {
                        ptm.destroyNode();
                      }

                    }

                    }


                    }
                    break;
                case 4 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:261:1: (temp_attribute= ruleattribute )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:261:1: (temp_attribute= ruleattribute )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:261:2: temp_attribute= ruleattribute
                    {
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(3)));
                    }
                    pushFollow(FOLLOW_ruleattribute_in_rulestmt290);
                    temp_attribute=ruleattribute();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      if (temp_attribute != null) {
                        hasContent = true;
                        ptm.setModelElement(temp_attribute);
                        ptm.ruleFinished(temp_attribute);
                        result =temp_attribute;
                      } else {
                        ptm.destroyNode();
                      }

                    }

                    }


                    }
                    break;
                case 5 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:274:1: (temp_attr_stmt= ruleattr_stmt )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:274:1: (temp_attr_stmt= ruleattr_stmt )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:274:2: temp_attr_stmt= ruleattr_stmt
                    {
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(4)));
                    }
                    pushFollow(FOLLOW_ruleattr_stmt_in_rulestmt304);
                    temp_attr_stmt=ruleattr_stmt();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      if (temp_attr_stmt != null) {
                        hasContent = true;
                        ptm.setModelElement(temp_attr_stmt);
                        ptm.ruleFinished(temp_attr_stmt);
                        result =temp_attr_stmt;
                      } else {
                        ptm.destroyNode();
                      }

                    }

                    }


                    }
                    break;
                case 6 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:287:1: (temp_subgraph= rulesubgraph )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:287:1: (temp_subgraph= rulesubgraph )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:287:2: temp_subgraph= rulesubgraph
                    {
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(5)));
                    }
                    pushFollow(FOLLOW_rulesubgraph_in_rulestmt318);
                    temp_subgraph=rulesubgraph();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      if (temp_subgraph != null) {
                        hasContent = true;
                        ptm.setModelElement(temp_subgraph);
                        ptm.ruleFinished(temp_subgraph);
                        result =temp_subgraph;
                      } else {
                        ptm.destroyNode();
                      }

                    }

                    }


                    }
                    break;

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:301:1: ( ';' )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==14) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:301:2: ';'
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,14,FOLLOW_14_in_rulestmt329); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(1)));
                        ptm.ruleFinished(getLastToken());
                      }
                    }

                    }
                    break;

            }


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 4, rulestmt_StartIndex); }
        }
        return result;
    }
    // $ANTLR end rulestmt


    // $ANTLR start ruleedge_stmt_node
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:314:1: ruleedge_stmt_node returns [EObject result] : ( (temp_node_id= rulenode_id ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )* ) ;
    public EObject ruleedge_stmt_node() throws RecognitionException {
        EObject result = null;
        int ruleedge_stmt_node_StartIndex = input.index();
        EObject temp_node_id = null;

        EObject temp_edgeRHS = null;

        EObject temp_attr_list = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 5) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:317:4: ( ( (temp_node_id= rulenode_id ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )* ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:317:4: ( (temp_node_id= rulenode_id ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )* )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "edge_stmt_node");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:320:1: ( (temp_node_id= rulenode_id ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )* )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:320:2: (temp_node_id= rulenode_id ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )*
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:320:2: (temp_node_id= rulenode_id )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:320:3: temp_node_id= rulenode_id
            {
            if ( backtracking==0 ) {
              ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(3)).eContents().get(1)).eContents().get(0)));
            }
            pushFollow(FOLLOW_rulenode_id_in_ruleedge_stmt_node371);
            temp_node_id=rulenode_id();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              if (temp_node_id != null) {
                hasContent = true;
                ptm.setModelElement(temp_node_id);
                factory.set(result,"node_id",convert(temp_node_id),false);
                ptm.ruleFinished(temp_node_id);
              } else {
                ptm.destroyNode();
              }

            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:332:1: (temp_edgeRHS= ruleedgeRHS )+
            int cnt8=0;
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( ((LA8_0>=21 && LA8_0<=22)) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:332:2: temp_edgeRHS= ruleedgeRHS
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(3)).eContents().get(1)).eContents().get(1)));
            	    }
            	    pushFollow(FOLLOW_ruleedgeRHS_in_ruleedge_stmt_node382);
            	    temp_edgeRHS=ruleedgeRHS();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_edgeRHS != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_edgeRHS);
            	        factory.add(result,"edgeRHS",convert(temp_edgeRHS),false);
            	        ptm.ruleFinished(temp_edgeRHS);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    if ( cnt8 >= 1 ) break loop8;
            	    if (backtracking>0) {failed=true; return result;}
                        EarlyExitException eee =
                            new EarlyExitException(8, input);
                        throw eee;
                }
                cnt8++;
            } while (true);

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:344:1: (temp_attr_list= ruleattr_list )*
            loop9:
            do {
                int alt9=2;
                alt9 = dfa9.predict(input);
                switch (alt9) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:344:2: temp_attr_list= ruleattr_list
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(3)).eContents().get(1)).eContents().get(2)));
            	    }
            	    pushFollow(FOLLOW_ruleattr_list_in_ruleedge_stmt_node394);
            	    temp_attr_list=ruleattr_list();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_attr_list != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_attr_list);
            	        factory.add(result,"attributes",convert(temp_attr_list),false);
            	        ptm.ruleFinished(temp_attr_list);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 5, ruleedge_stmt_node_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleedge_stmt_node


    // $ANTLR start ruleedge_stmt_subgraph
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:363:1: ruleedge_stmt_subgraph returns [EObject result] : ( (temp_subgraph= rulesubgraph ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )* ) ;
    public EObject ruleedge_stmt_subgraph() throws RecognitionException {
        EObject result = null;
        int ruleedge_stmt_subgraph_StartIndex = input.index();
        EObject temp_subgraph = null;

        EObject temp_edgeRHS = null;

        EObject temp_attr_list = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 6) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:366:4: ( ( (temp_subgraph= rulesubgraph ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )* ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:366:4: ( (temp_subgraph= rulesubgraph ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )* )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "edge_stmt_subgraph");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:369:1: ( (temp_subgraph= rulesubgraph ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )* )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:369:2: (temp_subgraph= rulesubgraph ) (temp_edgeRHS= ruleedgeRHS )+ (temp_attr_list= ruleattr_list )*
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:369:2: (temp_subgraph= rulesubgraph )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:369:3: temp_subgraph= rulesubgraph
            {
            if ( backtracking==0 ) {
              ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(4)).eContents().get(1)).eContents().get(0)));
            }
            pushFollow(FOLLOW_rulesubgraph_in_ruleedge_stmt_subgraph437);
            temp_subgraph=rulesubgraph();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              if (temp_subgraph != null) {
                hasContent = true;
                ptm.setModelElement(temp_subgraph);
                factory.set(result,"subgraph",convert(temp_subgraph),false);
                ptm.ruleFinished(temp_subgraph);
              } else {
                ptm.destroyNode();
              }

            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:381:1: (temp_edgeRHS= ruleedgeRHS )+
            int cnt10=0;
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( ((LA10_0>=21 && LA10_0<=22)) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:381:2: temp_edgeRHS= ruleedgeRHS
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(4)).eContents().get(1)).eContents().get(1)));
            	    }
            	    pushFollow(FOLLOW_ruleedgeRHS_in_ruleedge_stmt_subgraph448);
            	    temp_edgeRHS=ruleedgeRHS();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_edgeRHS != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_edgeRHS);
            	        factory.set(result,"edgeRHS",convert(temp_edgeRHS),false);
            	        ptm.ruleFinished(temp_edgeRHS);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    if ( cnt10 >= 1 ) break loop10;
            	    if (backtracking>0) {failed=true; return result;}
                        EarlyExitException eee =
                            new EarlyExitException(10, input);
                        throw eee;
                }
                cnt10++;
            } while (true);

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:393:1: (temp_attr_list= ruleattr_list )*
            loop11:
            do {
                int alt11=2;
                alt11 = dfa11.predict(input);
                switch (alt11) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:393:2: temp_attr_list= ruleattr_list
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(4)).eContents().get(1)).eContents().get(2)));
            	    }
            	    pushFollow(FOLLOW_ruleattr_list_in_ruleedge_stmt_subgraph460);
            	    temp_attr_list=ruleattr_list();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_attr_list != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_attr_list);
            	        factory.add(result,"attributes",convert(temp_attr_list),false);
            	        ptm.ruleFinished(temp_attr_list);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 6, ruleedge_stmt_subgraph_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleedge_stmt_subgraph


    // $ANTLR start rulenode_stmt
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:412:1: rulenode_stmt returns [EObject result] : ( ( RULE_DOT_ID ) (temp_port= ruleport )? (temp_attr_list= ruleattr_list )* ) ;
    public EObject rulenode_stmt() throws RecognitionException {
        EObject result = null;
        int rulenode_stmt_StartIndex = input.index();
        EObject temp_port = null;

        EObject temp_attr_list = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 7) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:415:4: ( ( ( RULE_DOT_ID ) (temp_port= ruleport )? (temp_attr_list= ruleattr_list )* ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:415:4: ( ( RULE_DOT_ID ) (temp_port= ruleport )? (temp_attr_list= ruleattr_list )* )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "node_stmt");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:418:1: ( ( RULE_DOT_ID ) (temp_port= ruleport )? (temp_attr_list= ruleattr_list )* )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:418:2: ( RULE_DOT_ID ) (temp_port= ruleport )? (temp_attr_list= ruleattr_list )*
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:418:2: ( RULE_DOT_ID )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:418:3: RULE_DOT_ID
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,RULE_DOT_ID,FOLLOW_RULE_DOT_ID_in_rulenode_stmt501); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                Token temp = getLastToken();
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(5)).eContents().get(1)).eContents().get(0)));
                factory.set(result,"name",convert(temp),false);
                ptm.ruleFinished(temp);
              }
            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:428:1: (temp_port= ruleport )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==20) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:428:2: temp_port= ruleport
                    {
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(5)).eContents().get(1)).eContents().get(1)));
                    }
                    pushFollow(FOLLOW_ruleport_in_rulenode_stmt512);
                    temp_port=ruleport();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      if (temp_port != null) {
                        hasContent = true;
                        ptm.setModelElement(temp_port);
                        factory.set(result,"port",convert(temp_port),false);
                        ptm.ruleFinished(temp_port);
                      } else {
                        ptm.destroyNode();
                      }

                    }

                    }
                    break;

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:440:1: (temp_attr_list= ruleattr_list )*
            loop13:
            do {
                int alt13=2;
                alt13 = dfa13.predict(input);
                switch (alt13) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:440:2: temp_attr_list= ruleattr_list
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(5)).eContents().get(1)).eContents().get(2)));
            	    }
            	    pushFollow(FOLLOW_ruleattr_list_in_rulenode_stmt524);
            	    temp_attr_list=ruleattr_list();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_attr_list != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_attr_list);
            	        factory.add(result,"attributes",convert(temp_attr_list),false);
            	        ptm.ruleFinished(temp_attr_list);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 7, rulenode_stmt_StartIndex); }
        }
        return result;
    }
    // $ANTLR end rulenode_stmt


    // $ANTLR start ruleattribute
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:459:1: ruleattribute returns [EObject result] : ( ( RULE_DOT_ID ) ( '=' ) ( RULE_DOT_ID ) ) ;
    public EObject ruleattribute() throws RecognitionException {
        EObject result = null;
        int ruleattribute_StartIndex = input.index();
        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 8) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:462:4: ( ( ( RULE_DOT_ID ) ( '=' ) ( RULE_DOT_ID ) ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:462:4: ( ( RULE_DOT_ID ) ( '=' ) ( RULE_DOT_ID ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "attribute");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:465:1: ( ( RULE_DOT_ID ) ( '=' ) ( RULE_DOT_ID ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:465:2: ( RULE_DOT_ID ) ( '=' ) ( RULE_DOT_ID )
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:465:2: ( RULE_DOT_ID )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:465:3: RULE_DOT_ID
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,RULE_DOT_ID,FOLLOW_RULE_DOT_ID_in_ruleattribute565); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                Token temp = getLastToken();
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(6)).eContents().get(1)).eContents().get(0)));
                factory.set(result,"name",convert(temp),false);
                ptm.ruleFinished(temp);
              }
            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:475:1: ( '=' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:475:2: '='
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,15,FOLLOW_15_in_ruleattribute573); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(6)).eContents().get(1)).eContents().get(1)));
                ptm.ruleFinished(getLastToken());
              }
            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:481:1: ( RULE_DOT_ID )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:481:2: RULE_DOT_ID
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,RULE_DOT_ID,FOLLOW_RULE_DOT_ID_in_ruleattribute581); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                Token temp = getLastToken();
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(6)).eContents().get(1)).eContents().get(2)));
                factory.set(result,"value",convert(temp),false);
                ptm.ruleFinished(temp);
              }
            }

            }


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 8, ruleattribute_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleattribute


    // $ANTLR start ruleattr_stmt
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:498:1: ruleattr_stmt returns [EObject result] : ( (temp_attributetype= ruleattributetype ) (temp_attr_list= ruleattr_list )+ ) ;
    public EObject ruleattr_stmt() throws RecognitionException {
        EObject result = null;
        int ruleattr_stmt_StartIndex = input.index();
        Enumerator temp_attributetype = null;

        EObject temp_attr_list = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 9) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:501:4: ( ( (temp_attributetype= ruleattributetype ) (temp_attr_list= ruleattr_list )+ ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:501:4: ( (temp_attributetype= ruleattributetype ) (temp_attr_list= ruleattr_list )+ )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "attr_stmt");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:504:1: ( (temp_attributetype= ruleattributetype ) (temp_attr_list= ruleattr_list )+ )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:504:2: (temp_attributetype= ruleattributetype ) (temp_attr_list= ruleattr_list )+
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:504:2: (temp_attributetype= ruleattributetype )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:504:3: temp_attributetype= ruleattributetype
            {
            if ( backtracking==0 ) {
              ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(7)).eContents().get(1)).eContents().get(0)));
            }
            pushFollow(FOLLOW_ruleattributetype_in_ruleattr_stmt623);
            temp_attributetype=ruleattributetype();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              if (temp_attributetype != null) {
                hasContent = true;
                factory.set(result,"type",convert(temp_attributetype),false);
                ptm.ruleFinished(temp_attributetype);
              } else {
                ptm.destroyNode();
              }

            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:515:1: (temp_attr_list= ruleattr_list )+
            int cnt14=0;
            loop14:
            do {
                int alt14=2;
                alt14 = dfa14.predict(input);
                switch (alt14) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:515:2: temp_attr_list= ruleattr_list
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(7)).eContents().get(1)).eContents().get(1)));
            	    }
            	    pushFollow(FOLLOW_ruleattr_list_in_ruleattr_stmt634);
            	    temp_attr_list=ruleattr_list();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_attr_list != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_attr_list);
            	        factory.add(result,"attributes",convert(temp_attr_list),false);
            	        ptm.ruleFinished(temp_attr_list);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    if ( cnt14 >= 1 ) break loop14;
            	    if (backtracking>0) {failed=true; return result;}
                        EarlyExitException eee =
                            new EarlyExitException(14, input);
                        throw eee;
                }
                cnt14++;
            } while (true);


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 9, ruleattr_stmt_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleattr_stmt


    // $ANTLR start ruleattr_list
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:534:1: ruleattr_list returns [EObject result] : ( ( '[' ) (temp_a_list= rulea_list )* ( ']' ) ) ;
    public EObject ruleattr_list() throws RecognitionException {
        EObject result = null;
        int ruleattr_list_StartIndex = input.index();
        EObject temp_a_list = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 10) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:537:4: ( ( ( '[' ) (temp_a_list= rulea_list )* ( ']' ) ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:537:4: ( ( '[' ) (temp_a_list= rulea_list )* ( ']' ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "attr_list");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:540:1: ( ( '[' ) (temp_a_list= rulea_list )* ( ']' ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:540:2: ( '[' ) (temp_a_list= rulea_list )* ( ']' )
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:540:2: ( '[' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:540:3: '['
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,16,FOLLOW_16_in_ruleattr_list674); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(8)).eContents().get(1)).eContents().get(0)));
                ptm.ruleFinished(getLastToken());
              }
            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:546:1: (temp_a_list= rulea_list )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==RULE_DOT_ID) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:546:2: temp_a_list= rulea_list
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(8)).eContents().get(1)).eContents().get(1)));
            	    }
            	    pushFollow(FOLLOW_rulea_list_in_ruleattr_list684);
            	    temp_a_list=rulea_list();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_a_list != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_a_list);
            	        factory.add(result,"a_list",convert(temp_a_list),false);
            	        ptm.ruleFinished(temp_a_list);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:558:1: ( ']' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:558:2: ']'
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,17,FOLLOW_17_in_ruleattr_list693); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(8)).eContents().get(1)).eContents().get(2)));
                ptm.ruleFinished(getLastToken());
              }
            }

            }


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 10, ruleattr_list_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleattr_list


    // $ANTLR start rulea_list
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:571:1: rulea_list returns [EObject result] : ( ( RULE_DOT_ID ) ( ( '=' ) ( RULE_DOT_ID ) )? ( ',' )? ) ;
    public EObject rulea_list() throws RecognitionException {
        EObject result = null;
        int rulea_list_StartIndex = input.index();
        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 11) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:574:4: ( ( ( RULE_DOT_ID ) ( ( '=' ) ( RULE_DOT_ID ) )? ( ',' )? ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:574:4: ( ( RULE_DOT_ID ) ( ( '=' ) ( RULE_DOT_ID ) )? ( ',' )? )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "a_list");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:577:1: ( ( RULE_DOT_ID ) ( ( '=' ) ( RULE_DOT_ID ) )? ( ',' )? )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:577:2: ( RULE_DOT_ID ) ( ( '=' ) ( RULE_DOT_ID ) )? ( ',' )?
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:577:2: ( RULE_DOT_ID )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:577:3: RULE_DOT_ID
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,RULE_DOT_ID,FOLLOW_RULE_DOT_ID_in_rulea_list732); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                Token temp = getLastToken();
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(9)).eContents().get(1)).eContents().get(0)));
                factory.set(result,"name",convert(temp),false);
                ptm.ruleFinished(temp);
              }
            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:587:1: ( ( '=' ) ( RULE_DOT_ID ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==15) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:587:2: ( '=' ) ( RULE_DOT_ID )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:587:2: ( '=' )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:587:3: '='
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,15,FOLLOW_15_in_rulea_list741); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(9)).eContents().get(1)).eContents().get(1)).eContents().get(0)));
                        ptm.ruleFinished(getLastToken());
                      }
                    }

                    }

                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:593:1: ( RULE_DOT_ID )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:593:2: RULE_DOT_ID
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,RULE_DOT_ID,FOLLOW_RULE_DOT_ID_in_rulea_list749); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        Token temp = getLastToken();
                        ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(9)).eContents().get(1)).eContents().get(1)).eContents().get(1)));
                        factory.set(result,"value",convert(temp),false);
                        ptm.ruleFinished(temp);
                      }
                    }

                    }


                    }
                    break;

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:604:1: ( ',' )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==18) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:604:2: ','
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,18,FOLLOW_18_in_rulea_list760); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(9)).eContents().get(1)).eContents().get(2)));
                        ptm.ruleFinished(getLastToken());
                      }
                    }

                    }
                    break;

            }


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 11, rulea_list_StartIndex); }
        }
        return result;
    }
    // $ANTLR end rulea_list


    // $ANTLR start rulesubgraph
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:617:1: rulesubgraph returns [EObject result] : ( ( ( 'subgraph' ) ( RULE_DOT_ID ) )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' ) ) ;
    public EObject rulesubgraph() throws RecognitionException {
        EObject result = null;
        int rulesubgraph_StartIndex = input.index();
        EObject temp_attr_list = null;

        EObject temp_stmt = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 12) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:620:4: ( ( ( ( 'subgraph' ) ( RULE_DOT_ID ) )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' ) ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:620:4: ( ( ( 'subgraph' ) ( RULE_DOT_ID ) )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "subgraph");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:623:1: ( ( ( 'subgraph' ) ( RULE_DOT_ID ) )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:623:2: ( ( 'subgraph' ) ( RULE_DOT_ID ) )? (temp_attr_list= ruleattr_list )* ( '{' ) (temp_stmt= rulestmt )* ( '}' )
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:623:2: ( ( 'subgraph' ) ( RULE_DOT_ID ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==19) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:623:3: ( 'subgraph' ) ( RULE_DOT_ID )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:623:3: ( 'subgraph' )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:623:4: 'subgraph'
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,19,FOLLOW_19_in_rulesubgraph800); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(10)).eContents().get(1)).eContents().get(0)).eContents().get(0)));
                        ptm.ruleFinished(getLastToken());
                      }
                    }

                    }

                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:629:1: ( RULE_DOT_ID )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:629:2: RULE_DOT_ID
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,RULE_DOT_ID,FOLLOW_RULE_DOT_ID_in_rulesubgraph808); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        Token temp = getLastToken();
                        ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(10)).eContents().get(1)).eContents().get(0)).eContents().get(1)));
                        factory.set(result,"name",convert(temp),false);
                        ptm.ruleFinished(temp);
                      }
                    }

                    }


                    }
                    break;

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:640:1: (temp_attr_list= ruleattr_list )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==16) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:640:2: temp_attr_list= ruleattr_list
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(10)).eContents().get(1)).eContents().get(1)));
            	    }
            	    pushFollow(FOLLOW_ruleattr_list_in_rulesubgraph822);
            	    temp_attr_list=ruleattr_list();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_attr_list != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_attr_list);
            	        factory.add(result,"attributes",convert(temp_attr_list),false);
            	        ptm.ruleFinished(temp_attr_list);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:652:1: ( '{' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:652:2: '{'
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,12,FOLLOW_12_in_rulesubgraph831); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(10)).eContents().get(1)).eContents().get(2)));
                ptm.ruleFinished(getLastToken());
              }
            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:658:1: (temp_stmt= rulestmt )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==RULE_DOT_ID||LA20_0==12||LA20_0==16||LA20_0==19||LA20_0==23||(LA20_0>=25 && LA20_0<=26)) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:658:2: temp_stmt= rulestmt
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(10)).eContents().get(1)).eContents().get(3)));
            	    }
            	    pushFollow(FOLLOW_rulestmt_in_rulesubgraph841);
            	    temp_stmt=rulestmt();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      if (temp_stmt != null) {
            	        hasContent = true;
            	        ptm.setModelElement(temp_stmt);
            	        factory.add(result,"stmts",convert(temp_stmt),false);
            	        ptm.ruleFinished(temp_stmt);
            	      } else {
            	        ptm.destroyNode();
            	      }

            	    }

            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:670:1: ( '}' )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:670:2: '}'
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,13,FOLLOW_13_in_rulesubgraph850); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(10)).eContents().get(1)).eContents().get(4)));
                ptm.ruleFinished(getLastToken());
              }
            }

            }


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 12, rulesubgraph_StartIndex); }
        }
        return result;
    }
    // $ANTLR end rulesubgraph


    // $ANTLR start ruleport
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:683:1: ruleport returns [EObject result] : ( ( ( ':' ) ( RULE_DOT_ID ) ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )? ) | ( ( ':' ) (temp_compass_pt= rulecompass_pt ) ) ) ;
    public EObject ruleport() throws RecognitionException {
        EObject result = null;
        int ruleport_StartIndex = input.index();
        Enumerator temp_compass_pt = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 13) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:686:4: ( ( ( ( ':' ) ( RULE_DOT_ID ) ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )? ) | ( ( ':' ) (temp_compass_pt= rulecompass_pt ) ) ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:686:4: ( ( ( ':' ) ( RULE_DOT_ID ) ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )? ) | ( ( ':' ) (temp_compass_pt= rulecompass_pt ) ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "port");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:689:1: ( ( ( ':' ) ( RULE_DOT_ID ) ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )? ) | ( ( ':' ) (temp_compass_pt= rulecompass_pt ) ) )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==20) ) {
                int LA22_1 = input.LA(2);

                if ( (LA22_1==RULE_DOT_ID) ) {
                    alt22=1;
                }
                else if ( ((LA22_1>=27 && LA22_1<=34)) ) {
                    alt22=2;
                }
                else {
                    if (backtracking>0) {failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("689:1: ( ( ( ':' ) ( RULE_DOT_ID ) ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )? ) | ( ( ':' ) (temp_compass_pt= rulecompass_pt ) ) )", 22, 1, input);

                    throw nvae;
                }
            }
            else {
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("689:1: ( ( ( ':' ) ( RULE_DOT_ID ) ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )? ) | ( ( ':' ) (temp_compass_pt= rulecompass_pt ) ) )", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:689:2: ( ( ':' ) ( RULE_DOT_ID ) ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )? )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:689:2: ( ( ':' ) ( RULE_DOT_ID ) ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )? )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:689:3: ( ':' ) ( RULE_DOT_ID ) ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )?
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:689:3: ( ':' )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:689:4: ':'
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,20,FOLLOW_20_in_ruleport889); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(11)).eContents().get(1)).eContents().get(0)).eContents().get(0)));
                        ptm.ruleFinished(getLastToken());
                      }
                    }

                    }

                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:695:1: ( RULE_DOT_ID )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:695:2: RULE_DOT_ID
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,RULE_DOT_ID,FOLLOW_RULE_DOT_ID_in_ruleport897); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        Token temp = getLastToken();
                        ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(11)).eContents().get(1)).eContents().get(0)).eContents().get(1)));
                        factory.set(result,"name",convert(temp),false);
                        ptm.ruleFinished(temp);
                      }
                    }

                    }

                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:705:1: ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )?
                    int alt21=2;
                    int LA21_0 = input.LA(1);

                    if ( (LA21_0==20) ) {
                        alt21=1;
                    }
                    switch (alt21) {
                        case 1 :
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:705:2: ( ':' ) (temp_compass_pt= rulecompass_pt )
                            {
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:705:2: ( ':' )
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:705:3: ':'
                            {
                            if ( backtracking==0 ) {
                              skipCurrentToken = false;
                            }
                            match(input,20,FOLLOW_20_in_ruleport906); if (failed) return result;
                            if ( backtracking==0 ) {
                              if (!skipCurrentToken) {
                                hasContent = true;
                                ptm.createNode(((EObject)((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(11)).eContents().get(1)).eContents().get(0)).eContents().get(2)).eContents().get(0)));
                                ptm.ruleFinished(getLastToken());
                              }
                            }

                            }

                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:711:1: (temp_compass_pt= rulecompass_pt )
                            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:711:2: temp_compass_pt= rulecompass_pt
                            {
                            if ( backtracking==0 ) {
                              ptm.createNode(((EObject)((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(11)).eContents().get(1)).eContents().get(0)).eContents().get(2)).eContents().get(1)));
                            }
                            pushFollow(FOLLOW_rulecompass_pt_in_ruleport916);
                            temp_compass_pt=rulecompass_pt();
                            _fsp--;
                            if (failed) return result;
                            if ( backtracking==0 ) {
                              if (temp_compass_pt != null) {
                                hasContent = true;
                                factory.set(result,"compass_pt",convert(temp_compass_pt),false);
                                ptm.ruleFinished(temp_compass_pt);
                              } else {
                                ptm.destroyNode();
                              }

                            }

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:724:1: ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:724:1: ( ( ':' ) (temp_compass_pt= rulecompass_pt ) )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:724:2: ( ':' ) (temp_compass_pt= rulecompass_pt )
                    {
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:724:2: ( ':' )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:724:3: ':'
                    {
                    if ( backtracking==0 ) {
                      skipCurrentToken = false;
                    }
                    match(input,20,FOLLOW_20_in_ruleport932); if (failed) return result;
                    if ( backtracking==0 ) {
                      if (!skipCurrentToken) {
                        hasContent = true;
                        ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(11)).eContents().get(1)).eContents().get(1)).eContents().get(0)));
                        ptm.ruleFinished(getLastToken());
                      }
                    }

                    }

                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:730:1: (temp_compass_pt= rulecompass_pt )
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:730:2: temp_compass_pt= rulecompass_pt
                    {
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(11)).eContents().get(1)).eContents().get(1)).eContents().get(1)));
                    }
                    pushFollow(FOLLOW_rulecompass_pt_in_ruleport942);
                    temp_compass_pt=rulecompass_pt();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      if (temp_compass_pt != null) {
                        hasContent = true;
                        factory.set(result,"compass_pt",convert(temp_compass_pt),false);
                        ptm.ruleFinished(temp_compass_pt);
                      } else {
                        ptm.destroyNode();
                      }

                    }

                    }


                    }


                    }
                    break;

            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 13, ruleport_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleport


    // $ANTLR start ruleedgeRHS
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:749:1: ruleedgeRHS returns [EObject result] : (temp_edgerhs_node= ruleedgeRHS_node | temp_edgerhs_subgraph= ruleedgeRHS_subgraph );
    public EObject ruleedgeRHS() throws RecognitionException {
        EObject result = null;
        int ruleedgeRHS_StartIndex = input.index();
        EObject temp_edgerhs_node = null;

        EObject temp_edgerhs_subgraph = null;


        try {
            if ( backtracking>0 && alreadyParsedRule(input, 14) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:751:9: (temp_edgerhs_node= ruleedgeRHS_node | temp_edgerhs_subgraph= ruleedgeRHS_subgraph )
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==21) ) {
                int LA23_1 = input.LA(2);

                if ( (LA23_1==12||LA23_1==16||LA23_1==19) ) {
                    alt23=2;
                }
                else if ( (LA23_1==RULE_DOT_ID) ) {
                    alt23=1;
                }
                else {
                    if (backtracking>0) {failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("749:1: ruleedgeRHS returns [EObject result] : (temp_edgerhs_node= ruleedgeRHS_node | temp_edgerhs_subgraph= ruleedgeRHS_subgraph );", 23, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA23_0==22) ) {
                int LA23_2 = input.LA(2);

                if ( (LA23_2==12||LA23_2==16||LA23_2==19) ) {
                    alt23=2;
                }
                else if ( (LA23_2==RULE_DOT_ID) ) {
                    alt23=1;
                }
                else {
                    if (backtracking>0) {failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("749:1: ruleedgeRHS returns [EObject result] : (temp_edgerhs_node= ruleedgeRHS_node | temp_edgerhs_subgraph= ruleedgeRHS_subgraph );", 23, 2, input);

                    throw nvae;
                }
            }
            else {
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("749:1: ruleedgeRHS returns [EObject result] : (temp_edgerhs_node= ruleedgeRHS_node | temp_edgerhs_subgraph= ruleedgeRHS_subgraph );", 23, 0, input);

                throw nvae;
            }
            switch (alt23) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:751:9: temp_edgerhs_node= ruleedgeRHS_node
                    {
                    pushFollow(FOLLOW_ruleedgeRHS_node_in_ruleedgeRHS980);
                    temp_edgerhs_node=ruleedgeRHS_node();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      result =temp_edgerhs_node;
                    }

                    }
                    break;
                case 2 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:751:82: temp_edgerhs_subgraph= ruleedgeRHS_subgraph
                    {
                    pushFollow(FOLLOW_ruleedgeRHS_subgraph_in_ruleedgeRHS995);
                    temp_edgerhs_subgraph=ruleedgeRHS_subgraph();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      result =temp_edgerhs_subgraph;
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 14, ruleedgeRHS_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleedgeRHS


    // $ANTLR start ruleedgeRHS_node
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:753:1: ruleedgeRHS_node returns [EObject result] : ( (temp_edgeop= ruleedgeop ) (temp_node_id= rulenode_id ) ) ;
    public EObject ruleedgeRHS_node() throws RecognitionException {
        EObject result = null;
        int ruleedgeRHS_node_StartIndex = input.index();
        Enumerator temp_edgeop = null;

        EObject temp_node_id = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 15) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:756:4: ( ( (temp_edgeop= ruleedgeop ) (temp_node_id= rulenode_id ) ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:756:4: ( (temp_edgeop= ruleedgeop ) (temp_node_id= rulenode_id ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "edgeRHS_node");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:759:1: ( (temp_edgeop= ruleedgeop ) (temp_node_id= rulenode_id ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:759:2: (temp_edgeop= ruleedgeop ) (temp_node_id= rulenode_id )
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:759:2: (temp_edgeop= ruleedgeop )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:759:3: temp_edgeop= ruleedgeop
            {
            if ( backtracking==0 ) {
              ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(13)).eContents().get(1)).eContents().get(0)));
            }
            pushFollow(FOLLOW_ruleedgeop_in_ruleedgeRHS_node1026);
            temp_edgeop=ruleedgeop();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              if (temp_edgeop != null) {
                hasContent = true;
                factory.set(result,"op",convert(temp_edgeop),false);
                ptm.ruleFinished(temp_edgeop);
              } else {
                ptm.destroyNode();
              }

            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:770:1: (temp_node_id= rulenode_id )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:770:2: temp_node_id= rulenode_id
            {
            if ( backtracking==0 ) {
              ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(13)).eContents().get(1)).eContents().get(1)));
            }
            pushFollow(FOLLOW_rulenode_id_in_ruleedgeRHS_node1037);
            temp_node_id=rulenode_id();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              if (temp_node_id != null) {
                hasContent = true;
                ptm.setModelElement(temp_node_id);
                factory.set(result,"node",convert(temp_node_id),false);
                ptm.ruleFinished(temp_node_id);
              } else {
                ptm.destroyNode();
              }

            }

            }


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 15, ruleedgeRHS_node_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleedgeRHS_node


    // $ANTLR start ruleedgeRHS_subgraph
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:789:1: ruleedgeRHS_subgraph returns [EObject result] : ( (temp_edgeop= ruleedgeop ) (temp_subgraph= rulesubgraph ) ) ;
    public EObject ruleedgeRHS_subgraph() throws RecognitionException {
        EObject result = null;
        int ruleedgeRHS_subgraph_StartIndex = input.index();
        Enumerator temp_edgeop = null;

        EObject temp_subgraph = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 16) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:792:4: ( ( (temp_edgeop= ruleedgeop ) (temp_subgraph= rulesubgraph ) ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:792:4: ( (temp_edgeop= ruleedgeop ) (temp_subgraph= rulesubgraph ) )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "edgeRHS_subgraph");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:795:1: ( (temp_edgeop= ruleedgeop ) (temp_subgraph= rulesubgraph ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:795:2: (temp_edgeop= ruleedgeop ) (temp_subgraph= rulesubgraph )
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:795:2: (temp_edgeop= ruleedgeop )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:795:3: temp_edgeop= ruleedgeop
            {
            if ( backtracking==0 ) {
              ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(14)).eContents().get(1)).eContents().get(0)));
            }
            pushFollow(FOLLOW_ruleedgeop_in_ruleedgeRHS_subgraph1079);
            temp_edgeop=ruleedgeop();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              if (temp_edgeop != null) {
                hasContent = true;
                factory.set(result,"op",convert(temp_edgeop),false);
                ptm.ruleFinished(temp_edgeop);
              } else {
                ptm.destroyNode();
              }

            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:806:1: (temp_subgraph= rulesubgraph )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:806:2: temp_subgraph= rulesubgraph
            {
            if ( backtracking==0 ) {
              ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(14)).eContents().get(1)).eContents().get(1)));
            }
            pushFollow(FOLLOW_rulesubgraph_in_ruleedgeRHS_subgraph1090);
            temp_subgraph=rulesubgraph();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              if (temp_subgraph != null) {
                hasContent = true;
                ptm.setModelElement(temp_subgraph);
                factory.set(result,"subgraph",convert(temp_subgraph),false);
                ptm.ruleFinished(temp_subgraph);
              } else {
                ptm.destroyNode();
              }

            }

            }


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 16, ruleedgeRHS_subgraph_StartIndex); }
        }
        return result;
    }
    // $ANTLR end ruleedgeRHS_subgraph


    // $ANTLR start rulenode_id
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:825:1: rulenode_id returns [EObject result] : ( ( RULE_DOT_ID ) (temp_port= ruleport )? ) ;
    public EObject rulenode_id() throws RecognitionException {
        EObject result = null;
        int rulenode_id_StartIndex = input.index();
        EObject temp_port = null;


        boolean hasContent = false;
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 17) ) { return result; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:828:4: ( ( ( RULE_DOT_ID ) (temp_port= ruleport )? ) )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:828:4: ( ( RULE_DOT_ID ) (temp_port= ruleport )? )
            {
            if ( backtracking==0 ) {

              				result = factory.create("", "node_id");
              			 
            }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:831:1: ( ( RULE_DOT_ID ) (temp_port= ruleport )? )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:831:2: ( RULE_DOT_ID ) (temp_port= ruleport )?
            {
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:831:2: ( RULE_DOT_ID )
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:831:3: RULE_DOT_ID
            {
            if ( backtracking==0 ) {
              skipCurrentToken = false;
            }
            match(input,RULE_DOT_ID,FOLLOW_RULE_DOT_ID_in_rulenode_id1130); if (failed) return result;
            if ( backtracking==0 ) {
              if (!skipCurrentToken) {
                hasContent = true;
                Token temp = getLastToken();
                ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(15)).eContents().get(1)).eContents().get(0)));
                factory.set(result,"name",convert(temp),false);
                ptm.ruleFinished(temp);
              }
            }

            }

            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:841:1: (temp_port= ruleport )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==20) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:841:2: temp_port= ruleport
                    {
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(15)).eContents().get(1)).eContents().get(1)));
                    }
                    pushFollow(FOLLOW_ruleport_in_rulenode_id1141);
                    temp_port=ruleport();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      if (temp_port != null) {
                        hasContent = true;
                        ptm.setModelElement(temp_port);
                        factory.set(result,"port",convert(temp_port),false);
                        ptm.ruleFinished(temp_port);
                      } else {
                        ptm.destroyNode();
                      }

                    }

                    }
                    break;

            }


            }

            if ( backtracking==0 ) {
              if (!hasContent)
                result = null;
            }

            }

        }
        catch (RecognitionException re) {
            if (!hasContent)
                result = null;
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 17, rulenode_id_StartIndex); }
        }
        return result;
    }
    // $ANTLR end rulenode_id


    // $ANTLR start ruleedgeop
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:860:1: ruleedgeop returns [Enumerator r] : ( '->' | '--' );
    public Enumerator ruleedgeop() throws RecognitionException {
        Enumerator r = null;
        int ruleedgeop_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 18) ) { return r; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:861:4: ( '->' | '--' )
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==21) ) {
                alt25=1;
            }
            else if ( (LA25_0==22) ) {
                alt25=2;
            }
            else {
                if (backtracking>0) {failed=true; return r;}
                NoViableAltException nvae =
                    new NoViableAltException("860:1: ruleedgeop returns [Enumerator r] : ( '->' | '--' );", 25, 0, input);

                throw nvae;
            }
            switch (alt25) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:861:4: '->'
                    {
                    match(input,21,FOLLOW_21_in_ruleedgeop1171); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(16)).eContents().get(1)));
                      r =factory.enumLit("", "edgeop","directed");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 2 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:867:7: '--'
                    {
                    match(input,22,FOLLOW_22_in_ruleedgeop1184); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(16)).eContents().get(2)));
                      r =factory.enumLit("", "edgeop","undirected");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 18, ruleedgeop_StartIndex); }
        }
        return r;
    }
    // $ANTLR end ruleedgeop


    // $ANTLR start rulegraphtype
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:875:1: rulegraphtype returns [Enumerator r] : ( 'graph' | 'digraph' );
    public Enumerator rulegraphtype() throws RecognitionException {
        Enumerator r = null;
        int rulegraphtype_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 19) ) { return r; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:876:4: ( 'graph' | 'digraph' )
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==23) ) {
                alt26=1;
            }
            else if ( (LA26_0==24) ) {
                alt26=2;
            }
            else {
                if (backtracking>0) {failed=true; return r;}
                NoViableAltException nvae =
                    new NoViableAltException("875:1: rulegraphtype returns [Enumerator r] : ( 'graph' | 'digraph' );", 26, 0, input);

                throw nvae;
            }
            switch (alt26) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:876:4: 'graph'
                    {
                    match(input,23,FOLLOW_23_in_rulegraphtype1205); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(17)).eContents().get(1)));
                      r =factory.enumLit("", "graphtype","graph");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 2 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:882:7: 'digraph'
                    {
                    match(input,24,FOLLOW_24_in_rulegraphtype1218); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(17)).eContents().get(2)));
                      r =factory.enumLit("", "graphtype","digraph");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 19, rulegraphtype_StartIndex); }
        }
        return r;
    }
    // $ANTLR end rulegraphtype


    // $ANTLR start ruleattributetype
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:890:1: ruleattributetype returns [Enumerator r] : ( 'graph' | 'node' | 'edge' );
    public Enumerator ruleattributetype() throws RecognitionException {
        Enumerator r = null;
        int ruleattributetype_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 20) ) { return r; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:891:4: ( 'graph' | 'node' | 'edge' )
            int alt27=3;
            switch ( input.LA(1) ) {
            case 23:
                {
                alt27=1;
                }
                break;
            case 25:
                {
                alt27=2;
                }
                break;
            case 26:
                {
                alt27=3;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return r;}
                NoViableAltException nvae =
                    new NoViableAltException("890:1: ruleattributetype returns [Enumerator r] : ( 'graph' | 'node' | 'edge' );", 27, 0, input);

                throw nvae;
            }

            switch (alt27) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:891:4: 'graph'
                    {
                    match(input,23,FOLLOW_23_in_ruleattributetype1239); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(18)).eContents().get(1)));
                      r =factory.enumLit("", "attributetype","graph");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 2 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:897:7: 'node'
                    {
                    match(input,25,FOLLOW_25_in_ruleattributetype1252); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(18)).eContents().get(2)));
                      r =factory.enumLit("", "attributetype","node");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 3 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:903:7: 'edge'
                    {
                    match(input,26,FOLLOW_26_in_ruleattributetype1265); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(18)).eContents().get(3)));
                      r =factory.enumLit("", "attributetype","edge");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 20, ruleattributetype_StartIndex); }
        }
        return r;
    }
    // $ANTLR end ruleattributetype


    // $ANTLR start rulecompass_pt
    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:911:1: rulecompass_pt returns [Enumerator r] : ( 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w' | 'nw' );
    public Enumerator rulecompass_pt() throws RecognitionException {
        Enumerator r = null;
        int rulecompass_pt_StartIndex = input.index();
        try {
            if ( backtracking>0 && alreadyParsedRule(input, 21) ) { return r; }
            // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:912:4: ( 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w' | 'nw' )
            int alt28=8;
            switch ( input.LA(1) ) {
            case 27:
                {
                alt28=1;
                }
                break;
            case 28:
                {
                alt28=2;
                }
                break;
            case 29:
                {
                alt28=3;
                }
                break;
            case 30:
                {
                alt28=4;
                }
                break;
            case 31:
                {
                alt28=5;
                }
                break;
            case 32:
                {
                alt28=6;
                }
                break;
            case 33:
                {
                alt28=7;
                }
                break;
            case 34:
                {
                alt28=8;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return r;}
                NoViableAltException nvae =
                    new NoViableAltException("911:1: rulecompass_pt returns [Enumerator r] : ( 'n' | 'ne' | 'e' | 'se' | 's' | 'sw' | 'w' | 'nw' );", 28, 0, input);

                throw nvae;
            }

            switch (alt28) {
                case 1 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:912:4: 'n'
                    {
                    match(input,27,FOLLOW_27_in_rulecompass_pt1286); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(19)).eContents().get(1)));
                      r =factory.enumLit("", "compass_pt","north");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 2 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:918:7: 'ne'
                    {
                    match(input,28,FOLLOW_28_in_rulecompass_pt1299); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(19)).eContents().get(2)));
                      r =factory.enumLit("", "compass_pt","northeast");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 3 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:924:7: 'e'
                    {
                    match(input,29,FOLLOW_29_in_rulecompass_pt1312); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(19)).eContents().get(3)));
                      r =factory.enumLit("", "compass_pt","east");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 4 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:930:7: 'se'
                    {
                    match(input,30,FOLLOW_30_in_rulecompass_pt1325); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(19)).eContents().get(4)));
                      r =factory.enumLit("", "compass_pt","southeast");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 5 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:936:7: 's'
                    {
                    match(input,31,FOLLOW_31_in_rulecompass_pt1338); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(19)).eContents().get(5)));
                      r =factory.enumLit("", "compass_pt","south");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 6 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:942:7: 'sw'
                    {
                    match(input,32,FOLLOW_32_in_rulecompass_pt1351); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(19)).eContents().get(6)));
                      r =factory.enumLit("", "compass_pt","southwest");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 7 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:948:7: 'w'
                    {
                    match(input,33,FOLLOW_33_in_rulecompass_pt1364); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(19)).eContents().get(7)));
                      r =factory.enumLit("", "compass_pt","west");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;
                case 8 :
                    // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:954:7: 'nw'
                    {
                    match(input,34,FOLLOW_34_in_rulecompass_pt1377); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.createNode(((EObject)((EObject)xtextfile.eContents().get(19)).eContents().get(8)));
                      r =factory.enumLit("", "compass_pt","northwest");
                      ptm.setModelElement(r);
                      ptm.ruleFinished(getLastToken());

                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
            if ( backtracking>0 ) { memoize(input, 21, rulecompass_pt_StartIndex); }
        }
        return r;
    }
    // $ANTLR end rulecompass_pt

    // $ANTLR start synpred6
    public void synpred6_fragment() throws RecognitionException {   
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:3: ( ( ruleedge_stmt_node ) )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:3: ( ruleedge_stmt_node )
        {
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:3: ( ruleedge_stmt_node )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:222:4: ruleedge_stmt_node
        {
        if ( backtracking==0 ) {
          ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(0)));
        }
        pushFollow(FOLLOW_ruleedge_stmt_node_in_synpred6248);
        ruleedge_stmt_node();
        _fsp--;
        if (failed) return ;

        }


        }
    }
    // $ANTLR end synpred6

    // $ANTLR start synpred7
    public void synpred7_fragment() throws RecognitionException {   
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:235:1: ( ( ruleedge_stmt_subgraph ) )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:235:1: ( ruleedge_stmt_subgraph )
        {
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:235:1: ( ruleedge_stmt_subgraph )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:235:2: ruleedge_stmt_subgraph
        {
        if ( backtracking==0 ) {
          ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(1)));
        }
        pushFollow(FOLLOW_ruleedge_stmt_subgraph_in_synpred7262);
        ruleedge_stmt_subgraph();
        _fsp--;
        if (failed) return ;

        }


        }
    }
    // $ANTLR end synpred7

    // $ANTLR start synpred8
    public void synpred8_fragment() throws RecognitionException {   
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:248:1: ( ( rulenode_stmt ) )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:248:1: ( rulenode_stmt )
        {
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:248:1: ( rulenode_stmt )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:248:2: rulenode_stmt
        {
        if ( backtracking==0 ) {
          ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(2)));
        }
        pushFollow(FOLLOW_rulenode_stmt_in_synpred8276);
        rulenode_stmt();
        _fsp--;
        if (failed) return ;

        }


        }
    }
    // $ANTLR end synpred8

    // $ANTLR start synpred9
    public void synpred9_fragment() throws RecognitionException {   
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:261:1: ( ( ruleattribute ) )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:261:1: ( ruleattribute )
        {
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:261:1: ( ruleattribute )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:261:2: ruleattribute
        {
        if ( backtracking==0 ) {
          ptm.createNode(((EObject)((EObject)((EObject)((EObject)xtextfile.eContents().get(2)).eContents().get(1)).eContents().get(0)).eContents().get(3)));
        }
        pushFollow(FOLLOW_ruleattribute_in_synpred9290);
        ruleattribute();
        _fsp--;
        if (failed) return ;

        }


        }
    }
    // $ANTLR end synpred9

    // $ANTLR start synpred13
    public void synpred13_fragment() throws RecognitionException {   
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:344:2: ( ruleattr_list )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:344:2: ruleattr_list
        {
        if ( backtracking==0 ) {
          ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(3)).eContents().get(1)).eContents().get(2)));
        }
        pushFollow(FOLLOW_ruleattr_list_in_synpred13394);
        ruleattr_list();
        _fsp--;
        if (failed) return ;

        }
    }
    // $ANTLR end synpred13

    // $ANTLR start synpred15
    public void synpred15_fragment() throws RecognitionException {   
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:393:2: ( ruleattr_list )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:393:2: ruleattr_list
        {
        if ( backtracking==0 ) {
          ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(4)).eContents().get(1)).eContents().get(2)));
        }
        pushFollow(FOLLOW_ruleattr_list_in_synpred15460);
        ruleattr_list();
        _fsp--;
        if (failed) return ;

        }
    }
    // $ANTLR end synpred15

    // $ANTLR start synpred17
    public void synpred17_fragment() throws RecognitionException {   
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:440:2: ( ruleattr_list )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:440:2: ruleattr_list
        {
        if ( backtracking==0 ) {
          ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(5)).eContents().get(1)).eContents().get(2)));
        }
        pushFollow(FOLLOW_ruleattr_list_in_synpred17524);
        ruleattr_list();
        _fsp--;
        if (failed) return ;

        }
    }
    // $ANTLR end synpred17

    // $ANTLR start synpred18
    public void synpred18_fragment() throws RecognitionException {   
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:515:2: ( ruleattr_list )
        // ..//org.openarchitectureware.graphviz/_src-gen/org/openarchitectureware/graphviz/parser/dot.g:515:2: ruleattr_list
        {
        if ( backtracking==0 ) {
          ptm.createNode(((EObject)((EObject)((EObject)xtextfile.eContents().get(7)).eContents().get(1)).eContents().get(1)));
        }
        pushFollow(FOLLOW_ruleattr_list_in_synpred18634);
        ruleattr_list();
        _fsp--;
        if (failed) return ;

        }
    }
    // $ANTLR end synpred18

    public final boolean synpred9() {
        backtracking++;
        int start = input.mark();
        try {
            synpred9_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !failed;
        input.rewind(start);
        backtracking--;
        failed=false;
        return success;
    }
    public final boolean synpred18() {
        backtracking++;
        int start = input.mark();
        try {
            synpred18_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !failed;
        input.rewind(start);
        backtracking--;
        failed=false;
        return success;
    }
    public final boolean synpred7() {
        backtracking++;
        int start = input.mark();
        try {
            synpred7_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !failed;
        input.rewind(start);
        backtracking--;
        failed=false;
        return success;
    }
    public final boolean synpred17() {
        backtracking++;
        int start = input.mark();
        try {
            synpred17_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !failed;
        input.rewind(start);
        backtracking--;
        failed=false;
        return success;
    }
    public final boolean synpred6() {
        backtracking++;
        int start = input.mark();
        try {
            synpred6_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !failed;
        input.rewind(start);
        backtracking--;
        failed=false;
        return success;
    }
    public final boolean synpred15() {
        backtracking++;
        int start = input.mark();
        try {
            synpred15_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !failed;
        input.rewind(start);
        backtracking--;
        failed=false;
        return success;
    }
    public final boolean synpred8() {
        backtracking++;
        int start = input.mark();
        try {
            synpred8_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !failed;
        input.rewind(start);
        backtracking--;
        failed=false;
        return success;
    }
    public final boolean synpred13() {
        backtracking++;
        int start = input.mark();
        try {
            synpred13_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !failed;
        input.rewind(start);
        backtracking--;
        failed=false;
        return success;
    }


    protected DFA9 dfa9 = new DFA9(this);
    protected DFA11 dfa11 = new DFA11(this);
    protected DFA13 dfa13 = new DFA13(this);
    protected DFA14 dfa14 = new DFA14(this);
    static final String DFA9_eotS =
        "\11\uffff";
    static final String DFA9_eofS =
        "\1\1\10\uffff";
    static final String DFA9_minS =
        "\1\4\1\uffff\2\4\1\0\2\4\1\uffff\1\4";
    static final String DFA9_maxS =
        "\1\32\1\uffff\1\21\1\22\1\0\1\4\1\21\1\uffff\1\22";
    static final String DFA9_acceptS =
        "\1\uffff\1\2\5\uffff\1\1\1\uffff";
    static final String DFA9_specialS =
        "\4\uffff\1\0\4\uffff}>";
    static final String[] DFA9_transitionS = {
            "\1\1\7\uffff\3\1\1\uffff\1\2\2\uffff\1\1\3\uffff\1\1\1\uffff"+
            "\2\1",
            "",
            "\1\3\14\uffff\1\4",
            "\1\3\12\uffff\1\5\1\uffff\1\4\1\6",
            "\1\uffff",
            "\1\10",
            "\1\3\14\uffff\1\4",
            "",
            "\1\3\14\uffff\1\4\1\6"
    };

    static final short[] DFA9_eot = DFA.unpackEncodedString(DFA9_eotS);
    static final short[] DFA9_eof = DFA.unpackEncodedString(DFA9_eofS);
    static final char[] DFA9_min = DFA.unpackEncodedStringToUnsignedChars(DFA9_minS);
    static final char[] DFA9_max = DFA.unpackEncodedStringToUnsignedChars(DFA9_maxS);
    static final short[] DFA9_accept = DFA.unpackEncodedString(DFA9_acceptS);
    static final short[] DFA9_special = DFA.unpackEncodedString(DFA9_specialS);
    static final short[][] DFA9_transition;

    static {
        int numStates = DFA9_transitionS.length;
        DFA9_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA9_transition[i] = DFA.unpackEncodedString(DFA9_transitionS[i]);
        }
    }

    class DFA9 extends DFA {

        public DFA9(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 9;
            this.eot = DFA9_eot;
            this.eof = DFA9_eof;
            this.min = DFA9_min;
            this.max = DFA9_max;
            this.accept = DFA9_accept;
            this.special = DFA9_special;
            this.transition = DFA9_transition;
        }
        public String getDescription() {
            return "()* loopback of 344:1: (temp_attr_list= ruleattr_list )*";
        }
        public int specialStateTransition(int s, IntStream input) throws NoViableAltException {
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA9_4 = input.LA(1);

                         
                        int index9_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred13()) ) {s = 7;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index9_4);
                        if ( s>=0 ) return s;
                        break;
            }
            if (backtracking>0) {failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 9, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA11_eotS =
        "\11\uffff";
    static final String DFA11_eofS =
        "\1\1\10\uffff";
    static final String DFA11_minS =
        "\1\4\1\uffff\2\4\1\0\2\4\1\uffff\1\4";
    static final String DFA11_maxS =
        "\1\32\1\uffff\1\21\1\22\1\0\1\4\1\21\1\uffff\1\22";
    static final String DFA11_acceptS =
        "\1\uffff\1\2\5\uffff\1\1\1\uffff";
    static final String DFA11_specialS =
        "\4\uffff\1\0\4\uffff}>";
    static final String[] DFA11_transitionS = {
            "\1\1\7\uffff\3\1\1\uffff\1\2\2\uffff\1\1\3\uffff\1\1\1\uffff"+
            "\2\1",
            "",
            "\1\3\14\uffff\1\4",
            "\1\3\12\uffff\1\5\1\uffff\1\4\1\6",
            "\1\uffff",
            "\1\10",
            "\1\3\14\uffff\1\4",
            "",
            "\1\3\14\uffff\1\4\1\6"
    };

    static final short[] DFA11_eot = DFA.unpackEncodedString(DFA11_eotS);
    static final short[] DFA11_eof = DFA.unpackEncodedString(DFA11_eofS);
    static final char[] DFA11_min = DFA.unpackEncodedStringToUnsignedChars(DFA11_minS);
    static final char[] DFA11_max = DFA.unpackEncodedStringToUnsignedChars(DFA11_maxS);
    static final short[] DFA11_accept = DFA.unpackEncodedString(DFA11_acceptS);
    static final short[] DFA11_special = DFA.unpackEncodedString(DFA11_specialS);
    static final short[][] DFA11_transition;

    static {
        int numStates = DFA11_transitionS.length;
        DFA11_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA11_transition[i] = DFA.unpackEncodedString(DFA11_transitionS[i]);
        }
    }

    class DFA11 extends DFA {

        public DFA11(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 11;
            this.eot = DFA11_eot;
            this.eof = DFA11_eof;
            this.min = DFA11_min;
            this.max = DFA11_max;
            this.accept = DFA11_accept;
            this.special = DFA11_special;
            this.transition = DFA11_transition;
        }
        public String getDescription() {
            return "()* loopback of 393:1: (temp_attr_list= ruleattr_list )*";
        }
        public int specialStateTransition(int s, IntStream input) throws NoViableAltException {
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA11_4 = input.LA(1);

                         
                        int index11_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred15()) ) {s = 7;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index11_4);
                        if ( s>=0 ) return s;
                        break;
            }
            if (backtracking>0) {failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 11, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA13_eotS =
        "\11\uffff";
    static final String DFA13_eofS =
        "\1\1\10\uffff";
    static final String DFA13_minS =
        "\1\4\1\uffff\2\4\1\0\2\4\1\uffff\1\4";
    static final String DFA13_maxS =
        "\1\32\1\uffff\1\21\1\22\1\0\1\4\1\21\1\uffff\1\22";
    static final String DFA13_acceptS =
        "\1\uffff\1\2\5\uffff\1\1\1\uffff";
    static final String DFA13_specialS =
        "\4\uffff\1\0\4\uffff}>";
    static final String[] DFA13_transitionS = {
            "\1\1\7\uffff\3\1\1\uffff\1\2\2\uffff\1\1\3\uffff\1\1\1\uffff"+
            "\2\1",
            "",
            "\1\3\14\uffff\1\4",
            "\1\3\12\uffff\1\5\1\uffff\1\4\1\6",
            "\1\uffff",
            "\1\10",
            "\1\3\14\uffff\1\4",
            "",
            "\1\3\14\uffff\1\4\1\6"
    };

    static final short[] DFA13_eot = DFA.unpackEncodedString(DFA13_eotS);
    static final short[] DFA13_eof = DFA.unpackEncodedString(DFA13_eofS);
    static final char[] DFA13_min = DFA.unpackEncodedStringToUnsignedChars(DFA13_minS);
    static final char[] DFA13_max = DFA.unpackEncodedStringToUnsignedChars(DFA13_maxS);
    static final short[] DFA13_accept = DFA.unpackEncodedString(DFA13_acceptS);
    static final short[] DFA13_special = DFA.unpackEncodedString(DFA13_specialS);
    static final short[][] DFA13_transition;

    static {
        int numStates = DFA13_transitionS.length;
        DFA13_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA13_transition[i] = DFA.unpackEncodedString(DFA13_transitionS[i]);
        }
    }

    class DFA13 extends DFA {

        public DFA13(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 13;
            this.eot = DFA13_eot;
            this.eof = DFA13_eof;
            this.min = DFA13_min;
            this.max = DFA13_max;
            this.accept = DFA13_accept;
            this.special = DFA13_special;
            this.transition = DFA13_transition;
        }
        public String getDescription() {
            return "()* loopback of 440:1: (temp_attr_list= ruleattr_list )*";
        }
        public int specialStateTransition(int s, IntStream input) throws NoViableAltException {
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA13_4 = input.LA(1);

                         
                        int index13_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred17()) ) {s = 7;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index13_4);
                        if ( s>=0 ) return s;
                        break;
            }
            if (backtracking>0) {failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 13, _s, input);
            error(nvae);
            throw nvae;
        }
    }
    static final String DFA14_eotS =
        "\11\uffff";
    static final String DFA14_eofS =
        "\1\1\10\uffff";
    static final String DFA14_minS =
        "\1\4\1\uffff\2\4\1\0\2\4\1\uffff\1\4";
    static final String DFA14_maxS =
        "\1\32\1\uffff\1\21\1\22\1\0\1\4\1\21\1\uffff\1\22";
    static final String DFA14_acceptS =
        "\1\uffff\1\2\5\uffff\1\1\1\uffff";
    static final String DFA14_specialS =
        "\4\uffff\1\0\4\uffff}>";
    static final String[] DFA14_transitionS = {
            "\1\1\7\uffff\3\1\1\uffff\1\2\2\uffff\1\1\3\uffff\1\1\1\uffff"+
            "\2\1",
            "",
            "\1\3\14\uffff\1\4",
            "\1\3\12\uffff\1\5\1\uffff\1\4\1\6",
            "\1\uffff",
            "\1\10",
            "\1\3\14\uffff\1\4",
            "",
            "\1\3\14\uffff\1\4\1\6"
    };

    static final short[] DFA14_eot = DFA.unpackEncodedString(DFA14_eotS);
    static final short[] DFA14_eof = DFA.unpackEncodedString(DFA14_eofS);
    static final char[] DFA14_min = DFA.unpackEncodedStringToUnsignedChars(DFA14_minS);
    static final char[] DFA14_max = DFA.unpackEncodedStringToUnsignedChars(DFA14_maxS);
    static final short[] DFA14_accept = DFA.unpackEncodedString(DFA14_acceptS);
    static final short[] DFA14_special = DFA.unpackEncodedString(DFA14_specialS);
    static final short[][] DFA14_transition;

    static {
        int numStates = DFA14_transitionS.length;
        DFA14_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA14_transition[i] = DFA.unpackEncodedString(DFA14_transitionS[i]);
        }
    }

    class DFA14 extends DFA {

        public DFA14(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 14;
            this.eot = DFA14_eot;
            this.eof = DFA14_eof;
            this.min = DFA14_min;
            this.max = DFA14_max;
            this.accept = DFA14_accept;
            this.special = DFA14_special;
            this.transition = DFA14_transition;
        }
        public String getDescription() {
            return "()+ loopback of 515:1: (temp_attr_list= ruleattr_list )+";
        }
        public int specialStateTransition(int s, IntStream input) throws NoViableAltException {
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA14_4 = input.LA(1);

                         
                        int index14_4 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred18()) ) {s = 7;}

                        else if ( (true) ) {s = 1;}

                         
                        input.seek(index14_4);
                        if ( s>=0 ) return s;
                        break;
            }
            if (backtracking>0) {failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 14, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

    public static final BitSet FOLLOW_rulegraphvizmodel_in_parse67 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_parse78 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulegraph_in_rulegraphvizmodel106 = new BitSet(new long[]{0x0000000001800802L});
    public static final BitSet FOLLOW_11_in_rulegraph145 = new BitSet(new long[]{0x0000000001800000L});
    public static final BitSet FOLLOW_rulegraphtype_in_rulegraph157 = new BitSet(new long[]{0x0000000000011010L});
    public static final BitSet FOLLOW_RULE_DOT_ID_in_rulegraph166 = new BitSet(new long[]{0x0000000000011000L});
    public static final BitSet FOLLOW_ruleattr_list_in_rulegraph178 = new BitSet(new long[]{0x0000000000011000L});
    public static final BitSet FOLLOW_12_in_rulegraph187 = new BitSet(new long[]{0x0000000006893010L});
    public static final BitSet FOLLOW_rulestmt_in_rulegraph197 = new BitSet(new long[]{0x0000000006893010L});
    public static final BitSet FOLLOW_13_in_rulegraph206 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleedge_stmt_node_in_rulestmt248 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_ruleedge_stmt_subgraph_in_rulestmt262 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_rulenode_stmt_in_rulestmt276 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_ruleattribute_in_rulestmt290 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_ruleattr_stmt_in_rulestmt304 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_rulesubgraph_in_rulestmt318 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_14_in_rulestmt329 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulenode_id_in_ruleedge_stmt_node371 = new BitSet(new long[]{0x0000000000600000L});
    public static final BitSet FOLLOW_ruleedgeRHS_in_ruleedge_stmt_node382 = new BitSet(new long[]{0x0000000000610002L});
    public static final BitSet FOLLOW_ruleattr_list_in_ruleedge_stmt_node394 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_rulesubgraph_in_ruleedge_stmt_subgraph437 = new BitSet(new long[]{0x0000000000600000L});
    public static final BitSet FOLLOW_ruleedgeRHS_in_ruleedge_stmt_subgraph448 = new BitSet(new long[]{0x0000000000610002L});
    public static final BitSet FOLLOW_ruleattr_list_in_ruleedge_stmt_subgraph460 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_RULE_DOT_ID_in_rulenode_stmt501 = new BitSet(new long[]{0x0000000000110002L});
    public static final BitSet FOLLOW_ruleport_in_rulenode_stmt512 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_ruleattr_list_in_rulenode_stmt524 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_RULE_DOT_ID_in_ruleattribute565 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_15_in_ruleattribute573 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_DOT_ID_in_ruleattribute581 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleattributetype_in_ruleattr_stmt623 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_ruleattr_list_in_ruleattr_stmt634 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_16_in_ruleattr_list674 = new BitSet(new long[]{0x0000000000020010L});
    public static final BitSet FOLLOW_rulea_list_in_ruleattr_list684 = new BitSet(new long[]{0x0000000000020010L});
    public static final BitSet FOLLOW_17_in_ruleattr_list693 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_DOT_ID_in_rulea_list732 = new BitSet(new long[]{0x0000000000048002L});
    public static final BitSet FOLLOW_15_in_rulea_list741 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_DOT_ID_in_rulea_list749 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_18_in_rulea_list760 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rulesubgraph800 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_DOT_ID_in_rulesubgraph808 = new BitSet(new long[]{0x0000000000011000L});
    public static final BitSet FOLLOW_ruleattr_list_in_rulesubgraph822 = new BitSet(new long[]{0x0000000000011000L});
    public static final BitSet FOLLOW_12_in_rulesubgraph831 = new BitSet(new long[]{0x0000000006893010L});
    public static final BitSet FOLLOW_rulestmt_in_rulesubgraph841 = new BitSet(new long[]{0x0000000006893010L});
    public static final BitSet FOLLOW_13_in_rulesubgraph850 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_ruleport889 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_DOT_ID_in_ruleport897 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_20_in_ruleport906 = new BitSet(new long[]{0x00000007F8000000L});
    public static final BitSet FOLLOW_rulecompass_pt_in_ruleport916 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_ruleport932 = new BitSet(new long[]{0x00000007F8000000L});
    public static final BitSet FOLLOW_rulecompass_pt_in_ruleport942 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleedgeRHS_node_in_ruleedgeRHS980 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleedgeRHS_subgraph_in_ruleedgeRHS995 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleedgeop_in_ruleedgeRHS_node1026 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rulenode_id_in_ruleedgeRHS_node1037 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleedgeop_in_ruleedgeRHS_subgraph1079 = new BitSet(new long[]{0x0000000000091000L});
    public static final BitSet FOLLOW_rulesubgraph_in_ruleedgeRHS_subgraph1090 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_DOT_ID_in_rulenode_id1130 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_ruleport_in_rulenode_id1141 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_ruleedgeop1171 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_ruleedgeop1184 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_rulegraphtype1205 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_rulegraphtype1218 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_ruleattributetype1239 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_ruleattributetype1252 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_ruleattributetype1265 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_rulecompass_pt1286 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_28_in_rulecompass_pt1299 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_rulecompass_pt1312 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_rulecompass_pt1325 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_rulecompass_pt1338 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_rulecompass_pt1351 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_rulecompass_pt1364 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_rulecompass_pt1377 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleedge_stmt_node_in_synpred6248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleedge_stmt_subgraph_in_synpred7262 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulenode_stmt_in_synpred8276 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleattribute_in_synpred9290 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleattr_list_in_synpred13394 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleattr_list_in_synpred15460 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleattr_list_in_synpred17524 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleattr_list_in_synpred18634 = new BitSet(new long[]{0x0000000000000002L});

}