package de.genesez.example.java.BankTutorial.Server.businessLogic;

/* 
 *	Do not place import/include statements above this comment, just below. 
 * 	@FILE-ID : (_16_0_129203bc_1271100068781_566546_717) 
 */

/**
 * An AccountSelectionException is thrown if a problem occurs with the selection of an account
 * @author apflueger
 */

public class AccountSelectionException extends RuntimeException {
	
	// -- generated code of other cartridges --------------------------------
	
	// -- own code implementation -------------------------------------------
	/* PROTECTED REGION ID(java.class.own.code.implementation._16_0_129203bc_1271100068781_566546_717) ENABLED START */
	// TODO: put your own implementation code here
	/* PROTECTED REGION END */
	
}
