/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.actions;

import org.eclipse.jdt.ui.actions.IJavaEditorActionDefinitionIds;
import org.eclipse.search.ui.ISearchQuery;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;
import org.openarchitectureware.xtext.parser.parsetree.Node;
import org.openarchitectureware.xtext.search.AbstractSearchAction;
import org.openarchitectureware.xtext.search.XtextSearchQuery;

public class FindReferencesInWorkspaceAction extends AbstractSearchAction {
	private AbstractXtextEditor editor;

	public FindReferencesInWorkspaceAction(AbstractXtextEditor editor) {
		setActionDefinitionId(IJavaEditorActionDefinitionIds.SEARCH_REFERENCES_IN_WORKSPACE);
		setText("In Workspace");
		this.editor = editor;
	}

	@Override
	protected ISearchQuery createSearchQuery() {
		if (editor != null) {
			Node node = editor.getCurrentNode();
			if ((node != null) && (node.getToken() != null))
				return new XtextSearchQuery(editor.getPlugin().getUtilities(),
						XtextSearchQuery.REFERENCE_SEARCH, node);
		}
		return null;
	}
}
