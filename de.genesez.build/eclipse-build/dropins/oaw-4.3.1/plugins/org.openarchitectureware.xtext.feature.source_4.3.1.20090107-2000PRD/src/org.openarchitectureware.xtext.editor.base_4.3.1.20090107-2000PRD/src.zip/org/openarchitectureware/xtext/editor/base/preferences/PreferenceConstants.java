package org.openarchitectureware.xtext.editor.base.preferences;

/**
 * Constant definitions for plug-in preferences
 */
public class PreferenceConstants {

	public static final String CHECK_STRATEGY = "xtextCheckStrategy";
	public static String CHECK_STRATEGY_ON_KEYSTROKE = "Always";
	public static String CHECK_STRATEGY_ON_SAVE_ONLY = "OnSaveOnly";
	
	public static final String SYNC_CHECK_STRATEGY = "xtextSyncStrategy";

}
