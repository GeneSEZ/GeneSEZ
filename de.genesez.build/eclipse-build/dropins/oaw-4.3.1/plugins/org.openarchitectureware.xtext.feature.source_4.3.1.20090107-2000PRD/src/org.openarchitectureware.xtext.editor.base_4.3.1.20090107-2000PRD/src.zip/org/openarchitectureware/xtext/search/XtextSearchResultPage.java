/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.search;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.search.ui.text.AbstractTextSearchViewPage;
import org.eclipse.search.ui.text.Match;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.ide.IDE;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;

public class XtextSearchResultPage extends AbstractTextSearchViewPage {

	private ContentProvider contentProvider;

	class ContentProvider implements IStructuredContentProvider {

		private TableViewer viewer;
		private XtextSearchResult input;

		public Object[] getElements(Object inputElement) {
			if (input != null) {
				return input.getElements();
			}
			return new Object[0];
		}

		public void dispose() {
		}

		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
			this.viewer = (TableViewer) viewer;
			this.input = (XtextSearchResult) newInput;
		}

		public void elementsChanged(Object[] objects) {
			for (int i = 0; i < objects.length; i++) {
				if (input.getMatchCount(objects[i]) > 0) {
					if (viewer.testFindItem(objects[i]) != null)
						viewer.refresh(objects[i]);
					else
						viewer.add(objects[i]);
				} else {
					viewer.remove(objects[i]);
				}
			}
		}

	}

	public XtextSearchResultPage() {
		// tree mode notsupported
		super(AbstractTextSearchViewPage.FLAG_LAYOUT_FLAT);
	}

	@Override
	protected void clear() {
		getViewer().refresh();
	}

	@Override
	protected void configureTableViewer(TableViewer viewer) {
		contentProvider = new ContentProvider();
		viewer.setContentProvider(contentProvider);
		viewer.setLabelProvider(new LabelProvider() {
			@Override
			public Image getImage(Object element) {
				if (isValidMatch(element)
						&& asXtextMatch(element).getImage() != null) {
					return asXtextMatch(element).getImage();
				}
				return super.getImage(element);
			}

			@Override
			public String getText(Object element) {
				if (isValidMatch(element)) {
					return asXtextMatch(element).getSearchString() + " - "
							+ asXtextMatch(element).getFile().getFullPath() + " (line: "+ asXtextMatch(element).getLine()+")";
				}
				return super.getText(element);
			}

			private boolean isValidMatch(Object element) {
				return element instanceof XtextSearchMatch
						&& asXtextMatch(element).getFile() != null
						&& asXtextMatch(element).getSearchString() != null;
			}

			private XtextSearchMatch asXtextMatch(Object o) {
				return (XtextSearchMatch) o;
			}
		});
	}

	@Override
	protected void configureTreeViewer(TreeViewer viewer) {
		throw new IllegalStateException("Tree mode not supported!");
	}

	@Override
	protected void elementsChanged(Object[] objects) {
		if (contentProvider != null && contentProvider.input != null)
			contentProvider.elementsChanged(objects);

	}

	@Override
	protected void showMatch(Match match, int currentOffset, int currentLength,
			boolean activate) throws PartInitException {
		if (match.getElement() instanceof XtextSearchMatch) {
			XtextSearchMatch xtMatch = (XtextSearchMatch) match.getElement();
			if (xtMatch != null && xtMatch.getFile() != null) {

				AbstractXtextEditor editor = (AbstractXtextEditor) IDE
						.openEditor(getSite().getPage(), xtMatch.getFile(),
								activate);
				if (editor != null) {
					editor.setHighlightRange(currentOffset, currentLength,true);
				}
			}
		}
	}
}
