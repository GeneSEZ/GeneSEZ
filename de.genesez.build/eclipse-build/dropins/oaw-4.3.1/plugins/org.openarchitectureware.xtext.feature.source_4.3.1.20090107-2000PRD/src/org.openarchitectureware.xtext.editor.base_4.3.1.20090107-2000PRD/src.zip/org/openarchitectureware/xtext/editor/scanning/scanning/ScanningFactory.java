/**
 * <copyright>
 * </copyright>
 *
 * $Id: ScanningFactory.java,v 1.2 2008/12/23 21:53:44 pschoenb Exp $
 */
package org.openarchitectureware.xtext.editor.scanning.scanning;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.editor.scanning.scanning.ScanningPackage
 * @generated
 */
public interface ScanningFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ScanningFactory eINSTANCE = org.openarchitectureware.xtext.editor.scanning.scanning.impl.ScanningFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Font Style</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Font Style</em>'.
	 * @generated
	 */
	FontStyle createFontStyle();

	/**
	 * Returns a new object of class '<em>Color</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Color</em>'.
	 * @generated
	 */
	Color createColor();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ScanningPackage getScanningPackage();

} //ScanningFactory
