/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.editor;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Vector;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.IJobChangeEvent;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.core.runtime.jobs.JobChangeAdapter;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.ui.actions.JdtActionConstants;
import org.eclipse.jface.action.GroupMarker;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextListener;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.IVerticalRuler;
import org.eclipse.jface.text.source.projection.ProjectionAnnotationModel;
import org.eclipse.jface.text.source.projection.ProjectionSupport;
import org.eclipse.jface.text.source.projection.ProjectionViewer;
import org.eclipse.jface.viewers.IPostSelectionProvider;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.contexts.IContextActivation;
import org.eclipse.ui.contexts.IContextService;
import org.eclipse.ui.editors.text.TextEditor;
import org.eclipse.ui.texteditor.IDocumentProvider;
import org.eclipse.ui.texteditor.ITextEditorActionConstants;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.SourceViewerDecorationSupport;
import org.eclipse.ui.texteditor.TextOperationAction;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;
import org.openarchitectureware.xtext.AbstractXtextEditorPlugin;
import org.openarchitectureware.xtext.BaseEditorPlugin;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.builder.XtextNature;
import org.openarchitectureware.xtext.editor.actions.FindReferencesInWorkspaceAction;
import org.openarchitectureware.xtext.editor.actions.FormatAction;
import org.openarchitectureware.xtext.editor.actions.IXtextEditorActionDefinitionIds;
import org.openarchitectureware.xtext.editor.actions.OpenDeclarationAction;
import org.openarchitectureware.xtext.editor.actions.OpenTypeHierarchyAction;
import org.openarchitectureware.xtext.editor.actions.ToggleCommentAction;
import org.openarchitectureware.xtext.editor.base.preferences.PreferenceConstants;
import org.openarchitectureware.xtext.editor.color.ColorProvider;
import org.openarchitectureware.xtext.editor.marker.MarkerManager;
import org.openarchitectureware.xtext.editor.marker.MarkerManager.MarkerDeletionStrategy;
import org.openarchitectureware.xtext.editor.outline.XtextContentOutlinePage;
import org.openarchitectureware.xtext.editor.scanning.StyleConstants;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;
import org.openarchitectureware.xtext.registry.JdtClasspathUriResolver;
import org.openarchitectureware.xtext.registry.XtextResourceSet;
import org.openarchitectureware.xtext.resource.IXtextResource;

public abstract class AbstractXtextEditor extends TextEditor {

	private Annotation annotation;

	public class MarkRegionJob extends Job {

		private static final String SELECTED_REGION_TYPE = "org.openarchitectureware.xtext.editor.base.selectedRegion";
		private int start;
		private int length;

		public MarkRegionJob() {
			super("Update region");
		}

		public Job setStartAndLength(final int start, final int length) {
			this.start = start;
			this.length = length;
			return this;
		}

		@Override
		protected IStatus run(final IProgressMonitor monitor) {
			if (monitor.isCanceled())
				return Status.CANCEL_STATUS;

			final ITextViewer textViewer = getSourceViewer();
			if (textViewer == null)
				return Status.CANCEL_STATUS;

			final IDocument document = textViewer.getDocument();
			if (document == null)
				return Status.CANCEL_STATUS;

			final IDocumentProvider documentProvider = getDocumentProvider();
			if (documentProvider == null)
				return Status.CANCEL_STATUS;

			final IAnnotationModel annotationModel = documentProvider
					.getAnnotationModel(getEditorInput());
			if (annotationModel == null)
				return Status.CANCEL_STATUS;

			String message;
			try {
				message = document.get(start, length);
			} catch (final BadLocationException e) {
				return Status.CANCEL_STATUS;
			}
			removeAnnotation();
			Display.getDefault().syncExec(new Runnable() {

				public void run() {
					// uninstallSelectionListener();
					getTextViewer().getTextWidget().setRedraw(false);
					getTextViewer().getTextWidget().setSelection(start,
							start + length);
					getTextViewer().getTextWidget().setSelection(start);
					getTextViewer().getTextWidget().setRedraw(true);
					// getSelectionProvider().setSelection(new
					// TextSelection(start, 0));
					// installSelectionListener();
				}
			});
			annotation = new Annotation(SELECTED_REGION_TYPE, false, message);
			annotationModel.addAnnotation(annotation, new Position(start,
					length));
			return Status.OK_STATUS;
		}

	}

	public class OutlineSynchronizer implements ISelectionChangedListener {

		/**
		 * Installs this selection changed listener with the given selection
		 * provider. If the selection provider is a post selection provider,
		 * post selection changed events are the preferred choice, otherwise
		 * normal selection changed events are requested.
		 * 
		 * @param selectionProvider
		 */
		public void install(final ISelectionProvider selectionProvider) {
			if (selectionProvider == null)
				return;

			if (selectionProvider instanceof IPostSelectionProvider) {
				final IPostSelectionProvider provider = (IPostSelectionProvider) selectionProvider;
				provider.addPostSelectionChangedListener(this);
			} else {
				selectionProvider.addSelectionChangedListener(this);
			}
		}

		/**
		 * Removes this selection changed listener from the given selection
		 * provider.
		 * 
		 * @param selectionProvider
		 *            the selection provider
		 */
		public void uninstall(final ISelectionProvider selectionProvider) {
			if (selectionProvider == null)
				return;

			if (selectionProvider instanceof IPostSelectionProvider) {
				final IPostSelectionProvider provider = (IPostSelectionProvider) selectionProvider;
				provider.removePostSelectionChangedListener(this);
			} else {
				selectionProvider.removeSelectionChangedListener(this);
			}
		}

		public void selectionChanged(final SelectionChangedEvent event) {
			if (event.getSelection() instanceof ITextSelection) {
				removeAnnotation();
				final Node node = NodeUtil.findNodeUnderOffset(lastResult,
						getTextViewer().getSelectedRange().x);
				final EObject modelElement = NodeUtil.getModelElement(node);
				if (null != modelElement) {
					outlinePage.setSelection(new StructuredSelection(
							modelElement));
				}
			}
		}

	}

	private class ParsingListener extends JobChangeAdapter {

		@Override
		public void done(IJobChangeEvent event) {
			isParsing = false;
			runPostponedJobs();
		}

		@Override
		public void running(IJobChangeEvent event) {
			isParsing = true;
		}

	}

	private static final String XTEXT_FIND_REFERENCES_SUB_MENU_ID = "#XtextFindReferencesSubMenu";

	private static final String REFERENCES_MENU_LABEL = "References";

	private static final String GROUP_XTEXT_FIND = "xtext.find";

	private ProjectionSupport projectionSupport;

	private final ColorProvider colorProvider;

	private XtextContentOutlinePage outlinePage;

	private final XtextFoldingStructureProvider xtextFoldingStructureProvider;

	private Node lastResult;

	private ResourceBundle resourceBundle;

	private IContextService contextService;

	private IContextActivation context;

	private Job j;

	private boolean useContextRule;

	private int delay = Integer.MIN_VALUE;

	private OutlineSynchronizer outlineSynchronizer;

	private final MarkRegionJob markRegionJob = new MarkRegionJob();

	private IXtextResource resource;

	private boolean firstTime = true;

	private boolean isParsing;

	private XtextResourceSet resourceSet;

	private List<Job> postponedJobs = new ArrayList<Job>();

	private ResourceSetSynchronizer resourceSetSynchronizer;

	public AbstractXtextEditor() {
		super();
		colorProvider = new ColorProvider();
		setSourceViewerConfiguration(new XtextSourceViewerConfiguration(
				getPlugin(), this));
		setDocumentProvider(new DocumentProvider(getPlugin().getUtilities()
				.getPartitionScanner()));
		xtextFoldingStructureProvider = new XtextFoldingStructureProvider();
		resourceSet = new XtextResourceSet();
		resourceSet.setRecursiveLink(false);
		resourceSetSynchronizer = new ResourceSetSynchronizer(this);
		resourceSet.eAdapters().add(resourceSetSynchronizer);
		ResourcesPlugin.getWorkspace().addResourceChangeListener(
				resourceSetSynchronizer);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.editors.text.TextEditor#initializeEditor() Called
	 * from TextEditor.<init>
	 */
	@Override
	protected void initializeEditor() {
		super.initializeEditor();
		setPreferenceStore(getPlugin().getCombinedPreferenceStore());
	}

	@Override
	protected void doSetInput(final IEditorInput input) throws CoreException {
		super.doSetInput(input);
		IFile file = getFile();
		IProject project = file.getProject();
		IJavaProject javaProject = JavaCore.create(project);
		resourceSet.getResources().clear();
		if (javaProject.exists()) {
			JdtClasspathUriResolver jdtClasspathUriResolver = new JdtClasspathUriResolver();
			resourceSet.setClasspathUriResolver(jdtClasspathUriResolver);
			resourceSet.setClasspathURIContext(javaProject);
		}
		getAdapter(IContentOutlinePage.class);
	}

	public abstract AbstractXtextEditorPlugin getPlugin();

	@Override
	public void createPartControl(final Composite parent) {
		super.createPartControl(parent);
		final ProjectionViewer projectionViewer = (ProjectionViewer) getSourceViewer();
		projectionSupport = new ProjectionSupport(projectionViewer,
				getAnnotationAccess(), getSharedColors());
		projectionSupport
				.addSummarizableAnnotationType("org.eclipse.ui.workbench.texteditor.error");
		projectionSupport
				.addSummarizableAnnotationType("org.eclipse.ui.workbench.texteditor.warning");
		projectionSupport
				.addSummarizableAnnotationType("org.eclipse.ui.workbench.texteditor.task");
		projectionSupport.install();
		projectionViewer.doOperation(ProjectionViewer.TOGGLE);
		register();

		outlineSynchronizer = new OutlineSynchronizer();
		installSelectionListener();
		refresh(new NullProgressMonitor());
	}

	@Override
	protected void configureSourceViewerDecorationSupport(
			final SourceViewerDecorationSupport support) {
		super.configureSourceViewerDecorationSupport(support);
	}

	private void register() {
		contextService = (IContextService) getEditorSite().getService(
				IContextService.class);
		context = contextService.activateContext("xtext.editor.base.context");
	}

	@Override
	protected ISourceViewer createSourceViewer(final Composite parent,
			final IVerticalRuler ruler, final int styles) {
		final ISourceViewer viewer = new XtextSourceViewer(parent, ruler,
				getOverviewRuler(), isOverviewRulerVisible(), styles);
		getSourceViewerDecorationSupport(viewer);
		j = new Job("parsing document") {
			@Override
			protected IStatus run(final IProgressMonitor monitor) {
				refresh(monitor);
				return Status.OK_STATUS;
			}
		};
		j.addJobChangeListener(new ParsingListener());

		viewer.addTextListener(new ITextListener() {
			public void textChanged(final org.eclipse.jface.text.TextEvent event) {
				if (event.getDocumentEvent() != null) {
					j.cancel();
					j.schedule();
				}
			}

		});
		return viewer;
	}

	@Override
	public void dispose() {
		resourceSet.eAdapters().remove(resourceSetSynchronizer);
		ResourcesPlugin.getWorkspace().removeResourceChangeListener(
				resourceSetSynchronizer);
		uninstallSelectionListener();
		colorProvider.dispose();
		super.dispose();
		if (outlinePage != null) {
			this.outlinePage.setInput(null);
			this.outlinePage.dispose();
			this.outlinePage = null;
		}
		if (context != null && contextService != null) {
			contextService.deactivateContext(context);
		}
		if (resource != null) {
			resource.unload();
		}
	}

	public Node getLastResult() {
		if (j != null) {
			try {
				j.join();
			} catch (final InterruptedException e) {
				// ignore
			}
		}
		return lastResult;
	}

	private void setLastResult(final Node lastResult) {
		this.lastResult = lastResult;
	}

	private int getDelay() {
		if (delay == Integer.MIN_VALUE) {
			final Object object = getPlugin().getUtilities().invokeExtension(
					StyleConstants.STYLE_EXTENSION_FILE_NAME,
					StyleConstants.DELAY);
			delay = (int) ((Long) object).longValue();
		}
		return delay;
	}

	private final void refresh(final IProgressMonitor mon) {
		refresh(mon, false);
	}

	final void refresh(final IProgressMonitor mon, boolean forceCheck) {
		final IFile file = getFile();
		if (file != null) {
			final IDocument document = getDocumentProvider().getDocument(
					getEditorInput());
			if (document == null)
				return;
			final String text = document.get();
			if (mon.isCanceled())
				return;
			try {

				boolean doCheck = forceCheck;
				if (BaseEditorPlugin
						.getDefault()
						.getPreferenceStore()
						.getString(PreferenceConstants.CHECK_STRATEGY)
						.equalsIgnoreCase(
								PreferenceConstants.CHECK_STRATEGY_ON_KEYSTROKE)) {
					doCheck = true;
				}

				if (firstTime) {
					firstTime = false;
					doCheck = true;
				}

				resource = MarkerManager.parseAndAnalyze(file,
						new ByteArrayInputStream(text.getBytes(file
								.getCharset())), resourceSet, doCheck, mon);
				if (resource != null && resource.getParser() != null) {
					setLastResult(resource.getParser().getRootNode());
				}
				if (mon.isCanceled())
					return;
				if (outlinePage != null && lastResult != null) {
					if (!MarkerManager.hasMarkers(file,
							MarkerDeletionStrategy.parseErrors)) {
						this.outlinePage.setRootElement(resource);
					}
				}
				if (mon.isCanceled())
					return;
				if (lastResult != null) {
					xtextFoldingStructureProvider.updateFoldingRegions(
							lastResult, this, getDocumentProvider()
									.getDocument(getEditorInput()),
							new NullProgressMonitor());
				}
			} catch (final UnsupportedEncodingException e) {
				XtextLog.logError(e);
			} catch (final CoreException e) {
				XtextLog.logError(e);
			}
		}
	}

	@Override
	public void doSave(final IProgressMonitor progressMonitor) {
		try {
			final IFile file = getFile();
			Job checkJob = new Job("Run checks on "
					+ getEditorInput().getName()) {
				@Override
				protected IStatus run(final IProgressMonitor monitor) {
					if (resource != null) {
						MarkerManager.runChecks(file, resource.getParser());
					}
					return Status.OK_STATUS;
				}
			};

			if (!file.getProject().hasNature(XtextNature.NATURE_ID)) {
				if (!isParsing) {
					checkJob.schedule();
				} else {
					postpone(checkJob);
				}
			}
		} catch (final CoreException e) {
			XtextLog.logError(e);
		}
		super.doSave(progressMonitor);
	}

	private void postpone(Job job) {
		if (job == null)
			return;

		postponedJobs.add(job);

	}

	private void runPostponedJobs() {
		for (Job job : postponedJobs) {
			job.schedule();
			try {
				job.join();
			} catch (InterruptedException e) {
				// ignore
			}
		}
		postponedJobs.clear();
	}

	@Override
	protected void editorContextMenuAboutToShow(final IMenuManager menu) {
		super.editorContextMenuAboutToShow(menu);
		addAction(menu, ITextEditorActionConstants.GROUP_OPEN,
				JdtActionConstants.OPEN);
		addAction(menu, ITextEditorActionConstants.GROUP_EDIT,
				JdtActionConstants.TOGGLE_COMMENT);
		final MenuManager mm = new MenuManager(REFERENCES_MENU_LABEL,
				XTEXT_FIND_REFERENCES_SUB_MENU_ID);
		mm.add(new GroupMarker(GROUP_XTEXT_FIND));
		mm.appendToGroup(GROUP_XTEXT_FIND,
				getAction(JdtActionConstants.FIND_REFERENCES_IN_WORKSPACE));
		menu.appendToGroup(ITextEditorActionConstants.GROUP_FIND, mm);

	}

	@SuppressWarnings("unchecked")
	@Override
	public Object getAdapter(final Class aRequired) {
		if (IContentOutlinePage.class.equals(aRequired)) {
			if (outlinePage == null) {
				outlinePage = newContentOutlinePage();
				if (getEditorInput() != null) {
					outlinePage.setInput(getEditorInput());
				}
			}
			return outlinePage;
		} else if (projectionSupport != null
				&& ProjectionAnnotationModel.class.equals(aRequired))
			return projectionSupport.getAdapter(getSourceViewer(), aRequired);
		return super.getAdapter(aRequired);
	}

	protected XtextContentOutlinePage newContentOutlinePage() {
		return new XtextContentOutlinePage(getPlugin().getUtilities(), this);
	}

	@Override
	@SuppressWarnings("unchecked")
	protected void createActions() {
		super.createActions();
		resourceBundle = new ResourceBundle() {

			@Override
			public Enumeration getKeys() {
				return new Vector<Object>().elements();
			}

			@Override
			protected Object handleGetObject(final String key) {
				return null;
			}
		};
		IAction a = new TextOperationAction(resourceBundle,
				"ContentAssistProposal.", this,
				ISourceViewer.CONTENTASSIST_PROPOSALS);
		a
				.setActionDefinitionId(ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS);
		setAction("ContentAssistProposal", a);

		a = new TextOperationAction(resourceBundle, "ContentAssistTip.", this,
				ISourceViewer.CONTENTASSIST_CONTEXT_INFORMATION);
		a
				.setActionDefinitionId(ITextEditorActionDefinitionIds.CONTENT_ASSIST_CONTEXT_INFORMATION);
		setAction("ContentAssistTip", a);

		a = new TextOperationAction(
				resourceBundle,
				"ShowOutline.", this, IXtextEditorActionDefinitionIds.SHOW_OUTLINE_ID, true); //$NON-NLS-1$
		a.setActionDefinitionId(IXtextEditorActionDefinitionIds.SHOW_OUTLINE);
		setAction(IXtextEditorActionDefinitionIds.SHOW_OUTLINE, a);

		hookAlienActions();
	}

	public ITextViewer getTextViewer() {
		return getSourceViewer();
	}

	private void hookAlienActions() {
		setAction(JdtActionConstants.OPEN, new OpenDeclarationAction(this));
		setAction(JdtActionConstants.TOGGLE_COMMENT, new ToggleCommentAction(
				this));
		setAction(JdtActionConstants.FIND_REFERENCES_IN_WORKSPACE,
				new FindReferencesInWorkspaceAction(this));
		setAction(JdtActionConstants.FORMAT, new FormatAction(this));
		setAction(JdtActionConstants.OPEN_TYPE_HIERARCHY,
				new OpenTypeHierarchyAction(this));
	}

	public IFile getFile() {
		return (IFile) getEditorInput().getAdapter(IFile.class);
	}

	public ResourceSet getResourceSet() {
		return resourceSet;
	}

	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	public Node getCurrentNode() {
		return NodeUtil.findNodeUnderOffset(getRootNode(), getTextViewer()
				.getSelectedRange().x);
	}

	public Node getRootNode() {
		return MarkerManager.parseAndAnalyze(getFile(), resourceSet, false,
				false, new NullProgressMonitor()).getParser().getRootNode();
	}

	public boolean useContextRule() {

		if (getDelay() < 0)
			return false;
		if (getDelay() == 0)
			return true;
		return useContextRule;
	}

	public void updateHighlightedRegion(final int start, final int length) {
		markRegionJob.setStartAndLength(start, length).schedule();
	}

	private void removeAnnotation() {
		if (annotation == null)
			return;
		final IDocumentProvider documentProvider = getDocumentProvider();
		if (documentProvider == null)
			return;
		final IAnnotationModel annotationModel = documentProvider
				.getAnnotationModel(getEditorInput());
		if (annotationModel == null)
			return;
		annotationModel.removeAnnotation(annotation);
		annotation = null;
	}

	private void uninstallSelectionListener() {
		outlineSynchronizer.uninstall(getSelectionProvider());
	}

	private void installSelectionListener() {
		outlineSynchronizer.install(getSelectionProvider());
	}
}
