/**
 * <copyright>
 * </copyright>
 *
 * $Id: ProposalImpl.java,v 1.2 2008/12/23 21:53:44 pschoenb Exp $
 */
package org.openarchitectureware.xtext.editor.contentassist.codeassist.impl;

import java.util.Collection;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.InternalEObject;
import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage;
import org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal;
import org.openarchitectureware.xtext.editor.contentassist.codeassist.Type;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Proposal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl#getLabel <em>Label</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl#getToInsert <em>To Insert</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl#getImage <em>Image</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl#getData <em>Data</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl#getModelElement <em>Model Element</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl#getType <em>Type</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl#getStartReplace <em>Start Replace</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl#getEndReplace <em>End Replace</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl#isApplyPrefixFilter <em>Apply Prefix Filter</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ProposalImpl extends EObjectImpl implements Proposal {
	/**
	 * The default value of the '{@link #getLabel() <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected static final String LABEL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLabel() <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected String label = LABEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getToInsert() <em>To Insert</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getToInsert()
	 * @generated
	 * @ordered
	 */
	protected static final String TO_INSERT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getToInsert() <em>To Insert</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getToInsert()
	 * @generated
	 * @ordered
	 */
	protected String toInsert = TO_INSERT_EDEFAULT;

	/**
	 * The default value of the '{@link #getImage() <em>Image</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage()
	 * @generated
	 * @ordered
	 */
	protected static final String IMAGE_EDEFAULT = "default.gif";

	/**
	 * The cached value of the '{@link #getImage() <em>Image</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage()
	 * @generated
	 * @ordered
	 */
	protected String image = IMAGE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getData() <em>Data</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getData()
	 * @generated
	 * @ordered
	 */
	protected EList data;

	/**
	 * The cached value of the '{@link #getModelElement() <em>Model Element</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getModelElement()
	 * @generated
	 * @ordered
	 */
	protected EObject modelElement;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final Type TYPE_EDEFAULT = Type.KEYWORD_LITERAL;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected Type type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getStartReplace() <em>Start Replace</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStartReplace()
	 * @generated
	 * @ordered
	 */
	protected static final int START_REPLACE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getStartReplace() <em>Start Replace</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStartReplace()
	 * @generated
	 * @ordered
	 */
	protected int startReplace = START_REPLACE_EDEFAULT;

	/**
	 * The default value of the '{@link #getEndReplace() <em>End Replace</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndReplace()
	 * @generated
	 * @ordered
	 */
	protected static final int END_REPLACE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getEndReplace() <em>End Replace</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndReplace()
	 * @generated
	 * @ordered
	 */
	protected int endReplace = END_REPLACE_EDEFAULT;

	/**
	 * The default value of the '{@link #isApplyPrefixFilter() <em>Apply Prefix Filter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isApplyPrefixFilter()
	 * @generated
	 * @ordered
	 */
	protected static final boolean APPLY_PREFIX_FILTER_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isApplyPrefixFilter() <em>Apply Prefix Filter</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isApplyPrefixFilter()
	 * @generated
	 * @ordered
	 */
	protected boolean applyPrefixFilter = APPLY_PREFIX_FILTER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProposalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return CodeassistPackage.Literals.PROPOSAL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLabel(String newLabel) {
		String oldLabel = label;
		label = newLabel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CodeassistPackage.PROPOSAL__LABEL, oldLabel, label));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getToInsert() {
		return toInsert;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setToInsert(String newToInsert) {
		String oldToInsert = toInsert;
		toInsert = newToInsert;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CodeassistPackage.PROPOSAL__TO_INSERT, oldToInsert, toInsert));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getImage() {
		return image;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setImage(String newImage) {
		String oldImage = image;
		image = newImage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CodeassistPackage.PROPOSAL__IMAGE, oldImage, image));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList getData() {
		if (data == null) {
			data = new EObjectContainmentEList(EObject.class, this, CodeassistPackage.PROPOSAL__DATA);
		}
		return data;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject getModelElement() {
		if (modelElement != null && modelElement.eIsProxy()) {
			InternalEObject oldModelElement = (InternalEObject)modelElement;
			modelElement = eResolveProxy(oldModelElement);
			if (modelElement != oldModelElement) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CodeassistPackage.PROPOSAL__MODEL_ELEMENT, oldModelElement, modelElement));
			}
		}
		return modelElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EObject basicGetModelElement() {
		return modelElement;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setModelElement(EObject newModelElement) {
		EObject oldModelElement = modelElement;
		modelElement = newModelElement;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CodeassistPackage.PROPOSAL__MODEL_ELEMENT, oldModelElement, modelElement));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Type getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(Type newType) {
		Type oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CodeassistPackage.PROPOSAL__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getStartReplace() {
		return startReplace;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStartReplace(int newStartReplace) {
		int oldStartReplace = startReplace;
		startReplace = newStartReplace;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CodeassistPackage.PROPOSAL__START_REPLACE, oldStartReplace, startReplace));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getEndReplace() {
		return endReplace;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEndReplace(int newEndReplace) {
		int oldEndReplace = endReplace;
		endReplace = newEndReplace;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CodeassistPackage.PROPOSAL__END_REPLACE, oldEndReplace, endReplace));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isApplyPrefixFilter() {
		return applyPrefixFilter;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setApplyPrefixFilter(boolean newApplyPrefixFilter) {
		boolean oldApplyPrefixFilter = applyPrefixFilter;
		applyPrefixFilter = newApplyPrefixFilter;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CodeassistPackage.PROPOSAL__APPLY_PREFIX_FILTER, oldApplyPrefixFilter, applyPrefixFilter));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CodeassistPackage.PROPOSAL__DATA:
				return ((InternalEList)getData()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CodeassistPackage.PROPOSAL__LABEL:
				return getLabel();
			case CodeassistPackage.PROPOSAL__TO_INSERT:
				return getToInsert();
			case CodeassistPackage.PROPOSAL__IMAGE:
				return getImage();
			case CodeassistPackage.PROPOSAL__DATA:
				return getData();
			case CodeassistPackage.PROPOSAL__MODEL_ELEMENT:
				if (resolve) return getModelElement();
				return basicGetModelElement();
			case CodeassistPackage.PROPOSAL__TYPE:
				return getType();
			case CodeassistPackage.PROPOSAL__START_REPLACE:
				return new Integer(getStartReplace());
			case CodeassistPackage.PROPOSAL__END_REPLACE:
				return new Integer(getEndReplace());
			case CodeassistPackage.PROPOSAL__APPLY_PREFIX_FILTER:
				return isApplyPrefixFilter() ? Boolean.TRUE : Boolean.FALSE;
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CodeassistPackage.PROPOSAL__LABEL:
				setLabel((String)newValue);
				return;
			case CodeassistPackage.PROPOSAL__TO_INSERT:
				setToInsert((String)newValue);
				return;
			case CodeassistPackage.PROPOSAL__IMAGE:
				setImage((String)newValue);
				return;
			case CodeassistPackage.PROPOSAL__DATA:
				getData().clear();
				getData().addAll((Collection)newValue);
				return;
			case CodeassistPackage.PROPOSAL__MODEL_ELEMENT:
				setModelElement((EObject)newValue);
				return;
			case CodeassistPackage.PROPOSAL__TYPE:
				setType((Type)newValue);
				return;
			case CodeassistPackage.PROPOSAL__START_REPLACE:
				setStartReplace(((Integer)newValue).intValue());
				return;
			case CodeassistPackage.PROPOSAL__END_REPLACE:
				setEndReplace(((Integer)newValue).intValue());
				return;
			case CodeassistPackage.PROPOSAL__APPLY_PREFIX_FILTER:
				setApplyPrefixFilter(((Boolean)newValue).booleanValue());
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case CodeassistPackage.PROPOSAL__LABEL:
				setLabel(LABEL_EDEFAULT);
				return;
			case CodeassistPackage.PROPOSAL__TO_INSERT:
				setToInsert(TO_INSERT_EDEFAULT);
				return;
			case CodeassistPackage.PROPOSAL__IMAGE:
				setImage(IMAGE_EDEFAULT);
				return;
			case CodeassistPackage.PROPOSAL__DATA:
				getData().clear();
				return;
			case CodeassistPackage.PROPOSAL__MODEL_ELEMENT:
				setModelElement((EObject)null);
				return;
			case CodeassistPackage.PROPOSAL__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case CodeassistPackage.PROPOSAL__START_REPLACE:
				setStartReplace(START_REPLACE_EDEFAULT);
				return;
			case CodeassistPackage.PROPOSAL__END_REPLACE:
				setEndReplace(END_REPLACE_EDEFAULT);
				return;
			case CodeassistPackage.PROPOSAL__APPLY_PREFIX_FILTER:
				setApplyPrefixFilter(APPLY_PREFIX_FILTER_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CodeassistPackage.PROPOSAL__LABEL:
				return LABEL_EDEFAULT == null ? label != null : !LABEL_EDEFAULT.equals(label);
			case CodeassistPackage.PROPOSAL__TO_INSERT:
				return TO_INSERT_EDEFAULT == null ? toInsert != null : !TO_INSERT_EDEFAULT.equals(toInsert);
			case CodeassistPackage.PROPOSAL__IMAGE:
				return IMAGE_EDEFAULT == null ? image != null : !IMAGE_EDEFAULT.equals(image);
			case CodeassistPackage.PROPOSAL__DATA:
				return data != null && !data.isEmpty();
			case CodeassistPackage.PROPOSAL__MODEL_ELEMENT:
				return modelElement != null;
			case CodeassistPackage.PROPOSAL__TYPE:
				return type != TYPE_EDEFAULT;
			case CodeassistPackage.PROPOSAL__START_REPLACE:
				return startReplace != START_REPLACE_EDEFAULT;
			case CodeassistPackage.PROPOSAL__END_REPLACE:
				return endReplace != END_REPLACE_EDEFAULT;
			case CodeassistPackage.PROPOSAL__APPLY_PREFIX_FILTER:
				return applyPrefixFilter != APPLY_PREFIX_FILTER_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (label: ");
		result.append(label);
		result.append(", toInsert: ");
		result.append(toInsert);
		result.append(", image: ");
		result.append(image);
		result.append(", type: ");
		result.append(type);
		result.append(", startReplace: ");
		result.append(startReplace);
		result.append(", endReplace: ");
		result.append(endReplace);
		result.append(", applyPrefixFilter: ");
		result.append(applyPrefixFilter);
		result.append(')');
		return result.toString();
	}

} //ProposalImpl
