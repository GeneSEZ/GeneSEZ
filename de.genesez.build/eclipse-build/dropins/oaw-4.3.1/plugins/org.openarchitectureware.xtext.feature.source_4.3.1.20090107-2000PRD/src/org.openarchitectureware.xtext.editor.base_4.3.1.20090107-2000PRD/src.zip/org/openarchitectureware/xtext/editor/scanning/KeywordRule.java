/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.editor.scanning;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.text.rules.ICharacterScanner;
import org.eclipse.jface.text.rules.IRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.RuleBasedScanner;
import org.eclipse.jface.text.rules.Token;

/**
 * @author Sven Efftinge (http://www.efftinge.de)
 * @author Bernd Kolb (http://www.kolbware.de)
 */
public class KeywordRule implements IRule {

	private IToken keywordToken;

	private List<String> keywords;

	private String[] getKeywords(String prefix) {
		List<String> result = new ArrayList<String>();
		for (int i = 0; i < keywords.size(); i++) {
			String w = keywords.get(i);
			if (w.startsWith(prefix))
				result.add(w);
		}
		return result.toArray(new String[result.size()]);
	}

	protected boolean isKeyword(String word) {
		for (int i = 0; i < keywords.size(); i++) {
			String w = keywords.get(i);
			if (w.equals(word))
				return true;
		}
		return false;
	}

	/**
	 * @param editor
	 * 
	 */
	public KeywordRule(IToken token, List<String> keywords) {
		this.keywordToken = token;
		this.keywords = keywords;
	}

	/**
	 * @param prefix
	 * @return
	 */
	protected boolean keywordExists(String prefix) {
		String[] currentWords = getKeywords(prefix.toString());
		return currentWords != null && currentWords.length > 0;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.text.rules.IRule#evaluate(org.eclipse.jface.text.rules.ICharacterScanner)
	 */
	public IToken evaluate(ICharacterScanner charScanner) {
		RuleBasedScanner scanner = (RuleBasedScanner) charScanner;
		StringBuffer buff = new StringBuffer();
		boolean stopReading = false;
		int reads = 0;
		if (scanner.getColumn() > 0) {
			scanner.unread();
			if (Character.isJavaIdentifierPart(scanner.read()))
				return Token.UNDEFINED;
		}
		while (!stopReading) {
			reads++;
			char c = (char) scanner.read();
			String currentWord = buff.toString();
			if (buff.length() > 0 && !Character.isJavaIdentifierPart(c)) {
				if (isKeyword(currentWord) && !keywordExists(currentWord + c)) {
					scanner.unread();
					return keywordToken;
				}
			}
			buff.append(c);
			stopReading = !keywordExists(currentWord);
		}

		for (int i = 0; i < reads; i++) {
			scanner.unread();
		}
		return Token.UNDEFINED;
	}
}
