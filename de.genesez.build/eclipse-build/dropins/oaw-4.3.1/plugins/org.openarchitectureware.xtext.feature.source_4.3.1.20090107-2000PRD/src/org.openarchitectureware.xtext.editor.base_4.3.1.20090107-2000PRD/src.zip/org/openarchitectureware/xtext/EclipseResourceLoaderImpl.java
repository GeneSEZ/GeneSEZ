/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext;

import java.io.InputStream;
import java.net.URL;

import org.openarchitectureware.workflow.util.ResourceLoaderDefaultImpl;

public class EclipseResourceLoaderImpl extends ResourceLoaderDefaultImpl {

    private ClassLoader cl;

    public EclipseResourceLoaderImpl(ClassLoader loader) {
        this.cl = loader;
    }

    @Override
    public InputStream internalGetResourceAsStream(String path) {
        return cl.getResourceAsStream(path);
    }

    @Override
    public Class<?> internalLoadClass(String clazzName) throws ClassNotFoundException {
        return cl.loadClass(clazzName);
    }

    @Override
    public URL internalGetResource(String uri) {
        return cl.getResource(uri);
    }

}
