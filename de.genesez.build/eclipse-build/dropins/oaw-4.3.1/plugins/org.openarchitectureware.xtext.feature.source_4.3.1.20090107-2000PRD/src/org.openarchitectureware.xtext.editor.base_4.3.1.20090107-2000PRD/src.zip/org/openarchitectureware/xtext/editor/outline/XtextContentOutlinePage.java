/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.outline;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.progress.UIJob;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;
import org.openarchitectureware.xtext.BaseEditorPlugin;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;
import org.openarchitectureware.xtext.editor.outline.tree.UIContentNode;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;
import org.openarchitectureware.xtext.resource.IXtextResource;

public class XtextContentOutlinePage extends ContentOutlinePage {

	public class LinkWithEditorAction extends Action {

		public LinkWithEditorAction() {
			super("Link with Editor", Action.AS_CHECK_BOX);
			setImageDescriptor(BaseEditorPlugin.getImageDescriptorFromBase("icons/synced.gif"));
			super.setChecked(true);
		}
		
		@Override
		public void setChecked(boolean checked) {
			super.setChecked(checked);
		}
		
	}

	public class ViewPointAction extends Action {

		public static final String DEFAULT = "default";
		private final XtextContentOutlinePage xtextContentOutlinePage;
		private final String vp;

		public ViewPointAction(XtextContentOutlinePage xtextContentOutlinePage,
				String vp, String iconLoc) {
			super(vp, IAction.AS_RADIO_BUTTON);
			this.xtextContentOutlinePage = xtextContentOutlinePage;
			this.vp = vp;
			if ( iconLoc != null) {
				final Image img = util.getImage(iconLoc);
				if (img!= null) {
					setImageDescriptor(new ImageDescriptor() {
						@Override
						public ImageData getImageData() {
							return img.getImageData();
						}
					});
				}
			}
		}

		@Override
		public void setChecked(boolean checked) {
			super.setChecked(checked);
			if (checked) {
				xtextContentOutlinePage.setViewPointInUse(vp);
			}
		}

	}

	private LanguageUtilities util;

	private AbstractXtextEditor editor;

	private UIContentNode root;

	private IXtextResource parseNodeRoot;

	private String viewPointInUse = ViewPointAction.DEFAULT;

	public XtextContentOutlinePage(LanguageUtilities util,
			AbstractXtextEditor editor) {
		this.util = util;
		this.editor = editor;
	}

	public void setViewPointInUse(String vp) {
		viewPointInUse = vp;
		setRootElement(parseNodeRoot);
	}

	public void setInput(IEditorInput input) {
	}

	public void setRootElement(IXtextResource root) {
		try {
			if (root == null || root.getParser() == null
					|| root.getParser().getRootNode() == null)
				return;
			this.parseNodeRoot = root;
			Object result;
			if (root.getParser().getRootNode().getModelElement() == null)
				return;
			if (viewPointInUse == ViewPointAction.DEFAULT) {
				result = util.invokeExtension("Outline", "outlineTree", root
						.getParser().getRootNode().getModelElement());
			} else {
				result = util.invokeExtension("Outline", "outlineTree_"
						+ viewPointInUse.replaceAll("\\s", "_"), root
						.getParser().getRootNode().getModelElement());
			}
			if (result instanceof UIContentNode) {
				this.root = (UIContentNode) result;
			}
			new UIJob("outline update") {
				@Override
				public IStatus runInUIThread(IProgressMonitor monitor) {
					refresh();
					return Status.OK_STATUS;
				}
			}.schedule();

		} catch (RuntimeException e) {
			XtextLog.logError("Error executing 'Outline.outlineTree(" + root
					+ ")' for '" + viewPointInUse + "' Viewpoint", e);
		}
	}

	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);
		getTreeViewer().setContentProvider(getContentProvider());
		getTreeViewer().setLabelProvider(getLabelProvider());
		getTreeViewer().addSelectionChangedListener(this);
		getTreeViewer().setInput(parse());
		registerToolbarActions(getSite().getActionBars());
	}
	
	private void registerToolbarActions(IActionBars actionBars) {
		try {
			Object result = util.invokeExtension("Outline", "viewpoints");
			if (result == null) {
				result = new ArrayList<String>(0);
			}
			if (result instanceof Collection) {
				MenuManager menu = new MenuManager("Viewpoints",
						"xtext.outline.viewpoints");
				String iconLoc = (String)util.invokeExtension("Outline", "viewpointIcon", "default");
				ViewPointAction vpA = new ViewPointAction(this,
						ViewPointAction.DEFAULT, iconLoc);
				vpA.setChecked(true);
				menu.add(new Separator());
				menu.add(vpA);
				Collection<?> viewPoints = (Collection<?>) result;
				for (Object viewPoint : viewPoints) {
					if (viewPoint instanceof String) {
						String vp = (String) viewPoint;
						Object iconLocAsObj = util.invokeExtension("Outline", "viewpointIcon", vp);
						if ( iconLocAsObj != null) { 
							iconLoc = iconLocAsObj.toString();
						}
						vpA = new ViewPointAction(this, vp, iconLoc);
						menu.add(vpA);
					}
				}
				menu.add(new Separator("xtextActions"));
				menu.add(new Separator("additions"));
				actionBars.getMenuManager().add(menu);
				linkWithEditorAction = new LinkWithEditorAction();
				actionBars.getMenuManager().add(linkWithEditorAction);
			}
		} catch (Exception e) {
			XtextLog
					.logInfo(
							"Error while executing 'viewPoints' in 'Outline'. Extension not available?",
							e);
		}
		actionBars.getToolBarManager().add(new OutlineSortingAction(this));
	}

	private EObject parse() {
		return root;
	}

	private ILabelProvider getLabelProvider() {
		return new UIContentNodeLabelProvider(util);
	}

	private ITreeContentProvider getContentProvider() {
		return new UIContentNodeContentProvider();
	}

	private ISelection selection;

	private LinkWithEditorAction linkWithEditorAction;

	@Override
	public void selectionChanged(SelectionChangedEvent anEvent) {
		super.selectionChanged(anEvent);
		this.selection = anEvent.getSelection();
		this.updateHighlight();
	}

	public void updateHighlight() {
		if (selection != null) {
			if (selection.isEmpty()) {
				editor.resetHighlightRange();
			} else {
				UIContentNode segment = (UIContentNode) ((IStructuredSelection) selection)
						.getFirstElement();
				if (segment != null && segment.getContext() != null) {
					Node n = NodeUtil.getNode(parseNodeRoot.getParser()
							.getRootNode(), (EObject) segment.getContext());
					if (n == null)
						return;
					int start = n.getStart();
					int end = n.getEnd();
					if (start >= 0 && end > start) {
						try {
							editor.updateHighlightedRegion(start, end-start);
						} catch (IllegalArgumentException x) {
							editor.resetHighlightRange();
						}
					}
				}
			}
		}
	}

	public void refresh() {
		TreeViewer viewer = getTreeViewer();

		if (viewer != null) {
			Control control = viewer.getControl();

			if ((control != null) && !control.isDisposed()) {
				control.setRedraw(false);

//				ISelection selection = viewer.getSelection();
				TreePath[] treePaths = viewer.getExpandedTreePaths();
				UIContentNode parse = (UIContentNode) parse();
				viewer.setInput(parse);
				viewer.setExpandedTreePaths(treePaths);
				contentMap = null;
//              FIXME: The call to selectContext never selects a node. Is this really necessary?				
//				if (selection instanceof IStructuredSelection) {
//					IStructuredSelection ss = (IStructuredSelection) selection;
//					UIContentNode node = (UIContentNode) ss.getFirstElement();
//					if (node != null) {
//						selectContext(node);
//					}
//				}
				control.setRedraw(true);
				// viewer.expandToLevel(2);
			}
		}
	}

	private Map<Object, UIContentNode> contentMap;
	
	private void selectContext(Object context) {
		if (contentMap == null) {
			EObject rootNode = parse();
			if (rootNode == null) {
				return;
			}
			contentMap = new HashMap<Object, UIContentNode>();
			for (Iterator<?> iterator = rootNode.eAllContents(); iterator.hasNext();) {
				UIContentNode newNode = (UIContentNode) iterator.next();
				if (newNode.getContext() != null)
					contentMap.put(newNode.getContext(), newNode);
			}
		}

		UIContentNode contentNode = contentMap.get(context);
		if ((contentNode == null) && (context instanceof EObject)) {
			Node node = NodeUtil.getNode((EObject)context);
			if (node != null)
				node = node.getParent();
			while(node != null) {
				EObject modelElement = node.getModelElement();
				contentNode = contentMap.get(modelElement);
				if (contentNode != null)
					break;
				node = node.getParent();
			}
		}

		if (contentNode != null)
			getTreeViewer().setSelection(new StructuredSelection(contentNode));
	}

	@Override
	public void setSelection(ISelection selection) {
		if (linkWithEditorAction == null || !linkWithEditorAction.isChecked()) {
			return;
		}
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection sel = (IStructuredSelection) selection;
			getTreeViewer().removeSelectionChangedListener(this);
			selectContext(sel.getFirstElement());
			getTreeViewer().addSelectionChangedListener(this);
		}
	}

	@Override
	public TreeViewer getTreeViewer() {
		return super.getTreeViewer();
	}

}
