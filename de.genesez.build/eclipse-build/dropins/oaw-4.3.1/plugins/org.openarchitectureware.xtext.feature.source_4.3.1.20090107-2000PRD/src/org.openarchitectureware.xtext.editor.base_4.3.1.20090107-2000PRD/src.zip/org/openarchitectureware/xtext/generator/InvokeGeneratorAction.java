package org.openarchitectureware.xtext.generator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.debug.core.ILaunchManager;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.openarchitectureware.eclipse.launch.WorkflowLaunchDelegate;
import org.openarchitectureware.eclipse.launch.WorkflowLaunchShortcut;
import org.openarchitectureware.workflow.WorkflowRunner;
import org.openarchitectureware.workflow.util.ResourceLoaderFactory;
import org.openarchitectureware.xtext.BaseEditorPlugin;
import org.openarchitectureware.xtext.XtextLog;

public class InvokeGeneratorAction implements IObjectActionDelegate {

	private Log log = LogFactory.getLog(getClass());

	private ISelection selection;

	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
	}

	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = selection;
	}

	public void run(IAction action) {
		if (selection instanceof IStructuredSelection) {
			IStructuredSelection structuredSelection = (IStructuredSelection) selection;
			Object element = structuredSelection.getFirstElement();
			IFile file = null;
			if (element instanceof IFile) {
				file = (IFile) element;
			} else if (element instanceof IAdaptable) {
				file = (IFile) ((IAdaptable) element).getAdapter(IFile.class);
			}
			IProject project = file.getProject();
			IResource workflowFile = project.findMember("src/generate.oaw");
			if (workflowFile != null) {
				log.debug(workflowFile.getName());
				try {
					invokeGenerator(project, workflowFile, new NullProgressMonitor());
				} catch (CoreException e) {
					XtextLog.logError(e);
				}
			} else {
				MessageDialog.openWarning(null, "No workflow file found",
						"Xtext workflow file must reside in 'src/generate.oaw'");
			}
		}
	}

	private void invokeGenerator(IProject project, IResource workflowFile, IProgressMonitor monitor)
			throws CoreException {
		WorkflowLaunchShortcut launchShortcut = new WorkflowLaunchShortcut();
		ISelection selection = new StructuredSelection(workflowFile);
		launchShortcut.launch(selection, ILaunchManager.RUN_MODE);

		project.refreshLocal(IResource.DEPTH_INFINITE, monitor);
	}

}
