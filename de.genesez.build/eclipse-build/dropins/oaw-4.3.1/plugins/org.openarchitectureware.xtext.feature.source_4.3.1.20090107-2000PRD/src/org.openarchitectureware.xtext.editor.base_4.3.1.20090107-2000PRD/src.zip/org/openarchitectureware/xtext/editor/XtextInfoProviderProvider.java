package org.openarchitectureware.xtext.editor;

import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.information.IInformationProvider;
import org.eclipse.jface.text.information.IInformationProviderExtension;

public class XtextInfoProviderProvider implements IInformationProvider, IInformationProviderExtension {

	private final AbstractXtextEditor editor;

	public XtextInfoProviderProvider(AbstractXtextEditor editor) {
		this.editor = editor;
	}

	public String getInformation(ITextViewer textViewer, IRegion subject) {
		return getInformation2(textViewer, subject).toString();
	}

	public IRegion getSubject(ITextViewer textViewer, int offset) {
		return new Region(offset, 0);
	}

	public Object getInformation2(ITextViewer textViewer, IRegion subject) {
		return editor.getCurrentNode();
	}

	

}
