/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.editor.wizards;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.SubProgressMonitor;
import org.eclipse.jdt.core.IClasspathEntry;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;

public class ProjectCreator {
	private static Log log = LogFactory.getLog(ProjectCreator.class);

	public static void addBuilders(final IProject project, final String[] strings,
			final IProgressMonitor progressMonitor) throws CoreException {
		final IProjectDescription projectDescription = project.getDescription();

		final ICommand java = createBuilderCommand(projectDescription, JavaCore.BUILDER_ID);

		final ICommand manifest = createBuilderCommand(projectDescription, "org.eclipse.pde.ManifestBuilder");

		final ICommand schema = createBuilderCommand(projectDescription, "org.eclipse.pde.SchemaBuilder");
		projectDescription.setBuildSpec(new ICommand[] { java, manifest, schema });
		project.setDescription(projectDescription, progressMonitor);

	}

	public static void addNatures(final IProject project, final String[] natures, final IProgressMonitor progressMonitor)
			throws CoreException {
		final IProjectDescription projectDescription = project.getDescription();
		projectDescription.setNatureIds(natures);
		project.setDescription(projectDescription, progressMonitor);

	}

	public static void addSourceFolders(final IProject project, final String[] names,
			final IProgressMonitor progressMonitor) throws CoreException {
		final IJavaProject javaProject = JavaCore.create(project);
		javaProject.getProject().getDescription().hasNature(JavaCore.NATURE_ID);
		final List<IClasspathEntry> classpathEntries = new ArrayList<IClasspathEntry>();
		for (final String src : names) {
			final IFolder srcContainer = project.getFolder(src);
			if (!srcContainer.exists()) {
				srcContainer.create(false, true, new SubProgressMonitor(progressMonitor, 1));
			}
			final IClasspathEntry srcClasspathEntry = JavaCore.newSourceEntry(srcContainer.getFullPath());
			classpathEntries.add(srcClasspathEntry);
		}
		classpathEntries.add(JavaCore.newContainerEntry(new Path("org.eclipse.jdt.launching.JRE_CONTAINER")));
		classpathEntries.add(JavaCore.newContainerEntry(new Path("org.eclipse.pde.core.requiredPlugins")));

		javaProject.setRawClasspath(classpathEntries.toArray(new IClasspathEntry[] {}), new SubProgressMonitor(
				progressMonitor, 1));
	}

	public static void create(final IProject project, final String[] requiredBundles, final String[] optionalBundles,
			final IProgressMonitor progressMonitor) throws CoreException {
		addNatures(project, new String[] { JavaCore.NATURE_ID, "org.eclipse.pde.PluginNature" }, progressMonitor);
		addBuilders(project, new String[] { JavaCore.BUILDER_ID, "org.eclipse.pde.ManifestBuilder",
				"org.eclipse.pde.SchemaBuilder" }, progressMonitor);
		final String[] srcFolders = new String[] { "src", "src-gen" };
		addSourceFolders(project, srcFolders, progressMonitor);
		createManifest(project, requiredBundles, optionalBundles, null, progressMonitor);
		createBuildProps(project, srcFolders, progressMonitor);

	}

	public static IFile createFile(final String name, final IContainer container, final String content,
			final IProgressMonitor progressMonitor) {
		final IFile file = container.getFile(new Path(name));
		assertExist(file.getParent());
		try {
			final InputStream stream = new ByteArrayInputStream(content.getBytes(file.getCharset()));
			if (file.exists()) {
				file.setContents(stream, true, true, progressMonitor);
			}
			else {
				file.create(stream, true, progressMonitor);
			}
			stream.close();
		}
		catch (final Exception e) {
			log.error(e);
		}
		progressMonitor.worked(1);

		return file;
	}

	private static void assertExist(final IContainer c) {
		if (!c.exists()) {
			if (!c.getParent().exists()) {
				assertExist(c.getParent());
			}
			if (c instanceof IFolder) {
				try {
					((IFolder) c).create(false, true, new NullProgressMonitor());
				}
				catch (final CoreException e) {
					log.error(e);
				}
			}

		}

	}

	/**
	 * @param projectDescription
	 * @param builderName
	 * @param project
	 * @return
	 * @throws CoreException
	 */
	private static ICommand createBuilderCommand(final IProjectDescription projectDescription, final String builderName)
			throws CoreException {
		final ICommand manifest = projectDescription.newCommand();
		manifest.setBuilderName(builderName);
		return manifest;
	}

	private static void createBuildProps(final IProject project, final String[] srcFolders,
			final IProgressMonitor progressMonitor) {
		final StringBuilder bpContent = new StringBuilder("source.. = ");
		for (final String string : srcFolders) {
			bpContent.append(string).append("/,");
		}
		bpContent.append("\n");
		bpContent.append("bin.includes = META-INF/,\\n");
		bpContent.append("               .\n");
		createFile("build.properties", project, bpContent.toString(), progressMonitor);
	}

	private static void createManifest(final IProject project, final String[] requiredBundles,
			final String[] optionalBundles, final List<String> exportedPackages, final IProgressMonitor progressMonitor)
			throws CoreException {
		final StringBuilder maniContent = new StringBuilder("Manifest-Version: 1.0\n");
		maniContent.append("Bundle-ManifestVersion: 2\n");
		maniContent.append("Bundle-Name: " + project.getName() + "\n");
		maniContent.append("Bundle-SymbolicName: " + project.getName() + "; singleton:=true\n");
		maniContent.append("Bundle-Version: 1.0.0\n");
		// maniContent.append("Bundle-Localization: plugin\n");
		maniContent.append("Require-Bundle: ");
		// bundles
		if (requiredBundles != null && requiredBundles.length > 0) {
			for (final String entry : requiredBundles) {
				if (entry != null) {
					maniContent.append(" " + entry + ",\n");
				}
			}
		}

		if (optionalBundles != null && optionalBundles.length > 0) {
			for (final String entry : optionalBundles) {
				if (entry != null) {
					maniContent.append(" " + entry + "; resolution:=optional,\n");
				}
			}
		}
		maniContent.append(" org.openarchitectureware.dependencies\n");
		// packages
		if (exportedPackages != null && !exportedPackages.isEmpty()) {
			maniContent.append("Export-Package: " + exportedPackages.get(0));
			for (int i = 1, x = exportedPackages.size(); i < x; i++) {
				maniContent.append(",\n " + exportedPackages.get(i));
			}
			maniContent.append("\n");
		}

		final IFolder metaInf = project.getFolder("META-INF");
		metaInf.create(false, true, new SubProgressMonitor(progressMonitor, 1));
		createFile("MANIFEST.MF", metaInf, maniContent.toString(), progressMonitor);
	}

}
