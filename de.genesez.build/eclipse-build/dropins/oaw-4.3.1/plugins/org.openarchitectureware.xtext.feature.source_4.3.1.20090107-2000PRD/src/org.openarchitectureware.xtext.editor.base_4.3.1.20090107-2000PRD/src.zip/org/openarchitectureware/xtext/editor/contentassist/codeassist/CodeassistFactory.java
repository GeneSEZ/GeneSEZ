/**
 * <copyright>
 * </copyright>
 *
 * $Id: CodeassistFactory.java,v 1.1 2007/08/10 07:19:23 sefftinge Exp $
 */
package org.openarchitectureware.xtext.editor.contentassist.codeassist;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage
 * @generated
 */
public interface CodeassistFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CodeassistFactory eINSTANCE = org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.CodeassistFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Proposal</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Proposal</em>'.
	 * @generated
	 */
	Proposal createProposal();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	CodeassistPackage getCodeassistPackage();

} //CodeassistFactory
