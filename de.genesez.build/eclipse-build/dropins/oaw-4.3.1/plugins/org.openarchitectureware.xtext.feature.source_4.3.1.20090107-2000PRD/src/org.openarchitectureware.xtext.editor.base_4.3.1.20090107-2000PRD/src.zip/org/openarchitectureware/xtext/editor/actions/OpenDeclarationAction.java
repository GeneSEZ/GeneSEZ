/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.actions;

import org.eclipse.core.resources.IFile;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jdt.ui.actions.IJavaEditorActionDefinitionIds;
import org.eclipse.jface.action.Action;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;
import org.eclipse.ui.texteditor.ITextEditor;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;
import org.openarchitectureware.xtext.editor.marker.MarkerManager;
import org.openarchitectureware.xtext.editor.util.ExtensionHelper;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class OpenDeclarationAction extends Action {
    private AbstractXtextEditor editor;

    public OpenDeclarationAction(AbstractXtextEditor editor) {
        setActionDefinitionId(IJavaEditorActionDefinitionIds.OPEN_EDITOR);
        setId(OpenDeclarationAction.class.getName());
        setText("Open Declaration");
        this.editor = editor;
    }

    @Override
    public void run() {
        Node destnode = ExtensionHelper.getFindDeclarationNode(editor
                .getCurrentNode());
        if (destnode != null) {
            destnode = ExtensionHelper.fixStringRule(destnode);
            String id = NodeUtil.getText(editor.getTextViewer().getDocument()
                    .get(), destnode);
            EObject o = ExtensionHelper.findDeclaration(editor.getPlugin()
                    .getUtilities(), destnode, id);
            if (o != null) {
                IFile targetFile = MarkerManager.getFileForModelElement(o);
                Node targetNode = NodeUtil.getNode(o);
                if (targetFile != null && targetNode != null) {
                    IEditorPart opened;

                    try {
                        opened = IDE.openEditor(PlatformUI.getWorkbench()
                                .getActiveWorkbenchWindow().getActivePage(),
                                targetFile);
                        if (opened instanceof ITextEditor) {
                            ((ITextEditor) opened).selectAndReveal(targetNode
                                    .getStart(), targetNode.getEnd()
                                    - targetNode.getStart());
                        }
                    } catch (PartInitException e) {
                        XtextLog.logError(e);
                    }
                }
            }
        }

    }
}
