/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.editor.wizards;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.wizard.IWizardPage;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWizard;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.dialogs.WizardNewFileCreationPage;
import org.eclipse.ui.ide.IDE;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.XtextLog;

abstract public class AbstractNewFileWizard extends Wizard implements
		INewWizard {
	private WizardNewFileCreationPage page;
	private ISelection selection;

	/**
	 * Constructor for AbstractNewFileWizard.
	 */
	public AbstractNewFileWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	/**
	 * Adding the page to the wizard.
	 */
	public void addPages() {
		if (!(selection instanceof IStructuredSelection)) {
			selection = new StructuredSelection();
		}

		page = new WizardNewFileCreationPage("New " + "Xtext" + " File",
				(IStructuredSelection) selection) {
			@Override
			protected InputStream getInitialContents() {
				return new ByteArrayInputStream(new byte[0]);
			}

			@Override
			public IWizardPage getPreviousPage() {
				validatePage();// validates initial value's
				return super.getPreviousPage();
			}
		};
		page.setFileName("model."+getFileExtension());
		page.setTitle("Xtext DSL " + getFileExtension() + " Editor File");
		page
				.setDescription("This wizard creates a new file with *."
						+ getFileExtension()
						+ " extension that can be opened by the corresponding Xtext editor.");
		page.setImageDescriptor(ImageDescriptor.createFromImage(getUtilities()
				.getImage("newfile_wiz.png")));
		addPage(page);

	}

	private String getFileExtension() {
		return getUtilities().getFileExtension();
	}

	/**
	 * This method is called when 'Finish' button is pressed in the wizard. We
	 * will create an operation and run it using wizard as execution context.
	 */
	public boolean performFinish() {
		boolean retValue = false;
		final IFile f = page.createNewFile();
		if (f != null && f.exists()) {
			try {
				IRunnableWithProgress op = new IRunnableWithProgress() {
					public void run(IProgressMonitor monitor) {
						if (f != null) {
							doOpenFile(f, monitor);
						}
					}
				};
				// fork it
				getContainer().run(true, true, op);
				retValue = true;
			} catch (InvocationTargetException e) {
				XtextLog.logError(e);
				retValue = false;
			} catch (InterruptedException e) {
				XtextLog.logError(e);
				retValue = false;
			}
		}
		return retValue;
	}

	/**
	 * Opens given file in an editor
	 * 
	 * @param f -
	 *            File to open
	 * @param monitor -
	 *            Monitor to progress
	 */
	private void doOpenFile(final IFile f, final IProgressMonitor monitor) {
		monitor.setTaskName("Opening file for editing...");

		getShell().getDisplay().asyncExec(new Runnable() {
			public void run() {
				IWorkbenchPage page = PlatformUI.getWorkbench()
						.getActiveWorkbenchWindow().getActivePage();
				try {
					IDE.openEditor(page, f, true);
				} catch (PartInitException e) {
				}
			}
		});
		monitor.worked(1);
	}

	/**
	 * We will accept the selection in the workbench to see if we can initialize
	 * from it.
	 * 
	 * @see IWorkbenchWizard#init(IWorkbench, IStructuredSelection)
	 */
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}

	abstract protected LanguageUtilities getUtilities();
}