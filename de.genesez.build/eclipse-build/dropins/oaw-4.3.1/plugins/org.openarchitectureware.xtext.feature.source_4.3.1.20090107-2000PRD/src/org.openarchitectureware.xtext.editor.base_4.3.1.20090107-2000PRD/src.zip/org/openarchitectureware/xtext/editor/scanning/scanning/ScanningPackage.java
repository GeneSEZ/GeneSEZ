/**
 * <copyright>
 * </copyright>
 *
 * $Id: ScanningPackage.java,v 1.2 2008/12/23 21:53:44 pschoenb Exp $
 */
package org.openarchitectureware.xtext.editor.scanning.scanning;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.editor.scanning.scanning.ScanningFactory
 * @model kind="package"
 * @generated
 */
public interface ScanningPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "scanning";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.eclipse.org/emp/xtext/scanning";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "scanning";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ScanningPackage eINSTANCE = org.openarchitectureware.xtext.editor.scanning.scanning.impl.ScanningPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl <em>Font Style</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.impl.ScanningPackageImpl#getFontStyle()
	 * @generated
	 */
	int FONT_STYLE = 0;

	/**
	 * The feature id for the '<em><b>Bold</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONT_STYLE__BOLD = 0;

	/**
	 * The feature id for the '<em><b>Italic</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONT_STYLE__ITALIC = 1;

	/**
	 * The feature id for the '<em><b>Underline</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONT_STYLE__UNDERLINE = 2;

	/**
	 * The feature id for the '<em><b>Strikethrough</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONT_STYLE__STRIKETHROUGH = 3;

	/**
	 * The feature id for the '<em><b>Forground Color</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONT_STYLE__FORGROUND_COLOR = 4;

	/**
	 * The feature id for the '<em><b>Background Color</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONT_STYLE__BACKGROUND_COLOR = 5;

	/**
	 * The number of structural features of the '<em>Font Style</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FONT_STYLE_FEATURE_COUNT = 6;


	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.ColorImpl <em>Color</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.impl.ColorImpl
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.impl.ScanningPackageImpl#getColor()
	 * @generated
	 */
	int COLOR = 1;

	/**
	 * The feature id for the '<em><b>R</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR__R = 0;

	/**
	 * The feature id for the '<em><b>G</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR__G = 1;

	/**
	 * The feature id for the '<em><b>B</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR__B = 2;

	/**
	 * The number of structural features of the '<em>Color</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLOR_FEATURE_COUNT = 3;


	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle <em>Font Style</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Font Style</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle
	 * @generated
	 */
	EClass getFontStyle();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isBold <em>Bold</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bold</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isBold()
	 * @see #getFontStyle()
	 * @generated
	 */
	EAttribute getFontStyle_Bold();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isItalic <em>Italic</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Italic</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isItalic()
	 * @see #getFontStyle()
	 * @generated
	 */
	EAttribute getFontStyle_Italic();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isUnderline <em>Underline</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Underline</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isUnderline()
	 * @see #getFontStyle()
	 * @generated
	 */
	EAttribute getFontStyle_Underline();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isStrikethrough <em>Strikethrough</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Strikethrough</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#isStrikethrough()
	 * @see #getFontStyle()
	 * @generated
	 */
	EAttribute getFontStyle_Strikethrough();

	/**
	 * Returns the meta object for the containment reference '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#getForgroundColor <em>Forground Color</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Forground Color</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#getForgroundColor()
	 * @see #getFontStyle()
	 * @generated
	 */
	EReference getFontStyle_ForgroundColor();

	/**
	 * Returns the meta object for the containment reference '{@link org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#getBackgroundColor <em>Background Color</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Background Color</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.FontStyle#getBackgroundColor()
	 * @see #getFontStyle()
	 * @generated
	 */
	EReference getFontStyle_BackgroundColor();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.editor.scanning.scanning.Color <em>Color</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Color</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.Color
	 * @generated
	 */
	EClass getColor();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.scanning.scanning.Color#getR <em>R</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>R</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.Color#getR()
	 * @see #getColor()
	 * @generated
	 */
	EAttribute getColor_R();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.scanning.scanning.Color#getG <em>G</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>G</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.Color#getG()
	 * @see #getColor()
	 * @generated
	 */
	EAttribute getColor_G();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.scanning.scanning.Color#getB <em>B</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>B</em>'.
	 * @see org.openarchitectureware.xtext.editor.scanning.scanning.Color#getB()
	 * @see #getColor()
	 * @generated
	 */
	EAttribute getColor_B();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ScanningFactory getScanningFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl <em>Font Style</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.editor.scanning.scanning.impl.FontStyleImpl
		 * @see org.openarchitectureware.xtext.editor.scanning.scanning.impl.ScanningPackageImpl#getFontStyle()
		 * @generated
		 */
		EClass FONT_STYLE = eINSTANCE.getFontStyle();

		/**
		 * The meta object literal for the '<em><b>Bold</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FONT_STYLE__BOLD = eINSTANCE.getFontStyle_Bold();

		/**
		 * The meta object literal for the '<em><b>Italic</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FONT_STYLE__ITALIC = eINSTANCE.getFontStyle_Italic();

		/**
		 * The meta object literal for the '<em><b>Underline</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FONT_STYLE__UNDERLINE = eINSTANCE.getFontStyle_Underline();

		/**
		 * The meta object literal for the '<em><b>Strikethrough</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FONT_STYLE__STRIKETHROUGH = eINSTANCE.getFontStyle_Strikethrough();

		/**
		 * The meta object literal for the '<em><b>Forground Color</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FONT_STYLE__FORGROUND_COLOR = eINSTANCE.getFontStyle_ForgroundColor();

		/**
		 * The meta object literal for the '<em><b>Background Color</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FONT_STYLE__BACKGROUND_COLOR = eINSTANCE.getFontStyle_BackgroundColor();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.editor.scanning.scanning.impl.ColorImpl <em>Color</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.editor.scanning.scanning.impl.ColorImpl
		 * @see org.openarchitectureware.xtext.editor.scanning.scanning.impl.ScanningPackageImpl#getColor()
		 * @generated
		 */
		EClass COLOR = eINSTANCE.getColor();

		/**
		 * The meta object literal for the '<em><b>R</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLOR__R = eINSTANCE.getColor_R();

		/**
		 * The meta object literal for the '<em><b>G</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLOR__G = eINSTANCE.getColor_G();

		/**
		 * The meta object literal for the '<em><b>B</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLOR__B = eINSTANCE.getColor_B();

	}

} //ScanningPackage
