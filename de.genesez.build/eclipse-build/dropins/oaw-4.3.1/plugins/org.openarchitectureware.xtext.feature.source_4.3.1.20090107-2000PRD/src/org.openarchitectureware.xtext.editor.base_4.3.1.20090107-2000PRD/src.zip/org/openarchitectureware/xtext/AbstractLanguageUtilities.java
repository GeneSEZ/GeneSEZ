/*******************************************************************************
 * Copyright (c) 2007 2008 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.antlr.runtime.RecognitionException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.m2t.type.emf.EmfRegistryMetaModel;
import org.eclipse.swt.graphics.Image;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.ExecutionContextImpl;
import org.openarchitectureware.type.MetaModel;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.util.ResourceLoader;
import org.openarchitectureware.workflow.util.ResourceLoaderFactory;
import org.openarchitectureware.workflow.util.ResourceLoaderImpl;
import org.openarchitectureware.xtend.XtendFacade;
import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.parser.IXtextParser;
import org.openarchitectureware.xtext.parser.impl.AntlrUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;
import org.osgi.framework.Bundle;

public abstract class AbstractLanguageUtilities implements LanguageUtilities {

	private Log log = LogFactory.getLog(AbstractLanguageUtilities.class);
	
	public IXtextParser parse(InputStream is) {
		try {
			IXtextParser internalParse = internalParse(is);
			internalParse.getRootNode();
			return internalParse;
		} catch (RuntimeException e) {
			XtextLog.logInfo("Error parsing input : " + e.getMessage());
			return null;
		} catch (IOException e) {
			XtextLog.logInfo("Error parsing input : " + e.getMessage());
			return null;
		} catch (RecognitionException e) {
			final ErrorMsg err = AntlrUtil.create(e, null);
			return new IXtextParser() {

				public Issues doCheck() {
					return null;
				}

				public List<ErrorMsg> getParseErrors() {
					return Collections.singletonList(err);
				}

				public Node getRootNode() {
					return null;
				}

				public void doLinking() {
				}

				public void postLinking() {
				}

				public void preLinking() {
				}

			};
		}
	}
	
	public abstract AbstractXtextEditorPlugin getXtextEditorPlugin();
	
	public Bundle getPluginBundle() {
		return getXtextEditorPlugin().getBundle();
	}

	public abstract EPackage getEPackage();

	public abstract String getFileExtension();

	protected abstract IXtextParser internalParse(InputStream inputStream) throws IOException, RecognitionException;

	/**
	 * overwrite me to contribute a processor
	 */
	public IContentAssistProcessor getContentAssistProcessor() {
		return null;
	}

	private String defaultImage = "default.gif";

	public Image getImage(String imgname) {
		if (imgname == null)
			imgname = defaultImage;
		final String pathSuffix = "icons/"; //$NON-NLS-1$
		if (imgname != null) {
			Image result = null;
			URL imgUrl = getXtextEditorPlugin().getBundle().getEntry(pathSuffix + imgname);
			if (imgUrl != null) {
				ImageDescriptor id = null;
				result = getXtextEditorPlugin().getImageRegistry().get(imgUrl.toExternalForm());
				if (result == null) {
					id = ImageDescriptor.createFromURL(imgUrl);
					if (id != null) {
						result = id.createImage();
						getXtextEditorPlugin().getImageRegistry().put(imgUrl.toExternalForm(), result);
					}
				}
				return result;
			} else {
				if (imgname != "notFound.gif") {
					return getImage("notFound.gif");
				}
			}
		}
		return null;
	}

	public void dispose() {
	}

	protected abstract ClassLoader getClassLoader();

	WeakReference<ExecutionContextImpl> weakContext;

	private ExecutionContext getContext() {
		ExecutionContextImpl ctx = null;
		if (weakContext != null)
			ctx = weakContext.get();

		if (ctx == null) {
			ctx = new ExecutionContextImpl();
			weakContext = new WeakReference<ExecutionContextImpl>(ctx);
			ctx.registerMetaModel(new EmfRegistryMetaModel() {
				@Override
				protected EPackage[] allPackages() {
					Set<EPackage> packages = new HashSet<EPackage>();
					for (String name : new HashSet<String>(
							EPackage.Registry.INSTANCE.keySet())) {
						try {
							EPackage package1 = EPackage.Registry.INSTANCE
									.getEPackage(name);
							packages.add(package1);
						} catch (Exception e) {
							XtextLog.logWarning("Loading package named '"
									+ name + "' failed.", e);
						}
					}

					return packages.toArray(new EPackage[packages.size()]);
				}

			});
			List<? extends MetaModel> otherMMs = getContributedMetaModels();
			if ( otherMMs != null) {
				for (MetaModel metaModel : otherMMs) {
					ctx.registerMetaModel(metaModel);
				}
			}
		}

		return ctx;
	}

	protected List<? extends MetaModel> getContributedMetaModels() {
		return null;
	}

	protected abstract String getPackageForExtensions();

	private Map<String, WeakReference<XtendFacade>> facadeCache = new HashMap<String, WeakReference<XtendFacade>>();

	private XtendFacade getFacade(String extensionFile) {
		XtendFacade facade = null;

		WeakReference<XtendFacade> weakFacade = facadeCache.get(extensionFile);
		if (weakFacade != null)
			facade = weakFacade.get();

		if (facade == null) {
			if (log.isDebugEnabled())
				log.debug("loading File: " + extensionFile);
			facade = XtendFacade.create(getContext(), getPackageForExtensions() + "::" + extensionFile);
			facadeCache.put(extensionFile, new WeakReference<XtendFacade>(facade));
		}

		return facade;
	}

	public Object invokeExtension(String extensionFile, String name, Object... params) {
		if (log.isDebugEnabled()) {
			StringBuffer paramsString = new StringBuffer();
			for (Object object : params) {
				paramsString.append(toString(object)).append(",");
			}
			log.debug("invoking " + extensionFile + "::" + name + "(" + paramsString + ")");
		}
		ResourceLoader cl = ResourceLoaderFactory.createResourceLoader();
		try {
			ResourceLoaderFactory.setCurrentThreadResourceLoader(new ResourceLoaderImpl(getClassLoader()));
			try {
				Object call = getFacade(extensionFile).call(name, params);
				return call;
			} catch (RuntimeException e) {
				log.error(e);
				throw e;
			}
		} finally {
			ResourceLoaderFactory.setCurrentThreadResourceLoader(cl);
		}
	}

	private String toString(Object object) {
		if (object instanceof EObject) {
			EObject eobj = (EObject) object;
			return eobj.eClass().getName();
		}
		return object == null ? "null" : object.toString();
	}

}