/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.marker;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.texteditor.MarkerUtilities;
import org.openarchitectureware.workflow.issues.Issue;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.parser.IXtextParser;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;
import org.openarchitectureware.xtext.registry.CachingModelLoad;
import org.openarchitectureware.xtext.resource.IXtextResource;
import org.openarchitectureware.xtext.resource.IXtextResourceFactory;

public class MarkerManager {

	public final static String PARSER_MARKER_ID = "org.openarchitectureware.xtext.editor.base.problem";
	public final static String CHECK_MARKER_ID = "org.openarchitectureware.xtext.editor.base.checkViolation";

	public static enum MarkerDeletionStrategy {
		all, parseErrors, checkMarkers
	};

	private static void addMarker(final IFile file, Node n, final Issue issue,
			final int severity) {
		try {
			int start = 0, end = 0, line = 0;
			if (n != null) {
				start = n.getStart();
				end = n.getEnd();
				line = n.getLine();
			}
			final Map<String, Object> attrs = createAttributes(issue.getMessage(),
					severity, start, end, line);
			IWorkspaceRunnable r= new IWorkspaceRunnable() {
				public void run(IProgressMonitor monitor) throws CoreException {
					IMarker marker= file.createMarker(CHECK_MARKER_ID);
					marker.setAttributes(attrs);
				}
			};

			file.getWorkspace().run(r, null,IWorkspace.AVOID_UPDATE, null);
			//MarkerUtilities.createMarker(file, attrs, CHECK_MARKER_ID);
		} catch (final CoreException e) {
			XtextLog.logError(e);
		}
	}

	private static void addParserMarker(final IFile file, final String message,
			final int severity, final int start, final int end, final int line) {
		try {
			Map<String, Object> attrs = createAttributes(message, severity,
					start, end, line);
			MarkerUtilities.createMarker(file, attrs, PARSER_MARKER_ID);
		} catch (final CoreException e) {
			XtextLog.logError(e);
		}
	}

	private static final Map<String, Object> createAttributes(
			final String message, final int severity, final int start,
			final int end, final int line) {
		Map<String, Object> map = new HashMap<String, Object>();
		MarkerUtilities.setMessage(map, message);
		if (start >= 0) {
			MarkerUtilities.setCharStart(map, start);
		}
		if (end > start) {
			MarkerUtilities.setCharEnd(map, end);
		}
		MarkerUtilities.setLineNumber(map, line);
		map.put(IMarker.SEVERITY, severity);
		map.put(IMarker.LOCATION, "line : " + line);
		return map;
	}

	public static boolean hasMarkers(final IResource file,
			final MarkerDeletionStrategy deleteCheckMarkers) {
		try {
			if (file.exists()) {
				boolean result = false;
				if (deleteCheckMarkers == MarkerDeletionStrategy.all
						|| deleteCheckMarkers == MarkerDeletionStrategy.parseErrors) {
					result = file.findMarkers(PARSER_MARKER_ID, false,
							IResource.DEPTH_INFINITE).length > 0;
				}
				if (!result
						&& deleteCheckMarkers == MarkerDeletionStrategy.all
						|| deleteCheckMarkers == MarkerDeletionStrategy.checkMarkers) {
					result = file.findMarkers(CHECK_MARKER_ID, false,
							IResource.DEPTH_INFINITE).length > 0;
				}
				return result;
			}
		} catch (final Exception ignore) {
		}
		return false;

	}

	public static void deleteMarkers(final IResource file,
			final MarkerDeletionStrategy deleteCheckMarkers) {
		try {
			if (file.exists()) {
				new WorkspaceModifyOperation() {

					@Override
					protected void execute(final IProgressMonitor monitor)
							throws CoreException, InvocationTargetException,
							InterruptedException {
						if (deleteCheckMarkers == MarkerDeletionStrategy.all
								|| deleteCheckMarkers == MarkerDeletionStrategy.parseErrors) {
							file.deleteMarkers(PARSER_MARKER_ID, true,
									IResource.DEPTH_INFINITE);
						}
						if (deleteCheckMarkers == MarkerDeletionStrategy.all
								|| deleteCheckMarkers == MarkerDeletionStrategy.checkMarkers) {
							file.deleteMarkers(CHECK_MARKER_ID, true,
									IResource.DEPTH_INFINITE);
						}
					}

				}.run(new NullProgressMonitor());
			}
		} catch (final Exception ce) {
			XtextLog.logError(ce);
		}
	}

	public static IXtextResource parseAndAnalyze(IResource resource,
			InputStream in, ResourceSet resourceSet, boolean doCheck, IProgressMonitor mon) {
		return internalParseAndAnalyze(resource, in, resourceSet, true, doCheck, mon);
	}

	public static IXtextResource parseAndAnalyze(IResource resource,
			ResourceSet resourceSet, boolean reload, boolean doCheck, IProgressMonitor mon) {
		return internalParseAndAnalyze(resource, null, resourceSet, reload, doCheck,  mon);
	}

	private static IXtextResource internalParseAndAnalyze(IResource resource,
			InputStream in, ResourceSet resourceSet, boolean reload, boolean doCheck, IProgressMonitor mon) {
		IFile file = (IFile) resource.getAdapter(IFile.class);
		if (file == null)
			return null;
		if (file.isDerived())
			return null;
		URI uri = URI.createPlatformResourceURI(file.getFullPath().toString(),
				true);
		Object factory = Resource.Factory.Registry.INSTANCE.getFactory(uri);
		if (factory == null)
			return null;
		if (!(factory instanceof IXtextResourceFactory))
			return null;
		if ( mon.isCanceled()) {
			return null;
		}
		try {
			MarkerManager.deleteMarkers(file,
					doCheck ? MarkerDeletionStrategy.all
							: MarkerDeletionStrategy.parseErrors);
			Resource r = null;
			if (in == null) {
				r = CachingModelLoad.loadResource(uri, resourceSet, reload, true);
			} else {
				r = CachingModelLoad.loadResource(uri, in, resourceSet, true);
			}
			if (!(r instanceof IXtextResource)) {
				return null;
			}
			IXtextResource result = ((IXtextResource) r);
			if (!reload)
				return result;
			IXtextParser pr = result.getParser();
			if (pr == null) {
				return null;
			}
			List<ErrorMsg> parseErrors = pr.getParseErrors();
			for (ErrorMsg err : parseErrors) {
				int start = err.getStart();
				int end = err.getStart() + err.getLength() + 1;
				int line = err.getLine();
				if (err.getLine() == 0 && pr != null
						&& pr.getRootNode() != null) {
					start = pr.getRootNode().getEnd() - 1;
					end = pr.getRootNode().getEnd();
					line = -1;
				}
				addParserMarker(file, err.getMsg(), IMarker.SEVERITY_ERROR,
						start, end, line);
			}
			if ( mon.isCanceled()) {
				return result;
			}

			// execute check
			if (parseErrors.isEmpty() && doCheck) {
				runChecks(file, pr);
			}
			return result;
		} catch (Exception e) {
			XtextLog.logError(e);
		}
		return null;
	}

	public static void runChecks(IFile file, IXtextParser parser) {
		deleteMarkers(file, MarkerDeletionStrategy.checkMarkers);
		Issues issues = null;
		try {
			issues = parser.doCheck();
		} catch (Exception e) {
			//TODO potentially unreachable code, cause IXtextParse.doCheck() implementation (see GenParser template) catches Exception
			XtextLog.logError(e);
		}
		if (issues != null) {
			// errors
			Issue[] is = issues.getErrors();
			for (int i = 0; i < is.length; i++) {
				Issue issue = is[i];
				Node n = findNode((Node) parser.getRootNode(), issue
						.getElement());
				addMarker(file, n, issue, IMarker.SEVERITY_ERROR);
			}
			// warnings
			is = issues.getWarnings();
			for (int i = 0; i < is.length; i++) {
				Issue issue = is[i];
				Node n = findNode((Node) parser.getRootNode(), issue
						.getElement());
				addMarker(file, n, issue, IMarker.SEVERITY_WARNING);
			}
		}
	}

	private static Node findNode(Node rootElement, Object element) {
		if (rootElement == null || !(element instanceof EObject))
			return null;
		// make sure we really have the root element
		rootElement = NodeUtil.getRoot(rootElement);
		return NodeUtil.getNode(rootElement, (EObject) element);
	}

	public static IFile getFile(Node target) {
		Resource r = NodeUtil.getModelElement(target).eResource();
		ResourceSet resourceSet = r.getResourceSet();
		URI resourceURI = resourceSet.getURIConverter().normalize(r.getURI());
		String fileString = resourceURI.toPlatformString(true);
		Path path = new Path(fileString);
		return ResourcesPlugin.getWorkspace().getRoot().getFile(path);
	}

	public static IFile getFileForModelElement(EObject o) {
		Node node = NodeUtil.getNode(o);
		return getFile(node);
	}

}
