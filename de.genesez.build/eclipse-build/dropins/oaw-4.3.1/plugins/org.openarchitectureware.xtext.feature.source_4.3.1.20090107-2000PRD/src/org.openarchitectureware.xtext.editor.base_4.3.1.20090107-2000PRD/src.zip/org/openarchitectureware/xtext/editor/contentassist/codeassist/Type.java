/**
 * <copyright>
 * </copyright>
 *
 * $Id: Type.java,v 1.2 2008/12/23 21:53:44 pschoenb Exp $
 */
package org.openarchitectureware.xtext.editor.contentassist.codeassist;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistPackage#getType()
 * @model
 * @generated
 */
public final class Type extends AbstractEnumerator {
	/**
	 * The '<em><b>KEYWORD</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>KEYWORD</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #KEYWORD_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int KEYWORD = 0;

	/**
	 * The '<em><b>ASSIGNMENT</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ASSIGNMENT</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ASSIGNMENT_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ASSIGNMENT = 1;

	/**
	 * The '<em><b>ENUM LITERAL</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ENUM LITERAL</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ENUM_LITERAL_LITERAL
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ENUM_LITERAL = 2;

	/**
	 * The '<em><b>KEYWORD</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #KEYWORD
	 * @generated
	 * @ordered
	 */
	public static final Type KEYWORD_LITERAL = new Type(KEYWORD, "KEYWORD", "KEYWORD");

	/**
	 * The '<em><b>ASSIGNMENT</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ASSIGNMENT
	 * @generated
	 * @ordered
	 */
	public static final Type ASSIGNMENT_LITERAL = new Type(ASSIGNMENT, "ASSIGNMENT", "ASSIGNMENT");

	/**
	 * The '<em><b>ENUM LITERAL</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ENUM_LITERAL
	 * @generated
	 * @ordered
	 */
	public static final Type ENUM_LITERAL_LITERAL = new Type(ENUM_LITERAL, "ENUM_LITERAL", "ENUM_LITERAL");

	/**
	 * An array of all the '<em><b>Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final Type[] VALUES_ARRAY =
		new Type[] {
			KEYWORD_LITERAL,
			ASSIGNMENT_LITERAL,
			ENUM_LITERAL_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Type get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Type result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Type getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Type result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Type get(int value) {
		switch (value) {
			case KEYWORD: return KEYWORD_LITERAL;
			case ASSIGNMENT: return ASSIGNMENT_LITERAL;
			case ENUM_LITERAL: return ENUM_LITERAL_LITERAL;
		}
		return null;
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private Type(int value, String name, String literal) {
		super(value, name, literal);
	}

} //Type
