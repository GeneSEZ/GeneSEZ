/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.editor.actions;

import org.eclipse.jdt.ui.actions.IJavaEditorActionDefinitionIds;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.graphics.Point;
import org.eclipse.ui.texteditor.TextEditorAction;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;

/**
 * An action which toggles comment prefixes on the selected lines.
 */
public class ToggleCommentAction extends TextEditorAction {
	private static final String COMMENT_STRING = "//";
	private ITextViewer textViewer;

	public ToggleCommentAction(AbstractXtextEditor editor) {
		super(editor.getResourceBundle(), null, editor);
		setText("Toggle Comment");
		this.textViewer = editor.getTextViewer();
		setActionDefinitionId(IJavaEditorActionDefinitionIds.TOGGLE_COMMENT);
	}

	@Override
	public void run() {
		if (canModifyEditor()) {
			AbstractXtextEditor editor = (AbstractXtextEditor) getTextEditor();
			final ISelection sel = editor.getSelectionProvider().getSelection();
			if (sel instanceof ITextSelection && !sel.isEmpty()) {
				BusyIndicator.showWhile(editor.getSite().getShell()
						.getDisplay(), new Runnable() {
					public void run() {
						IRegion newTextSelection = performToggle((ITextSelection) sel);
						if (newTextSelection.getLength() > 0) {
							// IRegi
							textViewer.setSelectedRange(newTextSelection
									.getOffset(), newTextSelection.getLength());

						}
					}
				});

			}
		}
	}

	/**
	 * @param startLine
	 * @param endLine
	 * @return modification length - positive if chars added negative otherwise
	 */
	private IRegion performToggle(ITextSelection textSelection) {
		IRegion selection = new Region(textSelection.getOffset(), textSelection
				.getLength());
		int startLine = textSelection.getStartLine();
		int endLine = textSelection.getEndLine();
		if (startLine >= 0 && endLine >= 0) {
			boolean enableComment = shouldEnableComment(new Point(startLine,
					endLine));
			for (int i = startLine; i <= endLine; i++) {
				int modificationLength = toggleLine(i, enableComment);
				if (i == startLine) {
					selection = new Region(selection.getOffset()
							+ modificationLength, selection.getLength());
				} else {
					selection = new Region(selection.getOffset(), selection
							.getLength()
							+ modificationLength);
				}
			}
		}
		return (IRegion) selection;
	}

	private boolean shouldEnableComment(Point sel) {
		boolean retVal = false;
		for (int i = sel.x; i <= sel.y; i++) {
			if (!hasComment(i)) {
				retVal = true;
				break;
			}
		}
		return retVal;
	}

	private int toggleLine(int i, boolean enableComment) {
		int modificationLength = 0;
		try {
			IDocument document = textViewer.getDocument();
			IRegion region = document.getLineInformation(i);
			String replString = COMMENT_STRING;
			int length = 0;
			int offset = region.getOffset();
			if (!enableComment) {
				length = replString.length();
				replString = new String();
				offset = region.getOffset()
						+ getLineContent(i).indexOf(COMMENT_STRING);
			}
			document.replace(offset, length, replString);
			modificationLength = replString.length() - length;
		} catch (BadLocationException e) {
			handleException(e);
		}
		return modificationLength;
	}

	private void handleException(BadLocationException e) {
		XtextLog.logError(e);
	}

	private boolean hasComment(int lineNummber) {
		return getLineContent(lineNummber).trim().startsWith(COMMENT_STRING);
	}

	private String getLineContent(int i) {
		String retVal = new String();
		try {
			IDocument document = textViewer.getDocument();
			IRegion reg = document.getLineInformation(i);
			retVal = document.get(reg.getOffset(), reg.getLength());
		} catch (BadLocationException e) {
			handleException(e);
		}
		return retVal;
	}
}
