/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.editor;

import org.eclipse.jface.text.formatter.IFormattingStrategy;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public class XtextFormattingStrategy implements IFormattingStrategy {

	public String format(String content, boolean isLineStart,
			String indentation, int[] positions) {
		// TODO implementation
		throw new NotImplementedException();
	}

	public void formatterStarts(String initialIndentation) {
		// TODO implementation
		throw new NotImplementedException();
	}

	public void formatterStops() {
		// TODO implementation
		throw new NotImplementedException();
	}

}
