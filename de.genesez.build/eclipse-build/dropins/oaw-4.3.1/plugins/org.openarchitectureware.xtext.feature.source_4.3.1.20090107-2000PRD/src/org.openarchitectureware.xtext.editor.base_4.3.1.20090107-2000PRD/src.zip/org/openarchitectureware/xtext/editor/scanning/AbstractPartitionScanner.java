/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.scanning;

import java.util.List;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.RuleBasedPartitionScanner;
import org.eclipse.jface.text.rules.Token;

/**
 * 
 * 
 */
public abstract class AbstractPartitionScanner extends RuleBasedPartitionScanner {
    public final static String COMMENT = "__comment";
    public final static String STRING = "__string";
    
    protected final IToken comment = new Token(COMMENT);
    protected final IToken string = new Token(STRING);
    protected final IToken defaultToken = new Token(IDocument.DEFAULT_CONTENT_TYPE);

    public AbstractPartitionScanner() {
        List<IPredicateRule> rules = getRules();
        setPredicateRules(rules.toArray(new IPredicateRule[rules.size()]));
    }
    
    public abstract List<IPredicateRule> getRules();
    
}
