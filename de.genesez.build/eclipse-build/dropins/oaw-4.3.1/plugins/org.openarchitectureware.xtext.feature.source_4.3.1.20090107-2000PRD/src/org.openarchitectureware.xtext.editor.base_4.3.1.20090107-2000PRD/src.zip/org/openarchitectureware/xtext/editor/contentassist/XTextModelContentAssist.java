/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.contentassist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;
import org.eclipse.swt.graphics.Image;
import org.openarchitectureware.xtext.Assignment;
import org.openarchitectureware.xtext.CrossReference;
import org.openarchitectureware.xtext.Element;
import org.openarchitectureware.xtext.EnumLiteral;
import org.openarchitectureware.xtext.FileRef;
import org.openarchitectureware.xtext.Keyword;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.Rule;
import org.openarchitectureware.xtext.StringRule;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;
import org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistFactory;
import org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal;
import org.openarchitectureware.xtext.editor.contentassist.codeassist.Type;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class XTextModelContentAssist implements IContentAssistProcessor {

	private Log log = LogFactory.getLog(getClass());

	private static final String CONTENT_ASSIST_EXTENSIONS = "ContentAssist";
	private AbstractXtextEditor editor;

	public XTextModelContentAssist(LanguageUtilities langUtil,
			AbstractXtextEditor editor) {
		this.langUtil = langUtil;
		this.editor = editor;
	}

	private LanguageUtilities langUtil;

	public ICompletionProposal[] computeCompletionProposals(ITextViewer viewer, int offset) {

		try {
			IDocument doc = viewer.getDocument();
			String wholetext = doc.get();
			return internalComputeProposals(wholetext, offset, editor.getLastResult());
		} catch (Throwable t) {
			XtextLog.logError(t);
		}

		return null;
	}

	/**
	 * No API!
	 */
	@SuppressWarnings("unchecked")
	public ICompletionProposal[] internalComputeProposals(String wholetext,
			int offset, Node node) {
		if (node == null)
			return null;
		String text = wholetext.substring(0, offset);
		Node lastComplete = NodeUtil.getNodeBeforeOffset(node, offset);
		if ((lastComplete != null) && !lastComplete.getErrors().isEmpty()
				&& (lastComplete.getStart() == 0)) {
			lastComplete = null;
		}
		if ((lastComplete != null) && (lastComplete.getParent()) != null) {
			Node parent = lastComplete.getParent();
			if (parent.getGrammarElement() instanceof Assignment) {
				Assignment assignment = (Assignment) parent.getGrammarElement();
				if (assignment.getToken() instanceof CrossReference) {
					for (EObject it = lastComplete.getGrammarElement(); it != null; it = it
					.eContainer()) {
						if (it instanceof StringRule) {
							lastComplete = parent;
							break;
						}
					}
				}
			}
		}

		List<Proposal> proposals = new ArrayList<Proposal>();
		String prefix = null;
		// if lastComplete is under the cursor we look up proposals for
		// completing this node
		// and proposals for possible completions of the preceeding node.
		if (lastComplete != null && lastComplete.getEnd() >= offset) {
			int startReplace;
			int endReplace;

			// get the preceeding node
			Node previous = NodeUtil.getNodeBeforeOffset(lastComplete, lastComplete
					.getStart());

			if (previous == lastComplete) {
				// This case only occurrs in an empty document.
				// Since ANTLR specifies the end of an empty document to be at position 1 (NOT zero),
				// we subtract 1 at this place:
				startReplace = lastComplete.getEnd() - 1;
				endReplace = lastComplete.getEnd() - 1;

				Set<Element> followUps = NodeUtil.getPossibleFollows(langUtil.getXtextFile(),
						lastComplete);
				proposals.addAll(createProposals(lastComplete, null, followUps, startReplace,
						endReplace, true));
			} else {
				Set<Element> followUps;

				// 2008-04-10 Peter:
				// 		Do NOT take the last complete node into consideration,
				//		as this will produce superfluous proposals!
				//				// Last Complete Node
				//				startReplace = lastComplete.getEnd();
				//				endReplace   = lastComplete.getEnd();
				//
				//				followUps = NodeUtil.getPossibleFollows(langUtil.getXtextFile(), lastComplete);
				//				proposals.addAll(createProposals(lastComplete, null, followUps, startReplace, endReplace, false, true));
				//--- end deactivated code

				// Previous Node
				startReplace = lastComplete.getStart();
				endReplace = lastComplete.getEnd();

				prefix = getPrefix(text, previous);
				followUps = NodeUtil.getPossibleFollows(langUtil.getXtextFile(), previous);
				proposals.addAll(createProposals(previous, prefix, followUps, startReplace,
						endReplace, true));
			}
		} else {
			int startReplace;
			int endReplace;
			prefix = getPrefix(text, lastComplete);

			if (lastComplete == null) {
				startReplace = 0;
				endReplace = (prefix == null) ? 0 : prefix.length();
			} else {
				startReplace = (prefix == null) ? offset : offset - prefix.length();
				endReplace = offset;
			}

			Set<Element> followUps = NodeUtil.getPossibleFollows(langUtil.getXtextFile(),
					lastComplete);
			proposals.addAll(createProposals(lastComplete, prefix, followUps, startReplace,
					endReplace, true));
		}

		// sort proposals using an extension (located in an external .ext file):
		Object tmpProposals = langUtil.invokeExtension(CONTENT_ASSIST_EXTENSIONS, "sortProposals",
				proposals);
		if (tmpProposals != null) {
			proposals = (List<Proposal>) tmpProposals;
		}

		List<ICompletionProposal> cp = new ArrayList<ICompletionProposal>();
		for (Proposal pi : proposals) {
			if (!pi.isApplyPrefixFilter()
					|| prefix == null
					|| (pi.getToInsert().toLowerCase().startsWith(prefix
							.toLowerCase()))) {
				cp.add(createCompletionProposal(pi));
			}
		}
		return cp.toArray(new ICompletionProposal[cp.size()]);
	}

	private String getPrefix(String text, Node lastComplete) {
		String prefix = text;
		if (lastComplete != null && lastComplete.getEnd() > 0
				&& lastComplete.getEnd() <= text.length()) {
			prefix = text.substring(lastComplete.getEnd());
		}
		// prefix (in almost all cases) does not end with whitespaces
		return prefix.trim().length() == 0
		|| prefix.substring(prefix.length() - 1, prefix.length()).matches("\\s") ? null
				: prefix.trim();
	}

	@SuppressWarnings("unchecked")
	private List<Proposal> createProposals(Node lastComplete, String prefix,
			Set<Element> followUps, int startReplace, int endReplace, boolean applyPrefixFilter) {
		List<Proposal> proposals = new ArrayList<Proposal>();
		for (Element ele : followUps) {
			List<Proposal> tempResult = null;
			if (ele instanceof Assignment) {
				Assignment ass = (Assignment) ele;

				try {
					tempResult = handleAssignment(ass, lastComplete, prefix);
					if (tempResult != null && !tempResult.isEmpty()) {
						proposals.addAll(tempResult);
						if (!(ass.getToken() instanceof FileRef)) {
							break;
						}
					}
					else {
						proposals.addAll(Collections.EMPTY_LIST);
					}
				} catch (RuntimeException re) {
					XtextLog.logInfo(re.getMessage());
				}
			} else if (ele instanceof Keyword) {
				try {
					tempResult = handleKeyword((Keyword) ele, lastComplete,
							prefix);
					proposals.addAll(tempResult != null ? tempResult
							: Collections.EMPTY_LIST);
				} catch (RuntimeException re) {
					XtextLog.logInfo(re.getMessage());
				}
			} else if (ele instanceof EnumLiteral) {
				try {
					tempResult = handleEnumLiteral((EnumLiteral) ele,
							lastComplete, prefix);
					proposals.addAll(tempResult != null ? tempResult
							: Collections.EMPTY_LIST);
				} catch (RuntimeException re) {
					XtextLog.logInfo(re.getMessage());
				}
			} else {
				try {
					tempResult = handleOther(ele, lastComplete, prefix);
					proposals.addAll(tempResult != null ? tempResult
							: Collections.EMPTY_LIST);
				} catch (RuntimeException re) {
					String message = re.getMessage();
					if (message == null) {
						// Message can be null, so more info is needed here
						//TODO what about above logs and re.getMessage==null?
						XtextLog.logInfo(re.getClass().getSimpleName()
								+ " occurred", re);
					}
					else {
						XtextLog.logInfo(re.getMessage());
					}
				}
			}
		}

		for (Proposal p : proposals) {
			p.setStartReplace(startReplace);
			p.setEndReplace(endReplace);
			p.setApplyPrefixFilter(applyPrefixFilter);
		}

		return proposals;
	}

	protected List<Proposal> handleEnumLiteral(EnumLiteral ele,
			Node lastComplete, String prefix) {
		if (prefix != null && !ele.getKeyword().startsWith(prefix))
			return null;

		EnumLiteral enumLit = ele;
		Proposal p = CodeassistFactory.eINSTANCE.createProposal();
		p.setImage("keyword.gif");
		p.setLabel(enumLit.getKeyword());
		p.setToInsert(enumLit.getKeyword());
		p.setType(Type.ENUM_LITERAL_LITERAL);
		p.setModelElement(NodeUtil.getModelElement(lastComplete));
		return Collections.singletonList(p);
	}

	protected List<Proposal> handleOther(Element ele, Node lastComplete,
			String prefix) {
		//TODO lastComplete is sometimes null
		if (log.isDebugEnabled()) {
			log.debug(ele.eClass().getName() + "-"
					+ (lastComplete.getToken()!=null?lastComplete.getToken().getText():"") + "-" + prefix);
		}
		return null;
	}

	protected List<Proposal> handleKeyword(Keyword ele, Node lastComplete,
			String prefix) {
		if (prefix != null && !ele.getValue().startsWith(prefix))
			return null;
		Proposal p = CodeassistFactory.eINSTANCE.createProposal();
		p.setLabel(ele.getValue());
		p.setToInsert(ele.getValue());
		p.setImage("keyword.gif");
		p.setType(Type.KEYWORD_LITERAL);
		p.setModelElement(NodeUtil.getModelElement(lastComplete));
		return Collections.singletonList(p);
	}

	@SuppressWarnings("unchecked")
	protected List<Proposal> handleAssignment(Assignment ass,
			Node lastComplete, String prefix) {
		EObject modelElement = NodeUtil.getModelElement(lastComplete);
		if (ass.getToken() instanceof FileRef) {
			EList<Resource> resources = editor.getResourceSet().getResources();
			List<Proposal> result = new ArrayList<Proposal>();
			for (Resource resource : resources) {
				Proposal p = CodeassistFactory.eINSTANCE.createProposal();
				URI uri = resource.getURI();
				p.setLabel(uri.toString());
				p.setToInsert("'" + uri + "' ");
				p.setImage("uri.gif");
				p.setModelElement(modelElement);
				p.setType(Type.ASSIGNMENT_LITERAL);
				result.add(p);
			}
			return result;
		}
		// Assignments get a call to
		// completeMyRule_feature(ModelElement ctx, String prefix)
		Rule r = NodeUtil.getContainingRule(ass);
		List<Proposal> proposals = (List<Proposal>) langUtil.invokeExtension(
				CONTENT_ASSIST_EXTENSIONS, "complete" + r.getName() + "_"
				+ ass.getFeature(), modelElement, prefix);
		for (Proposal proposal : proposals) {
			proposal.setModelElement(modelElement);
			proposal.setType(Type.ASSIGNMENT_LITERAL);
		}
		return proposals;
	}

	private ICompletionProposal createCompletionProposal(Proposal p) {
		Image img = langUtil.getImage(p.getImage());
		return new XtextCompletionProposal(p, img);
	}

	public IContextInformation[] computeContextInformation(ITextViewer viewer,
			int offset) {
		return null;
	}

	public char[] getCompletionProposalAutoActivationCharacters() {
		return null;
	}

	public char[] getContextInformationAutoActivationCharacters() {
		return null;
	}

	public IContextInformationValidator getContextInformationValidator() {
		return null;
	}

	public String getErrorMessage() {
		return null;
	}
}
