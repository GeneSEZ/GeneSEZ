/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.Document;
import org.eclipse.jface.text.DocumentEvent;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.rules.FastPartitioner;
import org.eclipse.jface.text.rules.IPartitionTokenScanner;
import org.eclipse.ui.editors.text.FileDocumentProvider;
import org.openarchitectureware.xtext.editor.scanning.AbstractPartitionScanner;

/**
 * @author Sven Efftinge (http://www.efftinge.de)
 * 
 * 
 */
public class DocumentProvider extends FileDocumentProvider {

    public static class XtextDocument extends Document implements IDocument {
    	
    	public void redrawDocument() {
    		fireDocumentChanged(new DocumentEvent(this, 0, getLength(), get()));
    	}
	}

	private IPartitionTokenScanner pscanner;

	public DocumentProvider(IPartitionTokenScanner partitionScanner) {
		this.pscanner = partitionScanner;
	}

	
    @Override
    protected IDocument createDocument(Object element) throws CoreException {
        IDocument document = super.createDocument(element);
        if (document != null) {
            IDocumentPartitioner partitioner = new FastPartitioner(pscanner,
                    new String[] { AbstractPartitionScanner.COMMENT , AbstractPartitionScanner.STRING});
            partitioner.connect(document);
            document.setDocumentPartitioner(partitioner);
        }
        return document;
    }
    
    @Override
    protected IDocument createEmptyDocument() {
    	return new XtextDocument();
    }

}