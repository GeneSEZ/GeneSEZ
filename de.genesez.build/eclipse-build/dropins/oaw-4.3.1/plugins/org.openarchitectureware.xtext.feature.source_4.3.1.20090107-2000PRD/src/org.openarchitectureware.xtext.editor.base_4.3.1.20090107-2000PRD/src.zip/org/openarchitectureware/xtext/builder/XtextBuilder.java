package org.openarchitectureware.xtext.builder;

import java.util.Map;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.common.util.URI;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.openarchitectureware.xtext.editor.marker.MarkerManager;
import org.openarchitectureware.xtext.registry.CachingModelLoad;
import org.openarchitectureware.xtext.registry.JdtClasspathUriResolver;
import org.openarchitectureware.xtext.registry.URIFactory;
import org.openarchitectureware.xtext.registry.XtextResourceSet;

public class XtextBuilder extends IncrementalProjectBuilder {

	class SampleDeltaVisitor implements IResourceDeltaVisitor {
		private final IProgressMonitor monitor;

		public SampleDeltaVisitor(IProgressMonitor monitor) {
			this.monitor = monitor;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.eclipse.core.resources.IResourceDeltaVisitor#visit(org.eclipse.core.resources.IResourceDelta)
		 */
		public boolean visit(IResourceDelta delta) throws CoreException {
			IResource resource = delta.getResource();
			switch (delta.getKind()) {
			case IResourceDelta.ADDED:
				// handle added resource
				updateRegistry(resource, monitor);
				break;
			case IResourceDelta.REMOVED:
				// handle removed resource
				updateRegistry(resource, monitor);
				break;
			case IResourceDelta.CHANGED:
				// handle changed resource
				updateRegistry(resource, monitor);
				break;
			}
			//return true to continue visiting children.
			return true;
		}
	}

	class SampleResourceVisitor implements IResourceVisitor {
		private final IProgressMonitor monitor;

		public SampleResourceVisitor(IProgressMonitor monitor) {
			this.monitor = monitor;
		}

		public boolean visit(IResource resource) {
			updateRegistry(resource, monitor);
			//return true to continue visiting children.
			return true;
		}
	}


	public static final String BUILDER_ID = "org.openarchitectureware.xtext.editor.base.builder";

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.core.internal.events.InternalBuilder#build(int,
	 *      java.util.Map, org.eclipse.core.runtime.IProgressMonitor)
	 */
	@SuppressWarnings("unchecked")
	protected IProject[] build(int kind, Map args, IProgressMonitor monitor)
			throws CoreException {
		if (kind == FULL_BUILD) {
			fullBuild(monitor);
		} else {
			IResourceDelta delta = getDelta(getProject());
			if (delta == null) {
				fullBuild(monitor);
			} else {
				incrementalBuild(delta, monitor);
			}
		}
		return null;
	}

	public static void updateRegistry(IResource resource, IProgressMonitor monitor) {
		if (resource.isDerived())
			return;
        XtextResourceSet resourceSet = new XtextResourceSet();
        IProject project = resource.getProject();
        IJavaProject javaProject = JavaCore.create(project);
        if(javaProject.exists()) {
        	JdtClasspathUriResolver jdtClasspathUriResolver = new JdtClasspathUriResolver();
            resourceSet.setClasspathUriResolver(jdtClasspathUriResolver);
        	resourceSet.setClasspathURIContext(javaProject);
        }
		MarkerManager.parseAndAnalyze(resource, resourceSet, true, true, monitor);
	}

	protected void fullBuild(final IProgressMonitor monitor)
			throws CoreException {
		try {
			getProject().accept(new SampleResourceVisitor(monitor));
		} catch (CoreException e) {
		}
	}


	protected void incrementalBuild(IResourceDelta delta,
			IProgressMonitor monitor) throws CoreException {
		// the visitor does the work.
		delta.accept(new SampleDeltaVisitor(monitor));
	}
}
