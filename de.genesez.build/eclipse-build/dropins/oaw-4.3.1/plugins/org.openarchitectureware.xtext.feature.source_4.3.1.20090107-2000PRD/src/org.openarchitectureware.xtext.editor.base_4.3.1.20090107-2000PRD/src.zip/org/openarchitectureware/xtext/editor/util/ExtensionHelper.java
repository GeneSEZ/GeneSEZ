/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.editor.util;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.openarchitectureware.xtext.Assignment;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.StringRule;
import org.openarchitectureware.xtext.editor.outline.tree.UIContentNode;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;
import org.openarchitectureware.xtext.resource.IXtextResource;

public class ExtensionHelper {

    /**
     * Possible usage:<code><br>
     * EObject result = ExtensionHelper.findDeclaration(LanguageUtilities, Node); <br>
     * if (result != null) {<br>
     * Node target = Registry.getNode(result);<br>
     * IFile targetFile = (IFile) Registry.getContainer(result);<br>
     * }<br>
     * </code>
     * 
     * @param languageUtilities
     * @param destNode
     * @return declaration - can be null
     */
    public static EObject findDeclaration(LanguageUtilities languageUtilities,
            Node destNode, String id) {
        Resource resource = NodeUtil.getModelElement(destNode).eResource();
        if ((!(resource instanceof IXtextResource)) || destNode == null
                || languageUtilities == null)
            return null;
        try {
            Object modelElement = NodeUtil.getModelElement(destNode);
            Object result = languageUtilities.invokeExtension("Navigation",
                    "findDeclaration", id, destNode.getGrammarElement(),
                    modelElement);
            if (result instanceof Collection<?>) {
                Collection<?> c = (Collection<?>) result;
                if (c.isEmpty())
                    return null;
                result = c.iterator().next();
            }
            if (!(result instanceof EObject))
                return null;
            return (EObject) result;
        } catch (RuntimeException e) {
            // ignore
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public static List<UIContentNode> findReferences(
            LanguageUtilities languageUtilities, Node node) {
        Resource resource = NodeUtil.getModelElement(node).eResource();
        if ((!(resource instanceof IXtextResource)) || node == null
                || languageUtilities == null)
            return null;
        try {
            Object modelElement = NodeUtil.getModelElement(node);
            Object result = languageUtilities.invokeExtension("Navigation",
                    "findReferences", node.getToken().getText(), node
                            .getGrammarElement(), modelElement);
            if (result instanceof Collection<?>) {
                Collection<?> c = (Collection<?>) result;
                if (!c.isEmpty())
                    return (List<UIContentNode>) c;
            }
        } catch (RuntimeException e) {
            // ignore
        }
        return null;
    }

    public static Node getFindDeclarationNode(Node current) {
        EObject grammar = current.getGrammarElement();

        if (grammar instanceof Assignment)
            return current;

        while ((grammar != null) && !(grammar instanceof StringRule)) {
            grammar = grammar.eContainer();
        }

        if (grammar != null)
            return current.getParent();

        return current;
    }

    public static Node fixStringRule(Node current) {
        EObject grammar = current.getGrammarElement();

        if (grammar instanceof Assignment)
            return current;

        while ((grammar != null) && !(grammar instanceof StringRule))
            grammar = grammar.eContainer();

        if (grammar != null)
            return current.getParent();

        return current;
    }

    // TODO move to test project
    // public class DeclarationFinderTest extends TestCase {
    //
    // public void testFindWordAtOffset() throws Exception {
    // String text = " This is a text to analyse";
    // assertEquals(new Region(1, 4), ExtensionHelper.findWordAtOffset(text,
    // 3));
    // assertEquals(new Region(6, 2), ExtensionHelper.findWordAtOffset(text,
    // 7));
    // text = "This is a text to analyse";
    // assertEquals(new Region(0, 4), ExtensionHelper.findWordAtOffset(text,
    // 3));
    // text = "This is a text to analyse ";
    // assertEquals(new Region(18, 7), ExtensionHelper.findWordAtOffset(
    // text, 22));
    // text = "This is a text to\t\n\r analyse";
    // assertEquals(new Region(15, 2), ExtensionHelper.findWordAtOffset(
    // text, 16));
    // }
    // }

}
