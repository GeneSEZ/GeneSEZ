/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.wizards;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.XtextLog;

public abstract class AbstractNewProjectWizard extends Wizard implements INewWizard {

	protected GenericNewProjectWizardPage mainPage;

	private String langName;

	private String fileExtension;

	private String packageName;

	private String dslProjectName;

	private String generatorProjectName;

	/**
	 * Constructor for AbstractNewProjectWizard.
	 */
	public AbstractNewProjectWizard() {
		super();
		setNeedsProgressMonitor(true);
	}

	@Override
	public void addPages() {
		super.addPages();
		mainPage = createMainPage();
		addPage(mainPage);
	}

	public String getDslProjectName() {
		return dslProjectName;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public String getLangName() {
		return langName;
	}

	public String getPackageName() {
		return packageName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.ui.IWorkbenchWizard#init(org.eclipse.ui.IWorkbench,
	 * org.eclipse.jface.viewers.IStructuredSelection)
	 */
	public void init(final IWorkbench workbench, final IStructuredSelection selection) {
		// does nothing
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.jface.wizard.Wizard#performFinish()
	 */
	@Override
	public boolean performFinish() {

		try {
			new WorkspaceModifyOperation() {

				@Override
				protected void execute(final IProgressMonitor monitor) throws CoreException, InvocationTargetException,
						InterruptedException {
					try {
						final IProject pr = mainPage.getProjectHandle();
						pr.create(monitor);
						pr.open(monitor);
						final String modelFileName = "model." + getFileExtension();
						ProjectCreator.create(pr, new String[] { getDslProjectName() },
								new String[] { getGeneratorProjectName() }, monitor);
						final IContainer srcFolder = pr.getFolder("src");
						ProjectCreator.createFile(modelFileName, srcFolder, "// model goes here...\n", monitor);
						ProjectCreator.createFile(pr.getName() + ".oaw", srcFolder, "<workflow>\n\t<component file='"
								+ getPackageName() + "generator.oaw'>\n\t\t<modelFile value='" + modelFileName
								+ "' />\n\t\t<targetDir value='src-gen' />\n\t</component>\n</workflow>", monitor);
					}
					catch (final CoreException e) {
						mainPage.setErrorMessage(e.getLocalizedMessage());
					}
				}
			}.run(null);
		}
		catch (final InvocationTargetException e) {
			XtextLog.logError(e);
			return false;
		}
		catch (final InterruptedException e) {
			XtextLog.logError(e);
			return false;
		}
		return true;
	}

	public void setDslProjectName(final String dslProjectName) {
		this.dslProjectName = dslProjectName;
	}

	public void setFileExtension(final String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public void setGeneratorProjectName(final String generatorProjectName) {
		this.generatorProjectName = generatorProjectName;
	}

	public void setLangName(final String langName) {
		this.langName = langName;
	}

	public void setPackageName(final String packageName) {
		this.packageName = packageName;
	}

	abstract protected LanguageUtilities getUtilities();

	private GenericNewProjectWizardPage createMainPage() {
		final GenericNewProjectWizardPage page = new GenericNewProjectWizardPage(getLangName());
		page.setImageDescriptor(ImageDescriptor.createFromImage(getUtilities().getImage("newprj_wiz.png")));
		return page;
	}

	private String getGeneratorProjectName() {
		return generatorProjectName;
	}

}
