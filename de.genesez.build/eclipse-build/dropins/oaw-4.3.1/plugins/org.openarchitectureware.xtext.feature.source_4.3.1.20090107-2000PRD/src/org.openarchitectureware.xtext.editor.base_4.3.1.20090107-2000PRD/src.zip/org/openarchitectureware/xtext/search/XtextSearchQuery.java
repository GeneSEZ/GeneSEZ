/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.search;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.OperationCanceledException;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.search.ui.ISearchQuery;
import org.eclipse.search.ui.ISearchResult;
import org.eclipse.search.ui.text.Match;
import org.eclipse.swt.graphics.Image;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.editor.marker.MarkerManager;
import org.openarchitectureware.xtext.editor.outline.tree.UIContentNode;
import org.openarchitectureware.xtext.editor.util.ExtensionHelper;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class XtextSearchQuery implements ISearchQuery {
	static public String REFERENCE_SEARCH = "Reference";

	private String searchForType;

	private Node node;

	private LanguageUtilities languageUtilities;

	private XtextSearchResult xtextSearchResult;

	private String searchFor;

	public XtextSearchQuery(LanguageUtilities languageUtilities, String type, Node node) {
		this.searchForType = type;
		this.node = node;
		this.searchFor = node.getToken().getText();
		this.languageUtilities = languageUtilities;
	}

	public boolean canRerun() {
		return true;
	}

	public boolean canRunInBackground() {
		return true;
	}

	public String getLabel() {
		return searchForType + " - " + searchFor;
	}

	public ISearchResult getSearchResult() {
		if (xtextSearchResult == null)
			xtextSearchResult = new XtextSearchResult(this);
		return xtextSearchResult;
	}

	public IStatus run(IProgressMonitor monitor) throws OperationCanceledException {
		if (searchForType.equals(REFERENCE_SEARCH)) {
			if (node != null) {
				ISearchResult searchResult = getSearchResult();
				// clean
				if (searchResult instanceof XtextSearchResult) {
					xtextSearchResult = (XtextSearchResult) searchResult;
					xtextSearchResult.removeAll();
				}
				List<UIContentNode> result = ExtensionHelper.findReferences(languageUtilities,node);
				if (result != null) {
					Collections.<UIContentNode>sort(result,new Comparator<UIContentNode>(){

						public int compare(UIContentNode arg0, UIContentNode arg1) {
							Node n1 = NodeUtil.getNode((EObject) arg0.getContext());
							Node n2 = NodeUtil.getNode((EObject) arg1.getContext());
							if (n1==null)
								return -1;
							if (n2==null)
								return 1;
							return ((Integer)n1.getLine()).compareTo(n2.getLine());
						}});
					for (UIContentNode contentNode : result) {
						// null pointer
						EObject context = (EObject) contentNode.getContext();
						Node n = NodeUtil.getNode(context);
						IFile file = MarkerManager.getFile(n);
						Image image = languageUtilities
								.getImage(contentNode.getImage());
						XtextSearchMatch match = new XtextSearchMatch(file, image, searchFor,n.getLine());
						xtextSearchResult.addMatch(new Match(match, n.getStart(), n.getEnd() - n.getStart()));
					}
				}
			}
		}
		return Status.OK_STATUS;
	}
}
