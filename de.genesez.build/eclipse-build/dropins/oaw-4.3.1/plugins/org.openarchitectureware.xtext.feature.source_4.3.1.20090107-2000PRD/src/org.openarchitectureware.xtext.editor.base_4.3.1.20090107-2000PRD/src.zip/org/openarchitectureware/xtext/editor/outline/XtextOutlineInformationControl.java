package org.openarchitectureware.xtext.editor.outline;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import org.eclipse.jface.viewers.AbstractTreeViewer;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.ui.keys.KeySequence;
import org.eclipse.ui.keys.SWTKeySupport;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.editor.AbstractInformationControl;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;
import org.openarchitectureware.xtext.editor.outline.tree.UIContentNode;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class XtextOutlineInformationControl extends AbstractInformationControl {

	private static final String DEFAULT_VP = "default";
	private KeyAdapter fKeyAdapter;
	private List<String> vps;
	private String currentVP;
	private Object lastInfo;

	public XtextOutlineInformationControl(Shell parent, int shellStyle,
			int treeStyle, String commandId, AbstractXtextEditor editor,
			LanguageUtilities utilities) {
		super(parent, shellStyle, treeStyle, commandId, true, editor, utilities);
	}

	@Override
	protected TreeViewer createTreeViewer(Composite parent, int style,
			LanguageUtilities utilities) {
		Tree tree = new Tree(parent, SWT.SINGLE | (style & ~SWT.MULTI));
		GridData gd = new GridData(GridData.FILL_BOTH);
		gd.heightHint = tree.getItemHeight() * 12;
		tree.setLayoutData(gd);
		TreeViewer tv = new TreeViewer(tree);
		tv.setAutoExpandLevel(AbstractTreeViewer.ALL_LEVELS);

		tv.setContentProvider(new UIContentNodeContentProvider());
		tv.setLabelProvider(new UIContentNodeLabelProvider(utilities));
		tv.addFilter(new NamePatternFilter());

		tv.getTree().addKeyListener(getKeyAdapter());
		return tv;
	}

	@Override
	protected Text createFilterText(Composite parent) {
		Text text = super.createFilterText(parent);
		text.addKeyListener(getKeyAdapter());
		return text;
	}

	@Override
	protected String getId() {
		return "org.openarchitectureware.xtext.editor.quickOutline";
	}

	@Override
	public void setInput(Object information, LanguageUtilities utilities) {
		this.lastInfo = information;
		if (information == null || information instanceof String) {
			inputChanged(null, null);
			return;
		}
		if (information instanceof Node) {
			Node current = (Node) information;
			Object result;
			if (currentVP.equals(DEFAULT_VP)) {
				result = utilities.invokeExtension("Outline", "outlineTree",
						NodeUtil.getRoot(current).getModelElement());
			} else {
				result = getUtilities().invokeExtension("Outline",
						"outlineTree_" + currentVP.replaceAll("\\s", "_"),
						getEditor().getRootNode().getModelElement());
			}
			if (result instanceof UIContentNode) {
				UIContentNode uiNode = (UIContentNode) result;
				inputChanged(uiNode, NodeUtil.getModelElement(current));

			}
		}
	}

	private KeyAdapter getKeyAdapter() {
		if (fKeyAdapter == null) {
			fKeyAdapter = new KeyAdapter() {
				public void keyPressed(KeyEvent e) {
					int accelerator = SWTKeySupport
							.convertEventToUnmodifiedAccelerator(e);
					KeySequence keySequence = KeySequence
							.getInstance(SWTKeySupport
									.convertAcceleratorToKeyStroke(accelerator));
					KeySequence[] sequences = getInvokingCommandKeySequences();
					if (sequences == null)
						return;
					for (int i = 0; i < sequences.length; i++) {
						if (sequences[i].equals(keySequence)) {
							e.doit = false;
							toggleShowInheritedMembers();
							return;
						}
					}
				}
			};
		}
		return fKeyAdapter;
	}

	protected String getStatusFieldText() {
		if (currentVP == null) {
			currentVP = DEFAULT_VP;
		}
		if ( getViewPoints().size()==1) {
			return "";
		}
		
		KeySequence[] sequences = getInvokingCommandKeySequences();
		if (sequences == null || sequences.length == 0)
			return ""; //$NON-NLS-1$

		String keySequence = sequences[0].format();

		return "Press " + keySequence + " to show '" + findNextVP()
				+ "' viewpoint";
	}

	private String findNextVP() {
		List<String> vps = getViewPoints();
		int currentVPIndex = vps.indexOf(currentVP);
		if (currentVPIndex == vps.size() - 1) {
			return vps.get(0);
		}
		return vps.get(currentVPIndex + 1);
	}

	private List<String> getViewPoints() {
		if (vps == null) {
			Object result = getUtilities().invokeExtension("Outline",
					"viewpoints");
			if (result instanceof Collection) {
				vps = new ArrayList<String>((Collection) result);
				vps.add(0, DEFAULT_VP);

			} else if (result == null) {
				vps = new ArrayList<String>(1);
				vps.add(DEFAULT_VP);
			} else {
				vps = Collections.EMPTY_LIST;
			}
		}
		return vps;
	}

	public void toggleShowInheritedMembers() {
		Tree tree = getTreeViewer().getTree();
		tree.setRedraw(false);
		
		currentVP = findNextVP();
		setInput(lastInfo);
		updateStatusFieldText();

		tree.setRedraw(true);
	}

}
