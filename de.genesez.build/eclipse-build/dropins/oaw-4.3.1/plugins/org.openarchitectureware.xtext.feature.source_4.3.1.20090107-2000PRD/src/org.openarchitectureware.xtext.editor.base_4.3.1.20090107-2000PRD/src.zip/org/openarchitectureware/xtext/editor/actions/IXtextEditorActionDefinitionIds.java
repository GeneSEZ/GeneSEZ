package org.openarchitectureware.xtext.editor.actions;

public interface IXtextEditorActionDefinitionIds {

	String SHOW_OUTLINE = "org.openarchitectureware.xtext.show.outline";
	int SHOW_OUTLINE_ID= 51;

}
