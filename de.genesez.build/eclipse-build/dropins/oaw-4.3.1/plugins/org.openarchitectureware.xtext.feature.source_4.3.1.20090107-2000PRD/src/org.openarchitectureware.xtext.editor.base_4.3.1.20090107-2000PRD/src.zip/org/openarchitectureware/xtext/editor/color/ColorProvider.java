/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.editor.color;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.widgets.Display;

/**
 * Manager for colors and fonts used in the Template editor
 */
public class ColorProvider {
    protected Map<RGB, Color> ivColorTable = new HashMap<RGB, Color>(10);
    protected HashMap<FontData, Font> ivFontTable = new HashMap<FontData, Font>(10);

    /**
     * Release all of the color resources held onto by the receiver.
     */
    public void dispose() {
        Iterator<Color> e = ivColorTable.values().iterator();
        while (e.hasNext()) {
            e.next().dispose();
        }
        ivColorTable.clear();
        Iterator<Font> f = ivFontTable.values().iterator();
        while (e.hasNext()) {
            f.next().dispose();
        }
        ivFontTable.clear();
    }

    /**
     * Return the Color that is stored in the Color table as rgb. Create new
     * entry, if none can be found.
     * 
     * @param rgb
     *            RGB color to lookup from HashMap
     */
    public Color getColor(RGB aRgb) {
        Color color = ivColorTable.get(aRgb);
        if (color == null) {
            color = new Color(Display.getCurrent(), aRgb);
            ivColorTable.put(aRgb, color);
        }
        return color;
    }
    
    /**
     * Return the Color that is stored in the Color table as rgb. Create new
     * entry, if none can be found.
     * 
     * @param rgb
     *            RGB color to lookup from HashMap
     */
    public Font getFont(FontData aFont) {
    	Font font = ivFontTable.get(aFont);
        if (font == null) {
            font = new Font(Display.getCurrent(), aFont);
            ivFontTable.put(aFont, font);
        }
        return font;
    }
}
