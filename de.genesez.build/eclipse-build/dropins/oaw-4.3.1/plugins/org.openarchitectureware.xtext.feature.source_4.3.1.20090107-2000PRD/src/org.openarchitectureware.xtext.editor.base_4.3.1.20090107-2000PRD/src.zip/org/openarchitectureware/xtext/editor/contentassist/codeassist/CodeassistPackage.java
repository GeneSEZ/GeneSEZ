/**
 * <copyright>
 * </copyright>
 *
 * $Id: CodeassistPackage.java,v 1.2 2008/12/23 21:53:44 pschoenb Exp $
 */
package org.openarchitectureware.xtext.editor.contentassist.codeassist;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.CodeassistFactory
 * @model kind="package"
 * @generated
 */
public interface CodeassistPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "codeassist";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.eclipse.org/emp/xtext/codeassist";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "codeassist";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CodeassistPackage eINSTANCE = org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.CodeassistPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl <em>Proposal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.CodeassistPackageImpl#getProposal()
	 * @generated
	 */
	int PROPOSAL = 0;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL__LABEL = 0;

	/**
	 * The feature id for the '<em><b>To Insert</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL__TO_INSERT = 1;

	/**
	 * The feature id for the '<em><b>Image</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL__IMAGE = 2;

	/**
	 * The feature id for the '<em><b>Data</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL__DATA = 3;

	/**
	 * The feature id for the '<em><b>Model Element</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL__MODEL_ELEMENT = 4;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL__TYPE = 5;

	/**
	 * The feature id for the '<em><b>Start Replace</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL__START_REPLACE = 6;

	/**
	 * The feature id for the '<em><b>End Replace</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL__END_REPLACE = 7;

	/**
	 * The feature id for the '<em><b>Apply Prefix Filter</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL__APPLY_PREFIX_FILTER = 8;

	/**
	 * The number of structural features of the '<em>Proposal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PROPOSAL_FEATURE_COUNT = 9;


	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Type <em>Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Type
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.CodeassistPackageImpl#getType()
	 * @generated
	 */
	int TYPE = 1;


	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal <em>Proposal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Proposal</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal
	 * @generated
	 */
	EClass getProposal();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getLabel()
	 * @see #getProposal()
	 * @generated
	 */
	EAttribute getProposal_Label();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getToInsert <em>To Insert</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>To Insert</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getToInsert()
	 * @see #getProposal()
	 * @generated
	 */
	EAttribute getProposal_ToInsert();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getImage <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Image</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getImage()
	 * @see #getProposal()
	 * @generated
	 */
	EAttribute getProposal_Image();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getData <em>Data</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Data</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getData()
	 * @see #getProposal()
	 * @generated
	 */
	EReference getProposal_Data();

	/**
	 * Returns the meta object for the reference '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getModelElement <em>Model Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Model Element</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getModelElement()
	 * @see #getProposal()
	 * @generated
	 */
	EReference getProposal_ModelElement();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getType()
	 * @see #getProposal()
	 * @generated
	 */
	EAttribute getProposal_Type();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getStartReplace <em>Start Replace</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start Replace</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getStartReplace()
	 * @see #getProposal()
	 * @generated
	 */
	EAttribute getProposal_StartReplace();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getEndReplace <em>End Replace</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>End Replace</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#getEndReplace()
	 * @see #getProposal()
	 * @generated
	 */
	EAttribute getProposal_EndReplace();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#isApplyPrefixFilter <em>Apply Prefix Filter</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Apply Prefix Filter</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Proposal#isApplyPrefixFilter()
	 * @see #getProposal()
	 * @generated
	 */
	EAttribute getProposal_ApplyPrefixFilter();

	/**
	 * Returns the meta object for enum '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Type <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Type</em>'.
	 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Type
	 * @generated
	 */
	EEnum getType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CodeassistFactory getCodeassistFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl <em>Proposal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.ProposalImpl
		 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.CodeassistPackageImpl#getProposal()
		 * @generated
		 */
		EClass PROPOSAL = eINSTANCE.getProposal();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPOSAL__LABEL = eINSTANCE.getProposal_Label();

		/**
		 * The meta object literal for the '<em><b>To Insert</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPOSAL__TO_INSERT = eINSTANCE.getProposal_ToInsert();

		/**
		 * The meta object literal for the '<em><b>Image</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPOSAL__IMAGE = eINSTANCE.getProposal_Image();

		/**
		 * The meta object literal for the '<em><b>Data</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROPOSAL__DATA = eINSTANCE.getProposal_Data();

		/**
		 * The meta object literal for the '<em><b>Model Element</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PROPOSAL__MODEL_ELEMENT = eINSTANCE.getProposal_ModelElement();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPOSAL__TYPE = eINSTANCE.getProposal_Type();

		/**
		 * The meta object literal for the '<em><b>Start Replace</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPOSAL__START_REPLACE = eINSTANCE.getProposal_StartReplace();

		/**
		 * The meta object literal for the '<em><b>End Replace</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPOSAL__END_REPLACE = eINSTANCE.getProposal_EndReplace();

		/**
		 * The meta object literal for the '<em><b>Apply Prefix Filter</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PROPOSAL__APPLY_PREFIX_FILTER = eINSTANCE.getProposal_ApplyPrefixFilter();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.editor.contentassist.codeassist.Type <em>Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.Type
		 * @see org.openarchitectureware.xtext.editor.contentassist.codeassist.impl.CodeassistPackageImpl#getType()
		 * @generated
		 */
		EEnum TYPE = eINSTANCE.getType();

	}

} //CodeassistPackage
