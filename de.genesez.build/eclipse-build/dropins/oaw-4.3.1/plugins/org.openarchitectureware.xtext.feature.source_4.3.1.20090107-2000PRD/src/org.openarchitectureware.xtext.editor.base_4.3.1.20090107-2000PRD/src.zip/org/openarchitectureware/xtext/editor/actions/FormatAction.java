/*******************************************************************************
 * Copyright (c) 2007 Dennis H�bner and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.actions;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.jdt.ui.actions.IJavaEditorActionDefinitionIds;
import org.eclipse.jface.action.Action;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;

public class FormatAction extends Action {

	private Log log = LogFactory.getLog(getClass());

	public FormatAction(AbstractXtextEditor editor) {
		setActionDefinitionId(IJavaEditorActionDefinitionIds.FORMAT);
	}

	@Override
	public void run() {
		log.debug("Formating ");
	}
}
