package org.openarchitectureware.xtext.editor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.swt.widgets.Display;
import org.openarchitectureware.xtext.BaseEditorPlugin;
import org.openarchitectureware.xtext.editor.base.preferences.PreferenceConstants;

public class ResourceSetSynchronizer implements IResourceChangeListener,
		Adapter {

	private Map<IFile, Resource> fileToResourceMap = new HashMap<IFile, Resource>();
	private ResourceSet resourceSet;
	private AbstractXtextEditor editor;

	public ResourceSetSynchronizer(AbstractXtextEditor editor) {
		this.editor = editor;
	}

	public void resourceChanged(IResourceChangeEvent event) {
		try {
			if (BaseEditorPlugin.getDefault().getPreferenceStore().getBoolean(
					PreferenceConstants.SYNC_CHECK_STRATEGY)) {
				IResourceDelta delta = event.getDelta();
				if (delta != null) {
					delta.accept(new IResourceDeltaVisitor() {
						public boolean visit(IResourceDelta delta)
								throws CoreException {
							IResource resource = delta.getResource();
							if (resource instanceof IContainer) {
								return true;
							}
							if (resource instanceof IFile) {
								IFile file = (IFile) resource;
								if (fileToResourceMap.containsKey(file)
										&& (delta.getFlags() & IResourceDelta.CONTENT) != 0) {
									switch (delta.getKind()) {
									case IResourceDelta.CHANGED:
									case IResourceDelta.REMOVED:
										handleFileChange(file);
										break;
									}
								}
							}
							return false;
						}
					});
				}
			}
		} catch (CoreException e) {
			BaseEditorPlugin.getDefault().getLog().log(
					new Status(IStatus.ERROR, BaseEditorPlugin.PLUGIN_ID,
							"Error refreshing resources", e));
		}

	}

	protected void handleFileChange(IFile file) {
		if (!file.equals(editor.getFile())) {
			EList<Resource> resources = resourceSet.getResources();
			for (Resource resource : resources) {
				resource.unload();
			}
			refreshEditor();
		}
	}

	private void refreshEditor() {
		// Disabled because it blocks the UI
		// Display.getDefault().asyncExec(new Runnable() {
		// public void run() {
		// editor.refresh(new NullProgressMonitor(), true);
		// }
		// });
	}

	public Notifier getTarget() {
		return resourceSet;
	}

	public boolean isAdapterForType(Object type) {
		return ResourceSetSynchronizer.class == type;
	}

	public void notifyChanged(Notification notification) {
		if (notification.getFeatureID(ResourceSet.class) == ResourceSet.RESOURCE_SET__RESOURCES) {
			if (notification.getEventType() == Notification.ADD
					|| notification.getEventType() == Notification.ADD_MANY) {
				Object newValue = notification.getNewValue();
				if (newValue instanceof List) {
					for (Object element : ((List<?>) newValue)) {
						addResourceListener(element);
					}
				} else {
					addResourceListener(newValue);
				}
			}
		}
	}

	private void addResourceListener(Object element) {
		if (element instanceof Resource) {
			Resource resource = (Resource) element;
			URI uri = resource.getURI();
			URI normalizedUri = resourceSet.getURIConverter().normalize(uri);
			if (normalizedUri.isPlatformResource()) {
				IPath path = new Path(normalizedUri.toPlatformString(true));
				IWorkspace workspace = ResourcesPlugin.getWorkspace();
				IFile file = workspace.getRoot().getFile(path);
				fileToResourceMap.put(file, resource);
			}
		}
	}

	public void setTarget(Notifier newTarget) {
		this.resourceSet = (ResourceSet) newTarget;
	}

}
