/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext;

import java.io.InputStream;
import java.util.List;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.rules.IPartitionTokenScanner;
import org.eclipse.swt.graphics.Image;
import org.openarchitectureware.xtext.parser.IXtextParser;

/**
 * @author Sven Efftinge (http://www.efftinge.de)
 *
 */
public interface LanguageUtilities {
    
    public IXtextParser parse(InputStream is);
    
    public EPackage getEPackage();
    public XtextFile getXtextFile();

    public List<String> allKeywords();

    public IContentAssistProcessor getContentAssistProcessor();

    public IPartitionTokenScanner getPartitionScanner();

    public void dispose();

	public Image getImage(String name);
	
	
	public String getFileExtension();

	public Object invokeExtension(String extensionFile, String name, Object... params);
}
