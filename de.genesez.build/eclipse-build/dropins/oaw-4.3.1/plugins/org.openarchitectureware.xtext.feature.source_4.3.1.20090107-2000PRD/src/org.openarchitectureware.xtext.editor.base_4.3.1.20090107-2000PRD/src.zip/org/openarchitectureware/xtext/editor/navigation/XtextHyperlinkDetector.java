/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.editor.navigation;

import org.eclipse.core.resources.IFile;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.hyperlink.IHyperlink;
import org.eclipse.jface.text.hyperlink.IHyperlinkDetector;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;
import org.eclipse.ui.texteditor.ITextEditor;
import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.XtextLog;
import org.openarchitectureware.xtext.editor.AbstractXtextEditor;
import org.openarchitectureware.xtext.editor.marker.MarkerManager;
import org.openarchitectureware.xtext.editor.util.ExtensionHelper;
import org.openarchitectureware.xtext.parser.model.NodeUtil;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public class XtextHyperlinkDetector implements IHyperlinkDetector {

	private LanguageUtilities utils;

	private AbstractXtextEditor editor;

	public XtextHyperlinkDetector(AbstractXtextEditor editor,
			LanguageUtilities utilities) {
		this.editor = editor;
		this.utils = utilities;
	}

	public IHyperlink[] detectHyperlinks(ITextViewer textViewer,
			IRegion region, boolean canShowMultipleHyperlinks) {
		if (region == null || textViewer == null) {
			return null;
		}

		// get hyperlinked region
		Node current = NodeUtil.findNodeUnderOffset(NodeUtil.getRoot(editor.getLastResult()),
				region.getOffset());

		if (current == null) {
			return null;
		}

		current = ExtensionHelper.getFindDeclarationNode(current);
		if (current == null) {
			return null;
		}

		current = ExtensionHelper.fixStringRule(current);
		final IRegion hyperlinkRegion = new Region(current.getStart(), current
				.getEnd()
				- current.getStart());
		// get the word that is hyperlinked
		final String hyperlinkedWord = NodeUtil.getText(textViewer
				.getDocument().get(), current);

		try {
			EObject result = ExtensionHelper.findDeclaration(utils, current,
					hyperlinkedWord);
			if (result == null)
				return null;
			Node target = NodeUtil.getNode(result);
			if (target == null)
				return null;
			final IFile targetFile = MarkerManager.getFile(target);
			if (targetFile == null)
				return null;
			final int start = target.getStart();
			final int end = target.getEnd();
			final IWorkbenchPage page = PlatformUI.getWorkbench()
					.getActiveWorkbenchWindow().getActivePage();
			return new IHyperlink[] { new IHyperlink() {

				public IRegion getHyperlinkRegion() {
					return hyperlinkRegion;
				}

				public String getHyperlinkText() {
					return hyperlinkedWord;
				}

				public String getTypeLabel() {
					return null;
				}

				public void open() {
					IEditorPart opened;
					try {
						opened = IDE.openEditor(page, targetFile);
						if (opened instanceof ITextEditor) {
							((ITextEditor) opened).selectAndReveal(start, end
									- start);
						}
					} catch (PartInitException e) {
						XtextLog.logError(e);
					}

				}
			} };
		} catch (RuntimeException e) {
			XtextLog.logError(e);
		}
		return null;
	}

}
