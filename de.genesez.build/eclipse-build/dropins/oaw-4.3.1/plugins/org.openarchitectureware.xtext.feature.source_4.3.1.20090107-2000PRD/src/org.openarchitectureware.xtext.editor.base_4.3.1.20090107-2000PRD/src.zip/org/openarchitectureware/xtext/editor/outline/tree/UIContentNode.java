/**
 * <copyright>
 * </copyright>
 *
 * $Id: UIContentNode.java,v 1.1 2007/08/10 07:19:22 sefftinge Exp $
 */
package org.openarchitectureware.xtext.editor.outline.tree;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>UI Content Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getChildren <em>Children</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getParent <em>Parent</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getLabel <em>Label</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getImage <em>Image</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getContext <em>Context</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.editor.outline.tree.TreePackage#getUIContentNode()
 * @model
 * @generated
 */
public interface UIContentNode extends EObject {
	/**
	 * Returns the value of the '<em><b>Children</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode}.
	 * It is bidirectional and its opposite is '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getParent <em>Parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Children</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Children</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.editor.outline.tree.TreePackage#getUIContentNode_Children()
	 * @see org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getParent
	 * @model type="org.openarchitectureware.xtext.editor.outline.tree.UIContentNode" opposite="parent" containment="true"
	 * @generated
	 */
	EList getChildren();

	/**
	 * Returns the value of the '<em><b>Parent</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parent</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parent</em>' container reference.
	 * @see #setParent(UIContentNode)
	 * @see org.openarchitectureware.xtext.editor.outline.tree.TreePackage#getUIContentNode_Parent()
	 * @see org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getChildren
	 * @model opposite="children" transient="false"
	 * @generated
	 */
	UIContentNode getParent();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getParent <em>Parent</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parent</em>' container reference.
	 * @see #getParent()
	 * @generated
	 */
	void setParent(UIContentNode value);

	/**
	 * Returns the value of the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Label</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Label</em>' attribute.
	 * @see #setLabel(String)
	 * @see org.openarchitectureware.xtext.editor.outline.tree.TreePackage#getUIContentNode_Label()
	 * @model
	 * @generated
	 */
	String getLabel();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getLabel <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label</em>' attribute.
	 * @see #getLabel()
	 * @generated
	 */
	void setLabel(String value);

	/**
	 * Returns the value of the '<em><b>Image</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Image</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image</em>' attribute.
	 * @see #setImage(String)
	 * @see org.openarchitectureware.xtext.editor.outline.tree.TreePackage#getUIContentNode_Image()
	 * @model
	 * @generated
	 */
	String getImage();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getImage <em>Image</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Image</em>' attribute.
	 * @see #getImage()
	 * @generated
	 */
	void setImage(String value);

	/**
	 * Returns the value of the '<em><b>Context</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Context</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Context</em>' attribute.
	 * @see #setContext(Object)
	 * @see org.openarchitectureware.xtext.editor.outline.tree.TreePackage#getUIContentNode_Context()
	 * @model
	 * @generated
	 */
	Object getContext();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.editor.outline.tree.UIContentNode#getContext <em>Context</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Context</em>' attribute.
	 * @see #getContext()
	 * @generated
	 */
	void setContext(Object value);

} // UIContentNode
