/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.check.editor.codeassist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;
import org.eclipse.ui.IEditorPart;
import org.openarchitectureware.OawPlugin;
import org.openarchitectureware.check.codeassist.CheckFastAnalyzer;
import org.openarchitectureware.core.IOawProject;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.codeassist.ExpressionProposalComputer;
import org.openarchitectureware.expression.codeassist.ExtensionImportProposalComputer;
import org.openarchitectureware.expression.codeassist.ProposalFactory;
import org.openarchitectureware.expression.codeassist.TypeProposalComputer;
import org.openarchitectureware.expression.editor.codeassist.AbstractOawContentAssistProcessor;
import org.openarchitectureware.expression.editor.codeassist.ProposalComparator;
import org.openarchitectureware.xtend.XtendFile;
import org.openarchitectureware.xtend.codeassist.Partition;

/**
 * @author Sven Efftinge (http://www.efftinge.de)
 */
public class CheckContentAssistProcessor extends AbstractOawContentAssistProcessor {

	public CheckContentAssistProcessor(final IEditorPart editor) {
		super(editor);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected ICompletionProposal[] internalComputeCompletionProposals(final ITextViewer viewer,
			final int documentOffset) {
		String part = viewer.getDocument().get().substring(0, documentOffset);
		ExecutionContext ctx = OawPlugin.getExecutionContext(getJavaProject());
		final Partition p = CheckFastAnalyzer.computePartition(part);
		final ProposalFactory factory = new CheckProposalFactoryEclipseImpl(documentOffset);
		List proposals = new ArrayList();
		if (p == Partition.EXPRESSION) {
			ctx = CheckFastAnalyzer.computeExecutionContext(part, ctx);
			final int i = part.lastIndexOf(';');
			if (i != -1) {
				part = part.substring(i);
			}
			proposals.addAll(new ExpressionProposalComputer().computeProposals(part, ctx, factory));
// proposals.addAll(new KeywordProposalComputer().computeProposals(part, ctx,
// factory));
		} else if (p == Partition.TYPE_DECLARATION) {
			ctx = CheckFastAnalyzer.computeExecutionContext(part, ctx);
			proposals = new TypeProposalComputer().computeProposals(part, ctx, factory);
		} else if (p == Partition.EXTENSION_IMPORT) {
			IOawProject project = OawPlugin.getOawModelManager().findProject(getFile());
			IOawResource[] resources = project.getAllRegisteredResources();
			Set<String> extensionNames = new HashSet<String>();
			for (IOawResource resource : resources) {
				if (resource instanceof XtendFile) {
					extensionNames.add(resource.getFullyQualifiedName());
				}
			}
			proposals = new ExtensionImportProposalComputer().computeProposals(part, ctx, factory, extensionNames);
		} else if (p == Partition.DEFAULT) {
			proposals = new KeywordProposalComputer().computeProposals(part, ctx, factory);
		}
		Collections.sort(proposals, new ProposalComparator());
		return (ICompletionProposal[]) proposals.toArray(new ICompletionProposal[proposals.size()]);
	}

	/**
	 * {@inheritDoc}
	 */
	public IContextInformation[] computeContextInformation(final ITextViewer viewer, final int documentOffset) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public char[] getCompletionProposalAutoActivationCharacters() {
		return new char[] { '.' };
	}

	/**
	 * {@inheritDoc}
	 */
	public char[] getContextInformationAutoActivationCharacters() {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getErrorMessage() {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public IContextInformationValidator getContextInformationValidator() {
		return null;
	}

}
