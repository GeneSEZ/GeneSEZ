package org.openarchitectureware.compiler.runtime;

import java.util.Arrays;

public abstract class BuiltinCallable implements Callable {
    private final String _name;
    
    private final Class<?>[] _paramTypes; 

    public BuiltinCallable (String name, Class<?>[] paramTypes) {
        _name = name;
        _paramTypes = paramTypes;
    }
    
    public String getName() {
        return _name;
    }

    public Class<?>[] getParamTypes() {
        return _paramTypes;
    }

    public Object invoke(Object[] params) throws Throwable {
        final Object[] actualParams = new Object[params.length - 1];
        System.arraycopy(params, 1, actualParams, 0, actualParams.length);

        return invoke (params[0], actualParams);
    }
    
    @Override
    public String toString() {
        return "Builtin: " + _name + "(" + Arrays.asList(_paramTypes) + ")";
    }
}
