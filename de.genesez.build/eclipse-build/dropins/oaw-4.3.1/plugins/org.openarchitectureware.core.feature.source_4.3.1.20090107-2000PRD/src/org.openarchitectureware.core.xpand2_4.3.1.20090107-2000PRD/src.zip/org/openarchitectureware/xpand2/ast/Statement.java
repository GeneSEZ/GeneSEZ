/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xpand2.ast;

import java.util.Set;

import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.ast.SyntaxElement;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;
import org.openarchitectureware.xpand2.XpandExecutionContext;

public abstract class Statement extends SyntaxElement implements XpandAnalyzable, XpandEvaluatable {

	protected AbstractDefinition containingDefinition;

	public Statement() {
	}

	public final void evaluate(final XpandExecutionContext ctx) {
		try {
			ProgressMonitor monitor = ctx.getMonitor();
			if (monitor != null && monitor.isCanceled())
				return;

			if (ctx.getCallback() != null) {
				ctx.getCallback().pre(this, ctx);
			}
			ctx.getOutput().pushStatement(this, ctx);
			ctx.preTask(this);
			evaluateInternal(ctx);
			ctx.postTask(this);
			ctx.getOutput().popStatement();
		}
		catch (final RuntimeException exc) {
			ctx.handleRuntimeException(exc, this, null);
		}
		finally {
			if (ctx.getCallback() != null) {
				ctx.getCallback().post(null);
			}
		}
	}

	public final void analyze(final XpandExecutionContext ctx, final Set<AnalysationIssue> issues) {
		try {
			if (ctx.getCallback() != null) {
				ctx.getCallback().pre(this, ctx);
			}
			analyzeInternal(ctx, issues);
		}
		catch (final RuntimeException ex) {
			final String message = ex.getMessage();
			if (message != null) {
				issues.add(new AnalysationIssue(AnalysationIssue.INTERNAL_ERROR, ex.getMessage(), this));
			}
			else
				throw ex;
		}
		finally {
			if (ctx.getCallback() != null) {
				ctx.getCallback().post(null);
			}
		}
	}

	protected abstract void evaluateInternal(XpandExecutionContext ctx);

	protected abstract void analyzeInternal(XpandExecutionContext ctx, final Set<AnalysationIssue> issues);

	public AbstractDefinition getContainingDefinition() {
		return containingDefinition;
	}

	public void setContainingDefinition(final AbstractDefinition definition) {
		this.containingDefinition = definition;
	}

}
