package org.openarchitectureware.compiler.helpers;

import java.util.List;

import org.openarchitectureware.xpand2.ast.Template;

/**
 * This class is a container for all information pertaining to a compilation unit.
 */
public class TemplateContext {
    private final Template _template;
    private String _packagePrefix;
    private final String _fileEncoding;
    
    public TemplateContext (Template template, String fileEncoding) {
        _template = template; 
        _fileEncoding = fileEncoding;
    }

    public void setPackagePrefix (String packagePrefix) {
        _packagePrefix = packagePrefix;
    }
    
    public Template getTemplate () {
        return _template;
    }
    
    public String getFileEncoding () {
        return _fileEncoding;
    }
    
    
    private List<String> _importedNs = null;
    public List<String> getImportedNs () {
        if (_importedNs == null)
            _importedNs = _template.getImportedNamespacesAsList();
        
        return _importedNs;
    }
    
    public String getPackagePrefix () {
        return _packagePrefix;
    }
   
    public String getFqnWithoutPackagePrefix () {
        return _template.getFullyQualifiedName();
    }
    
    public String getFqnWithPackagePrefix () {
        return _packagePrefix + "." + _template.getFullyQualifiedName();
    }
}
