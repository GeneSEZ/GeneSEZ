/*******************************************************************************
 * Copyright (c) 2005 - 2007 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.xpand2.debug;

import java.util.List;

import org.openarchitectureware.debug.model.NameValuePair;
import org.openarchitectureware.debug.model.SyntaxElementTO;
import org.openarchitectureware.expression.debug.ExpressionElementAdapter;
import org.openarchitectureware.expression.debug.NoResourceSpecial;
import org.openarchitectureware.xpand2.ast.ExpandStatement;
import org.openarchitectureware.xpand2.ast.FileStatement;
import org.openarchitectureware.xpand2.ast.Statement;
import org.openarchitectureware.xpand2.ast.TextStatement;

/**
 * The IElementAdapter implementation for Xpand statements.
 * 
 * @author Clemens Kadura (zAJKa)
 */
public class XpandElementAdapter extends ExpressionElementAdapter {

	@SuppressWarnings("hiding")
	public static final String TYPE = "xpand";

	// -------------------------------------------------------------------------

	public XpandElementAdapter() {
		super();
		specials.add(new ForEachSpecial());
		specials.add(new ExpandSpecial());
		specials.add(new IfSpecial());
		specials.add(new NoResourceSpecial());
		pres = new XpandModelPresentation(specials);
	}

	// -------------------------------------------------------------------------

	@Override
	public String getAdapterType() {
		return TYPE;
	}

	// -------------------------------------------------------------------------

	@Override
	public boolean canHandle(Object element) {
		if (element instanceof Statement)
			return true;
		if (element instanceof SyntaxElementTO) {
			SyntaxElementTO se = (SyntaxElementTO) element;
			return se.resource.endsWith(".xpt");
		}
		return false;
	}

	@Override
	public boolean shallHandle(Object element) {
		if (element instanceof TextStatement)
			return false;
		if (element instanceof Statement)
			return true;
		return super.shallHandle(element);
	}

	@Override
	public boolean isSurroundingElement(Object element) {
		boolean result;
		result = element instanceof FileStatement;
		result |= element instanceof ExpandStatement;
		return result;
	}

	@Override
	public SyntaxElementTO createEndElementTO(Object element) {
		// Note: is only called with elements of the above mentioned types
		return pres.getEndPresentation((Statement) element, context);
	}

	@Override
	public List<NameValuePair> getVariables(Object element) {
		
		// Beispiel wie inspect implementiert werden kann (hat hier nichts zu
		// suchen, nur als Gedankenst�tze CK)
		// ExpressionFacade ef = new ExpressionFacade(getCtx());
		// Object evaluate = ef.evaluate("");
		// getAllPropertiesFor(getCtx().getType(evaluate), evaluate);
		
		if (element instanceof Statement) {
			return getAllVisibleVariables();
		}
		return super.getVariables(element);
	}
	
	@Override
	public Object findElement(SyntaxElementTO se, Object actual, int flag) {
		if (actual == null)
			return null;
		if (actual instanceof Statement) {
			Statement op = (Statement) actual;
			int start = pres.getStart(op);
			if (se.resource.endsWith(pres.getStringRep(op.getFileName())) && se.start == start)
				return actual;
		}
		return super.findElement(se,actual, flag);
	}

}
