package org.openarchitectureware.xpand2.output;

/**
 * Signals a veto by a {@link VetoStrategy2}�implementation. 
 * @author thoms
 * @since 4.3.1
 */
public class VetoException extends RuntimeException {
	private static final long serialVersionUID = 8376169402481644160L;

	public VetoException(String message) {
		super(message);
	}

}
