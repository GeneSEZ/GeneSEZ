package org.openarchitectureware.compiler.helpers;

public class StringHelper { 
    public static String escape (String s) {
        if (s == null)
            return s;
        
        s = s.replace("\\", "\\\\");
        s = s.replace("\"", "\\\"");
        s = s.replace("\r", "\\r");
        s = s.replace("\n", "\\n");
        s = s.replace("\t", "\\t");
        
        return s;
    }
}
