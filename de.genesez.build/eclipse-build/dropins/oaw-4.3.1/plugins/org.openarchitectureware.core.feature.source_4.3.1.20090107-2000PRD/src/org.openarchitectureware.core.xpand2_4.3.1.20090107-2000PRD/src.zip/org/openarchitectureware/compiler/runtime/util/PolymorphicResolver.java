package org.openarchitectureware.compiler.runtime.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.openarchitectureware.compiler.runtime.Callable;

public class PolymorphicResolver {

    public final Callable getMethod(String name, List<Callable> candidates, Class<?>[] paramTypes) {
        return getMethod(name, candidates, Arrays.asList(paramTypes));
    }
    
    public final Callable getMethod(String name, List<Callable> candidatesRaw, List<Class<?>> paramTypes) {
        final List<Callable> candidates = new ArrayList<Callable>();
        for (Callable c: candidatesRaw) {
            boolean matchingParamTypes = true;
            for (int i=0; i<paramTypes.size(); i++) {
                if (Void.TYPE.equals (paramTypes.get(i)))
                    continue;
                
                if (! c.getParamTypes()[i].isAssignableFrom (paramTypes.get(i)))
                    matchingParamTypes = false;
            }
            if (matchingParamTypes)
                candidates.add (c);
        }
        
        if (candidates.size() == 1)
            return candidates.get(0);
        if (candidates.isEmpty())
            return null; // is checked for --> do NOT throw an exception here!

        // sort features by specialization
        Collections.sort(candidates, _candidateComparator);
        if (_candidateComparator.compare(candidates.get(1), candidates.get(0)) > 0) {
            return candidates.get(0);
        }

        throw new IllegalArgumentException ("ambiguous operation - no unique operation " + name + " for parameter types " + paramTypes);
    }

    private static final Comparator<Callable> _candidateComparator = new Comparator<Callable>() {
        public int compare(Callable m1, Callable m2) {
            final List<Class<?>> pt1 = Arrays.asList(m1.getParamTypes());
            final List<Class<?>> pt2 = Arrays.asList(m2.getParamTypes());
            
            return _typeListComparator.compare(pt1, pt2);
        }
    };

    public static final Comparator<List<Class<?>>> _typeListComparator = new ParamTypeListComparator();
}
