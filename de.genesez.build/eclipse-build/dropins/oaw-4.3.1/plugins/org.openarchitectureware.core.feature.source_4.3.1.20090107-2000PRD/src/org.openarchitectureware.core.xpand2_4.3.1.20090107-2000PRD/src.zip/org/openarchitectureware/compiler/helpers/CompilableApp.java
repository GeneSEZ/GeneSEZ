package org.openarchitectureware.compiler.helpers;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.openarchitectureware.expression.Resource;
import org.openarchitectureware.xpand2.ast.Template;

/**
 * This class represents the transitive closure of a compilation unit with regard
 *  to dependencies, i.e. a compilation unit and all other compilation units it
 *  depends on directly or indirectly. This abstraction serves as input for a compilation.
 * 
 * @author arno
 */
public class CompilableApp {
    private final Map<String, Object> _compilationUnits = new HashMap<String, Object>();
    private final String _fileEncoding;

    public CompilableApp(String fileEncoding) {
        _fileEncoding = fileEncoding;
    }

    public void registerCompilationUnit (String name, Object rootNode) {
        ((Resource) rootNode).setFullyQualifiedName(name);
        
        if (rootNode instanceof Template)
            _compilationUnits.put (name, new TemplateContext ((Template) rootNode, _fileEncoding));
        else
            _compilationUnits.put (name, rootNode);
    }

    public String getPackageName (String cuName) {
        return  cuName.substring (0, cuName.lastIndexOf('.'));
    }
    
    public String getSimpleName (String cuName) {
        return cuName.substring(cuName.lastIndexOf('.') + 1);
    }
    
    public Set<String> getCompilationUnits () {
        return _compilationUnits.keySet();
    }

    public Object getCompilationUnit (String name) {
        return _compilationUnits.get (name);
    }
}
