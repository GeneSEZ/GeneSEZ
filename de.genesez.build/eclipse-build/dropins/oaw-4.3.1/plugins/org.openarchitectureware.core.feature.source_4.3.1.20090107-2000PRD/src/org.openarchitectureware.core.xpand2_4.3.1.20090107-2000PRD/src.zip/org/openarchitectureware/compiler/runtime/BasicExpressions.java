package org.openarchitectureware.compiler.runtime;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openarchitectureware.compiler.runtime.util.EfficientLazyString;
import org.openarchitectureware.compiler.runtime.util.PolymorphicResolver;
import org.openarchitectureware.workflow.util.DoubleKeyCache;
import org.openarchitectureware.workflow.util.Pair;
import org.openarchitectureware.workflow.util.TripleKeyCache;


public abstract class BasicExpressions {
    ///////////////////////////////////////////////////////////////////////
    // mapping of operations to compilation units
    ///////////////////////////////////////////////////////////////////////
    
    private List<Callable> getCallables (String name, int numParams, Class<?> firstType) {
        return _callables.get (name, numParams, firstType);
    }

    private final TripleKeyCache<String, Integer, Class<?>, List<Callable>> _callables = new TripleKeyCache<String, Integer, Class<?>, List<Callable>> () {

        @Override
        protected List<Callable> createNew(String name, Integer numParams, Class<?> firstType) {
            final List<Callable> result = new ArrayList<Callable> ();
            
            final String escapedName = "_" + name;
            
            final List<Pair<Method, Boolean>> resultRaw = getMethodMapping().get (new Pair<String, Integer> (escapedName, numParams));
            
            if (resultRaw != null) {
                for (Pair <Method, Boolean> mtd: resultRaw)
                    result.add(new ExtensionCallable (mtd.getFirst(), mtd.getSecond ()));
            }

            if (firstType != null) {
                for (Method mtd: firstType.getMethods()) {
                    if (! mtd.getName ().equals (name)) 
                        continue;
                    if (mtd.getParameterTypes().length != numParams - 1)
                        continue;

                    result.add(new MethodCallable (mtd));
                }
            }

            addObjectBuiltins (result, name, numParams);
            
            if (String.class.equals (firstType)) {
                addStringBuiltins (result, name, numParams);
            }
            else if (Long.class.equals (firstType)) {
                addIntBuiltins (result, name, numParams);
            }
            else if (firstType != null && Collection.class.isAssignableFrom(firstType)) {
                addCollectionBuiltins (result, name, numParams);
                
                if (List.class.isAssignableFrom(firstType))
                    addListBuiltins (result, name, numParams);
            }
            
            System.err.println (name + " for " + ((firstType != null) ? firstType.getName() : "") + ": " + result);
            return result;
        }
    };
    
    private void addListBuiltins (List<Callable> callables, String name, int numParams) {
        switch (numParams) {
        case 1:
            if ("first".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {List.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        return ((List) first).get (0);
                    }
                });
            else if ("last".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {List.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final List l = (List) first;
                        return l.get (l.size() - 1);
                    }
                });
            else if ("withoutFirst".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {List.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final List result = new ArrayList ((List) first);
                        result.remove(0);
                        return result;
                    }
                });
            else if ("withoutLast".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {List.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final List result = new ArrayList ((List) first);
                        result.remove (result.size() - 1);
                        return result;
                    }
                });
            else if ("reverse".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {List.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final List result = new ArrayList ((List) first);
                        Collections.reverse(result);
                        return result;
                    }
                });
            
                
            break;
        case 2:
            if ("get".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {List.class, Long.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        return ((List) first).get (((Number) params[0]).intValue());
                    }
                });
            break;
        }            
    }
        
    
    private void addCollectionBuiltins (List<Callable> callables, String name, int numParams) {
        switch (numParams) {
        case 1:
            if ("toList".equals (name))
                callables.add (new BuiltinCallable (name, new Class<?>[] {Collection.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        return new ArrayList<Object> ((Collection) first);
                    }
                });
            else if ("toSet".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        return new HashSet<Object> ((Collection) first);
                    }
                });
            else if ("flatten".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        return flattenRec ((Collection) first);
                    }
                    
                    private List<Object> flattenRec(Collection col) {
                        final List<Object> result = new ArrayList<Object>();
                        for (final Object element : col) {
                            if (element instanceof Collection) {
                                result.addAll(flattenRec((Collection) element));
                            } else {
                                result.add(element);
                            }
                        }
                        return result;
                    }
                });

            break;
        case 2:
            if ("toString".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class, String.class}) {
                    @SuppressWarnings("unchecked")
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final StringBuilder result = new StringBuilder ();
                        boolean firstEl = true;
                        for (Object o: (Collection) first) {
                            if (! firstEl)
                                result.append (params[0]);
                            firstEl = false;
                            result.append (o);
                        }
                        return result.toString();
                    }
                });
            else if ("add".equals (name)) {
                removeCallable(callables, name);
                
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class, Object.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        ((Collection) first).add (params[0]);
                        return first;
                    }
                });
            }
            else if ("addAll".equals (name)) {
                removeCallable(callables, name);
                
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class, Collection.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        ((Collection) first).addAll ((Collection) params[0]);
                        return first;
                    }
                });
            }
            else if ("remove".equals (name)) {
                removeCallable(callables, name);
                
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class, Object.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        ((Collection) first).remove (params[0]);
                        return first;
                    }
                });
            }
            else if ("removeAll".equals (name)) {
                removeCallable(callables, name);
                
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class, Collection.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        ((Collection) first).removeAll ((Collection) params[0]);
                        return first;
                    }
                });
            }
            else if ("union".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class, Collection.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final Set<Object> result = new HashSet<Object>((Collection<? extends Object>) first);
                        result.addAll((Collection<? extends Object>) params[0]);
                        return result;
                    }
                });
            else if ("without".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class, Collection.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final Set<Object> result = new HashSet<Object>((Collection<? extends Object>) first);
                        result.removeAll((Collection<? extends Object>) params[0]);
                        return result;
                    }
                });
            else if ("intersect".equals (name))
                callables.add (new BuiltinCallable (name, new Class[] {Collection.class, Collection.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final Set<Object> result = new HashSet<Object>((Collection<? extends Object>) first);
                        result.retainAll((Collection<? extends Object>) params[0]);
                        return result;
                    }
                });
                
            break;
        }
    }
    private void addObjectBuiltins (List<Callable> callables, String name, int numParams) {
        switch (numParams) {
        case 1:
            if ("toString".equals (name)) {
                removeCallable (callables, name);

                callables.add (new BuiltinCallable (name, new Class[] {Object.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        if (first == null)
                            return "null";

                        return first.toString();
                    }
                });
            }
            break;
        case 2:
            if ("compareTo".equals (name)) {
                removeCallable(callables, name);

                callables.add (new BuiltinCallable (name, new Class[] {Object.class, Object.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        if (first == null) {
                            return params[0] == null ? new Long(0) : new Long(-1);
                        }
                        if (params[0] == null)
                            return new Long(1);
                        if (first instanceof Comparable)
                            return new Long(((Comparable<Object>) first).compareTo(params[0]));
                        else {
                            return new Long (first.toString().compareTo (params[0].toString()));
                        }
                    }
                });
            }
            break;
        }
    }

    private void removeCallable (List<Callable> callables, String name) {
        int ind;

        do {
            ind = -1;
            for (int i=0; i<callables.size(); i++) {
                final Callable c = callables.get (i);
                if (name.equals (c.getName())) {
                    ind = i;
                    break;
                }
            }

            if (ind >= 0)
                callables.remove(ind);
        }
        while (ind != -1);
    }

    private void addIntBuiltins (List<Callable> callables, String name, int numParams) {
        switch (numParams) {
        case 2:
            if ("upTo".equals (name))
                callables.add (new BuiltinCallable ("upTo", new Class[] {Number.class, Number.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final Number n1 = (Number) first;
                        final Number n2 = (Number) params[0];

                        final List<Long> result = new ArrayList<Long>();

                        for (long l=n1.longValue(); l<= n2.longValue(); l++)
                            result.add (l);

                        return result;
                    }
                });
            break;
        case 3:
            if ("upTo".equals (name))
                callables.add (new BuiltinCallable ("upTo", new Class[] {Number.class, Number.class, Number.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final Number n1 = (Number) first;
                        final Number n2 = (Number) params[0];
                        final Number n3 = (Number) params[1];

                        final List<Long> result = new ArrayList<Long>();

                        for (long l=n1.longValue(); l<= n2.longValue(); l+=n3.longValue())
                            result.add (l);

                        return result;
                    }
                });
            break;
        }
    }

    private void addStringBuiltins (List<Callable> callables, String name, int numParams) {
        switch (numParams) {
        case 1:
            if ("toFirstUpper".equals (name))
                callables.add (new BuiltinCallable ("toFirstUpper", new Class[] {String.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final String s = (String) first;
                        if (s.length() == 0)
                            return "";
                        if (s.length() == 1)
                            return s.toUpperCase ();
                        return s.substring (0, 1).toUpperCase() + s.substring (1);
                    }
                });
            if ("toFirstLower".equals (name))
                callables.add (new BuiltinCallable ("toFirstLower", new Class[] {String.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final String s = (String) first;
                        if (s.length() == 0)
                            return "";
                        if (s.length() == 1)
                            return s.toLowerCase ();
                        return s.substring (0, 1).toLowerCase() + s.substring (1);
                    }
                });
            if ("toCharList".equals (name))
                callables.add (new BuiltinCallable ("toCharList", new Class[] {String.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final String s = (String) first;
                        final List<String> result = new ArrayList<String>();

                        for (int i=0; i<s.length(); i++)
                            result.add ("" + s.charAt (i));

                        return result;
                    }
                });
            if ("asInteger".equals (name))
                callables.add (new BuiltinCallable ("asInteger", new Class[] {String.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        try {
                            return Long.parseLong ((String) first);
                        }
                        catch (Exception exc) {
                            return null;
                        }
                    }
                });
            break;
        case 2:
            if ("split".equals (name)) {
                removeCallable(callables, "split");
                
                callables.add (new BuiltinCallable ("split", new Class[] {String.class, String.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        return Arrays.asList(((String)first).split ((String)params[0]));
                    }
                });
            }
            break;
        case 3:
            if ("subString".equals (name))
                callables.add (new BuiltinCallable ("subString", new Class[] {String.class, Number.class, Number.class}) {
                    public Object invoke(Object first, Object[] params) throws Throwable {
                        final Number n1 = (Number) params[0];
                        final Number n2 = (Number) params[1];

                        return ((String) first).substring (n1.intValue(), n2.intValue());
                    }
                });
            break;
        }
    }
    
    
    /**
     * this method must be overridden by (typically generated) subclasses, and
     *  these subclass implementations must "merge" their own data with the
     *  method mappings provided by this superclass.
     */
    protected Map<Pair<String, Integer>, List<Pair<Method, Boolean>>> getMethodMapping () {
//      TODO initialize this with the built-in features
        return new HashMap<Pair<String,Integer>, List<Pair <Method, Boolean>>>();
    }

    protected void registerExtensionMethod (Map<Pair<String, Integer>, List<Pair<Method, Boolean>>> cache, Class cls, String name, boolean isCached, Class... paramTypes) {
        try {
            final Method mtd = cls.getDeclaredMethod(name, paramTypes);
            mtd.setAccessible(true);

            final Pair<String, Integer> key = new Pair<String, Integer> (name, paramTypes.length);
            List<Pair<Method, Boolean>> value = cache.get (key);
            if (value == null) {
                value = new ArrayList<Pair<Method, Boolean>>();
                cache.put(key, value);
            }
            value.add(new Pair<Method, Boolean>(mtd, isCached));
        }
        catch (RuntimeException exc) {
            throw exc;
        }
        catch (Exception exc) {
            throw new RuntimeException (exc);
        }
    }

    ///////////////////////////////////////////////////////////////////////
    // helpers
    ///////////////////////////////////////////////////////////////////////
    
    private boolean isReal (Object o) {
        return o instanceof Float || o instanceof Double;
    }

    ///////////////////////////////////////////////////////////////////////
    // miscellaneous
    ///////////////////////////////////////////////////////////////////////

    protected Object __chain__ (Object first, Object second) {
        return second;
    }

    protected Object __create__ (Class cls) throws Exception {
        //TODO EMF behandeln
        
        final Constructor ctor = cls.getConstructor((Class[]) null);
        ctor.setAccessible(true);
        
        return ctor.newInstance();
    }
    
    
    protected Object __definitionCall__ (Class templateClass, String defName, Object target, Object... params) throws Throwable {
        final Object[] allParams = new Object[params.length + 1];
        allParams[0] = target;
        System.arraycopy(params, 0, allParams, 1, params.length);
        
        final Class[] paramTypes = paramTypesForParams(allParams);
        final Callable callable = _theDefinition.get (templateClass, defName, paramTypes);
        return callable.invoke (allParams);
    }
    
    
    private final TripleKeyCache<Class, String, Integer, List<Callable>>  _definitions = new TripleKeyCache<Class, String, Integer, List<Callable>>() {

        @Override
        protected List<Callable> createNew(Class templateClass, String defName, Integer numParamsInclTarget) {
            final List<Callable> result = new ArrayList<Callable>();
            
            for (Method mtd: templateClass.getMethods()) {
                if (! defName.equals(mtd.getName()))
                    continue;
                
                if (! EfficientLazyString.class.equals (mtd.getReturnType()))
                    continue;
                
                if (mtd.getParameterTypes().length == numParamsInclTarget) {
                    result.add (new ExtensionCallable (mtd, false));
                }
            }
            return result;
        }
    };
    
    private final TripleKeyCache<Class, String, Class[], Callable> _theDefinition = new TripleKeyCache<Class, String, Class[], Callable>() {

        @Override
        protected Callable createNew(Class templateClass, String defName, Class[] paramTypesInclTarget) {
            final List<Callable> candidates = _definitions.get(templateClass, defName, paramTypesInclTarget.length);
            return new PolymorphicResolver().getMethod(defName, candidates, paramTypesInclTarget);
        }
    };
    
    private Class[] paramTypesForParams (Object... params) {
        final Class[] result = new Class[params.length];
        for (int i=0; i<params.length; i++) {
            result[i] = (params[i] == null) ? Void.TYPE : params[i].getClass(); 
        }
        return result;
    }
    
    protected Object __operationCall__ (boolean hasTarget, boolean hasThis, Object o, Object __this, String name, Object... params) throws Throwable {
        final Class[] paramTypes = paramTypesForParams(params);

        try {
            if (! hasTarget) {
                final Callable extensionMethod = _extensionsWithoutTarget.get (name, paramTypes);
                if (extensionMethod != null)
                    return extensionMethod.invoke(params);

                if (! hasThis)
                    throw new IllegalArgumentException ("no extension " + name + " found for parameter types " + paramTypeNames(paramTypes));

                o = __this;
            }

            if (o == null) {
                if ("compareTo".equals (name) && params != null && params.length == 1) {
                    // TODO remove this inconsistent, weird special treatment for compareTo!?
                    return params [0] == null ? 0L : -1L;
                }
                
                return null;
            }

            {
                final Callable extensionMethod = _extensionsWithTarget.get (name, o.getClass(), paramTypes);
                if (extensionMethod != null) 
                    return extensionMethod.invoke(o, params);
            }

            if (o instanceof Collection) {
                final List result = new ArrayList ();
                for (Object el: (Collection)o) {
                    final Callable extensionMethod = _extensionsWithTarget.get(name, el.getClass(), paramTypes);
                    if (extensionMethod == null)
                        throw new IllegalArgumentException ("no extension " + name + " found for parameter types " + paramTypeNames(paramTypes) + ".");
                    
                    result.add (extensionMethod.invoke(el, params));
                }
                return result;
            }
            throw new IllegalArgumentException ("no extension " + name + " found for parameter types " + paramTypeNames(paramTypes) + ".");
        }
        catch (InvocationTargetException exc) {
            throw exc.getCause();
        }
    }
    
    
    private final TripleKeyCache<String, Class, Class<?>[], Callable> _extensionsWithTarget = new TripleKeyCache<String, Class, Class<?>[], Callable>() {
        @Override
        protected Callable createNew(String name, Class cls, Class<?>[] paramTypes) {
            final Class[] actualParamTypes = new Class[paramTypes.length + 1];
            actualParamTypes[0] = cls;
            System.arraycopy(paramTypes, 0, actualParamTypes, 1, paramTypes.length);
            
            final List<Callable> candidates = getCallables(name, actualParamTypes.length, cls);
            return new PolymorphicResolver ().getMethod(name, candidates, actualParamTypes);
        }
    };

    private final DoubleKeyCache<String, Class<?>[], Callable> _extensionsWithoutTarget = new DoubleKeyCache<String, Class<?>[], Callable>() {

        @Override
        protected Callable createNew(String name, Class<?>[] paramTypes) {
            final List<Callable> candidates = getCallables(name, paramTypes.length, paramTypes.length > 0 ? paramTypes[0] : null);
            return new PolymorphicResolver ().getMethod(name, candidates, paramTypes);
        }
    };

    private List<String> paramTypeNames (Class[] paramTypes) {
        final List<String> result = new ArrayList<String>();
        for (int i=0; i<paramTypes.length; i++)
            result.add (paramTypes[i].getName());
        
        return result;
    }
    
    /**
     * evaluates a feature of a given object, dispatching calls on a collection to a collection of calls on the objects
     */
    protected Object __feature__ (Object o, String name) throws Throwable {
        if (o instanceof Collection) {
            if ("size".equals (name)) {
                if (o instanceof Collection)
                    return new Long (((Collection)o).size());
            }
            else if ("isEmpty".equals (name)) {
                if (o instanceof Collection)
                    return ((Collection)o).isEmpty();
            }
            
            final List result = new ArrayList ();
            for (Object el: (Collection) o) {
                result.add (__featureInternal__(el, name));
            }
            return result;
        }
        else {
            return __featureInternal__(o, name);
        }
    }
    
    
    /**
     * evaluates a feature that is part of a Java class by invoking the corresponding getter method.
     */    
    private Object __featureInternal__ (Object o, String name) throws Throwable {
        if (o == null)
            return null;
        
        final Class cls = o.getClass();
        //TODO performance optimize this - e.g. by statically precomputing the hashcodes of the feature names and using a switch
        if ("length".equals (name)) {
            if (String.class.equals(cls))
                return ((String) o).length();
        }
        else if ("metaType".equals (name))
            return CompiledExecutionContext.getInstance().getTypeSystem().getType(o);
            
            
        final Method getter = _getterCache.get(cls, name);
        
        try {
            return getter.invoke(o, (Object[]) null);
        }
        catch (InvocationTargetException exc) {
            throw exc.getCause();
        }
    }
    
    private final DoubleKeyCache<Class, String, Method> _getterCache = new DoubleKeyCache<Class, String, Method>() {
        @Override
        protected Method createNew(Class cls, String name) {
            final String upperName = firstUpper(name);
            
            final Method getMtd = _getterMethodCache.get(cls, "get" + upperName);
            if (getMtd != null)
                return getMtd;

            final Method isMtd = _getterMethodCache.get (cls, "is" + upperName);
            if (isMtd != null && (Boolean.class.equals (isMtd.getReturnType()) || Boolean.TYPE.equals(isMtd.getReturnType())))
                return isMtd;
            
            final Method classicMtd = _getterMethodCache.get (cls, upperName);
            if (classicMtd == null)
                throw new IllegalArgumentException ("class " + cls.getName() + " has no feature " + name);
            
            return classicMtd;
        }
    };
    
    private final DoubleKeyCache<Class, String, Method> _getterMethodCache = new DoubleKeyCache<Class, String, Method>() {
        @Override
        protected Method createNew(Class cls, String name) {
            try {
                final Method result = cls.getMethod(name, (Class[])null);
                
                if (Void.TYPE.equals (result.getReturnType()))
                    return null;
                if ((result.getModifiers() & Modifier.PUBLIC) == 0)
                    return null;
                if ((result.getModifiers() & Modifier.STATIC) != 0)
                    return null;
                if ((result.getModifiers() & Modifier.ABSTRACT) != 0)
                    return null;
                
                return result;
            }
            catch (Exception exc) {
                //
            }
            return null;
        }
    };
    
    
    private String firstUpper (String s) {
        if (s.length() == 1)
            return s.toUpperCase();
        return s.substring(0, 1).toUpperCase() + s.substring(1);
    }
    
    
    ///////////////////////////////////////////////////////////////////////
    // comparison 
    ///////////////////////////////////////////////////////////////////////

    protected Boolean __less__ (Object o1, Object o2) {
        if (o1 == null || o2 == null)
            return false;

        if (o1 instanceof Number && o2 instanceof Number) {
            if (isReal(o1) || isReal(o2))
                return ((Number) o1).doubleValue() < ((Number) o2).doubleValue();
            
            return ((Number)o1).longValue() < ((Number)o2).longValue();
        }
        
        return ((Comparable) o1).compareTo(o2) < 0;
    }

    protected Boolean __lessOrEquals__ (Object o1, Object o2) {
        if (o1 == null || o2 == null)
            return o1 == o2;

        if (o1 instanceof Number && o2 instanceof Number) {
            if (isReal(o1) || isReal(o2))
                return ((Number) o1).doubleValue() <= ((Number) o2).doubleValue();
            
            return ((Number)o1).longValue() <= ((Number)o2).longValue();
        }

        return ((Comparable) o1).compareTo(o2) <= 0;
    }
    
    protected Boolean __greater__ (Object o1, Object o2) {
        if (o1 == null || o2 == null)
            return false;
        
        if (o1 instanceof Number && o2 instanceof Number) {
            if (isReal(o1) || isReal(o2))
                return ((Number) o1).doubleValue() > ((Number) o2).doubleValue();
            
            return ((Number)o1).longValue() > ((Number)o2).longValue();
        }

        return ((Comparable) o1).compareTo(o2) > 0;
    }
    
    protected Boolean __greaterOrEquals__ (Object o1, Object o2) {
        if (o1 == null || o2 == null)
            return o1 == o2;
        
        if (o1 instanceof Number && o2 instanceof Number) {
            if (isReal(o1) || isReal(o2))
                return ((Number) o1).doubleValue() >= ((Number) o2).doubleValue();
            
            return ((Number)o1).longValue() >= ((Number)o2).longValue();
        }

        return ((Comparable) o1).compareTo(o2) >= 0;
    }
    
    protected Boolean __equals__ (Object o1, Object o2) {
        if (o1 == o2)
            return true;
        if (o1 == null)
            return false;
        
        if (o1 instanceof Number && o2 instanceof Number) {
            if (isReal(o1) || isReal(o2))
                return ((Number) o1).doubleValue() == ((Number) o2).doubleValue();
            
            return ((Number) o1).longValue() == ((Number)o2).longValue();
        }
        
        return o1.equals (o2);
    }
    
    protected Boolean __notEquals__ (Object o1, Object o2) {
        if (o1 == null)
            return o2 != null;

        if (o1 instanceof Number && o2 instanceof Number) {
            if (isReal(o1) || isReal(o2))
                return ((Number) o1).doubleValue() != ((Number) o2).doubleValue();
            
            return ((Number) o1).longValue() != ((Number)o2).longValue();
        }

        return ! o1.equals (o2);
    }
    
    ///////////////////////////////////////////////////////////////////////
    // arithmetic operations
    ///////////////////////////////////////////////////////////////////////
    
    protected Object __plus__ (Object o1, Object o2) {
        if (o1 instanceof String)
            return ((String) o1) + o2;

        if (o1 == null || o2== null)
            return null;
        
        final Number n1 = (Number) o1;
        final Number n2 = (Number) o2;
        
        if (isReal(o1) || isReal(o2))
            return n1.doubleValue() + n2.doubleValue();
        
        return n1.longValue() + n2.longValue();
    }

    protected Object __minus__ (Object o1, Object o2) {
        if (o1 == null || o2== null)
            return null;
        
        final Number n1 = (Number) o1;
        final Number n2 = (Number) o2;
        
        if (isReal(o1) || isReal(o2))
            return n1.doubleValue() - n2.doubleValue();
        
        return n1.longValue() - n2.longValue();
    }
    
    protected Object __mult__ (Object o1, Object o2) {
        if (o1 == null || o2== null)
            return null;
        
        final Number n1 = (Number) o1;
        final Number n2 = (Number) o2;
        
        if (isReal(o1) || isReal(o2))
            return n1.doubleValue() * n2.doubleValue();
        
        return n1.longValue() * n2.longValue();
    }
    
    protected Object __div__ (Object o1, Object o2) {
        if (o1 == null || o2== null)
            return null;
        
        final Number n1 = (Number) o1;
        final Number n2 = (Number) o2;
        
        if (isReal(o1) || isReal(o2))
            return n1.doubleValue() / n2.doubleValue();
        
        return n1.longValue() / n2.longValue();
    }
    
    ///////////////////////////////////////////////////////////////////////
    // collection expressions
    ///////////////////////////////////////////////////////////////////////

    protected List __collect__ (Object coll, Closure1 closure) throws Throwable {
        if (coll == null)
            return null;

        final List result = new ArrayList();
        for (Object el: (Collection) coll) {
            result.add (closure.exec (el));
        }
        
        return result;
    }
    
    protected List __sortBy__ (Object coll, final Closure1 closure) throws Throwable {
        if (coll == null)
            return null;
        
        List<Object> result = new ArrayList<Object>();
        result.addAll ((Collection) coll);
        Collections.sort(result, new Comparator<Object> () {

            @SuppressWarnings("unchecked")
            public int compare(Object o1, Object o2) {
                Object a;
                try {
                    a = closure.exec (o1);
                final Object b = closure.exec (o2);
                if (a==b)
                    return 0;
                if (a==null)
                    return -1;
                if (b==null)
                    return 1;
                if (a instanceof Comparable)
                    return ((Comparable)a).compareTo(b);
                return a.toString().compareTo(b.toString());
                } catch (Throwable e) {
                    throw new RuntimeException (e);
                }
            }});
        return result;
    }

    
    protected List __select__ (Object coll, Closure1 closure) throws Throwable {
        if (coll == null)
            return null;

        final List result = new ArrayList();
        for (Object el: (Collection) coll) {
            if (Boolean.TRUE.equals(closure.exec (el)))
                result.add (el); 
        }
        
        return result;
    }

    protected Object __selectFirst__ (Object coll, Closure1 closure) throws Throwable {
        if (coll == null)
            return null;
        
        for (Object el: (Collection) coll) {
            if (Boolean.TRUE.equals (closure.exec (el)))
                return el;
        }
        
        return null;
    }

    protected List __reject__ (Object coll, Closure1 closure) throws Throwable {
        if (coll == null)
            return null;

        final List result = new ArrayList();
        for (Object el: (Collection) coll) {
            if (! (Boolean.TRUE.equals(closure.exec (el))))
                result.add (el); 
        }
        
        return result;
    }

    protected Boolean __exists__ (Object coll, Closure1 closure) throws Throwable {
        if (coll == null)
            return null;
        
        for (Object el: (Collection) coll) {
            if (Boolean.TRUE.equals (closure.exec (el)))
                return Boolean.TRUE;
        }
        
        return Boolean.FALSE;
    }

    protected Boolean __notExists__ (Object coll, Closure1 closure) throws Throwable {
        if (coll == null)
            return null;
        
        for (Object el: (Collection) coll) {
            if (Boolean.TRUE.equals (closure.exec (el)))
                return Boolean.FALSE;
        }
        
        return Boolean.TRUE;
    }

    protected Boolean __forAll__ (Object coll, Closure1 closure) throws Throwable {
        if (coll == null)
            return null;
        
        for (Object el: (Collection) coll) {
            if (! (Boolean.TRUE.equals (closure.exec (el))))
                return Boolean.FALSE;
        }
        
        return Boolean.TRUE;
    }
    
    protected List __typeSelect__ (Object coll, Class type) throws Throwable {
        if (coll == null)
            return null;
        
        final List result = new ArrayList ();
        
        for (Object el: (Collection) coll) {
            if (type.isInstance(el))
                result.add (el);
        }
        
        return result;
    }
    
    protected List __typeSelectInt__ (Object coll) throws Throwable {
        if (coll == null)
            return null;
        
        final List result = new ArrayList ();
        
        for (Object el: (Collection) coll) {
            if (el instanceof Number && ! isReal(el))
                result.add (el);
        }
        
        return result;
    }
    
    protected List __typeSelectReal__ (Object coll) throws Throwable {
        if (coll == null)
            return null;
        
        final List result = new ArrayList ();
        
        for (Object el: (Collection) coll) {
            if (el instanceof Number)
                result.add (el);
        }
        
        return result;
    }
    
    
    ///////////////////////////////////////////////////////////////////////
    // helper classes
    ///////////////////////////////////////////////////////////////////////
    
    protected interface Closure {
        Object exec () throws Throwable;
    }

    protected interface Closure1 {
        Object exec (Object o) throws Throwable;
    }
}
