/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.workflow;

import org.openarchitectureware.workflow.container.CompositeComponent;

public class Workflow extends CompositeComponent {

	private boolean isAbstract;

	public Workflow() {
		super("workflow");
	}

	/**
	 * Sets if the workflow is abstract or not.
	 * 
	 * @param abs
	 *            if <code>true</code>, the workflow is abstract, if
	 *            <code>false</code> it is concrete.
	 */
	public void setAbstract(boolean abs) {
		isAbstract = abs;
	}

	/**
	 * Checks if the workflow is abstract.
	 * 
	 * @return <code>true</code> if the workflow is abstract, otherwise
	 *         <code>false</code>
	 */
	public boolean isAbstract() {
		return isAbstract;
	}

}
