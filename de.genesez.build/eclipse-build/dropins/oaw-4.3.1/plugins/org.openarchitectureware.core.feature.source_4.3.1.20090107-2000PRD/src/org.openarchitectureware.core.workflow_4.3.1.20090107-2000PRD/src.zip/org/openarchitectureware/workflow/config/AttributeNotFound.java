package org.openarchitectureware.workflow.config;

public class AttributeNotFound extends Exception {
	private static final long serialVersionUID = 1L;

	public AttributeNotFound() {
		super();
	}
	
	public AttributeNotFound(String message) {
		super(message);
	}
	
}
