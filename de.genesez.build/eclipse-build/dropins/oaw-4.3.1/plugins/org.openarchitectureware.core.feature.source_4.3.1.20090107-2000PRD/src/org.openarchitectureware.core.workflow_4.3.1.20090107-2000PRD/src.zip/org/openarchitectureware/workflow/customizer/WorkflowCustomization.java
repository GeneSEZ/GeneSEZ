package org.openarchitectureware.workflow.customizer;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class WorkflowCustomization {

	private static Map<String,Class<?>> keywordmapping = new HashMap<String,Class<?>>();

	private static final Log logger = LogFactory.getLog(WorkflowCustomization.class);

	public static void registerKeywordMapping( String keyword, Class<?> componentClass ) {
		keywordmapping .put( keyword, componentClass );
	}
	
	public static void registerKeywordMapping( String keyword, String componentClassName ) {
		try {
			keywordmapping .put( keyword, Class.forName(componentClassName) );
		} catch (ClassNotFoundException e) {
			logger.warn("Cannot resolve keyword class "+componentClassName);
		}
	}
	
	public static Class<?> getKeywordMapping( String keyword ) {
		return keywordmapping.get(keyword);
	}
	
	
}
