/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.workflow.lib;

import org.openarchitectureware.workflow.WorkflowComponentWithID;
import org.openarchitectureware.workflow.ast.parser.Location;
import org.openarchitectureware.workflow.container.CompositeComponent;
import org.openarchitectureware.workflow.issues.Issues;

/**
 * Base class useful for implementing custom WorkflowComponents.
 * 
 * @author Markus Voelter (impl)
 * @author Karsten Thoms (doc)
 * @since 4.0
 */
public abstract class AbstractWorkflowComponent implements WorkflowComponentWithID {
	/** The component's id */
	private String componentID;

	/** Container component */
	private CompositeComponent container;

	private Location location;

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponentWithID#getId()
	 */
	public String getId() {
		return componentID;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponentWithID#setId(java.lang.String)
	 */
	public void setId(final String id) {
		componentID = id;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getContainer()
	 */
	public CompositeComponent getContainer() {
		return container;
	}

	/**
	 * @param container
	 *            The containing component
	 */
	public void setContainer(CompositeComponent container) {
		this.container = container;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponentWithID#getLogMessage()
	 */
	public String getLogMessage() {
		return null;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getLocation()
	 */
	public Location getLocation() {
		return location;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#setLocation(org.openarchitectureware.workflow.ast.parser.Location)
	 */
	public void setLocation(final Location location) {
		this.location = location;
	}
	
	
	/**
	 * Override this method by custom components.
	 * @return Simple class name as default. 
	 * @since 4.3.1
	 */
	public String getComponentName() {
		return getClass().getSimpleName();
	}

	/**
	 * Utility method that can be used in method <code>checkConfiguration</code>
	 * to check required properties. If <code>configPropertyValue</code> is
	 * <code>null</code> or a blank string then this method will add an error
	 * issue.
	 * 
	 * @param configPropertyName
	 *            Name of the checked config property.
	 * @param configPropertyValue
	 *            The config property value.
	 * @param issues
	 *            The Issues instance.
	 */
	public void checkRequiredConfigProperty(String configPropertyName, Object configPropertyValue, Issues issues) {
		boolean isError = false;
		if (configPropertyValue == null) {
			isError = true;
		}
		else if ((configPropertyValue instanceof String) && isBlank(configPropertyValue.toString())) {
			isError = true;
		}

		if (isError) {
			issues.addError("'" + configPropertyName + "' not specified.");
		}
	}

	private boolean isBlank(String string) {
		if (string == null || string.trim().equals(""))
			return true;
		return false;
	}

}
