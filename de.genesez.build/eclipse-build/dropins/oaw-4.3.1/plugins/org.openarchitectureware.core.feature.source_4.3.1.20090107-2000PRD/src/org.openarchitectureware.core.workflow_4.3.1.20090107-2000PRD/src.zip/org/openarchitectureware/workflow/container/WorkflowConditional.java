package org.openarchitectureware.workflow.container;


public interface WorkflowConditional {

	public boolean evaluate();
	
}
