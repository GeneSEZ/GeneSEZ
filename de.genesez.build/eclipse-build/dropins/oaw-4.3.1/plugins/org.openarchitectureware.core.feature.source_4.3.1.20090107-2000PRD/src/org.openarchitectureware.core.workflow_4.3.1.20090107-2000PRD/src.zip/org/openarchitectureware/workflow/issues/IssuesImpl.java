/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.workflow.issues;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.openarchitectureware.workflow.WorkflowComponent;
import org.openarchitectureware.workflow.util.ComponentPrinter;

public class IssuesImpl implements Issues {
    private final List<Issue> warnings = new ArrayList<Issue>();

    private final List<Issue> errors = new ArrayList<Issue>();

    public void addError(final WorkflowComponent ctx, final String msg, final Object element) {
        addError(new Issue(ctx, msg, element));
    }

    private void addError(final Issue issue) {
        errors.add(issue);
    }

    public void addWarning(final WorkflowComponent ctx, final String msg, final Object element) {
        addWarning(new Issue(ctx, msg, element));
    }

    private void addWarning(final Issue issue) {
        warnings.add(issue);
    }

    public void addError(final WorkflowComponent ctx, final String msg) {
        addError(ctx, msg, null);
    }

    public void addWarning(final WorkflowComponent ctx, final String msg) {
        addWarning(ctx, msg, null);
    }

    public void addWarning(final String msg, final Object element) {
        addWarning(new Issue(msg, element));
    }

    public void addError(final String msg, final Object element) {
        addError(new Issue(msg, element));
    }

    public void addWarning(final String msg) {
        addWarning(msg, null);
    }

    public void addError(final String msg) {
        addError(msg, null);
    }

    public boolean hasErrors() {
        return !errors.isEmpty();
    }

    public Issue[] getErrors() {
        return errors.toArray(new Issue[errors.size()]);
    }

    public Issue[] getWarnings() {
        return warnings.toArray(new Issue[warnings.size()]);
    }

    @Override
    public String toString() {
        final StringBuffer buff = new StringBuffer();
        Issue[] issues = getWarnings();
        for (int i = 0; i < issues.length; i++) {
            final Issue issue = issues[i];
            buff.append("\n[WARNING] : " + issue.getMessage());
            if (issue.getElement() != null) {
                buff.append(" - for " + getElementStringRep(issue));
            }
            if (issue.getContext() != null) {
                buff.append(" - reported by: " + ComponentPrinter.getString(issue.getContext()));
            }
        }
        issues = getErrors();
        for (int i = 0; i < issues.length; i++) {
            final Issue issue = issues[i];
            buff.append("\n[ERROR] : " + issue.getMessage());
            if (issue.getElement() != null) {
                buff.append(" - for " + getElementStringRep(issue));
            }
            if (issue.getContext() != null) {
                buff.append(" - reported by: " + ComponentPrinter.getString(issue.getContext()));
            }
        }
        return buff.toString();
    }

    private String getElementStringRep(final Issue issue) {
		Object element = issue.getElement();
		if (element instanceof EObject ) {
			EObject eo = (EObject)element;
			String name = getEName(eo);
			if ( name == null ) return eo.toString();
			StringBuffer qfn = new StringBuffer();
			qfn.append(name);
			while ( eo.eContainer() != null ) {
				eo = eo.eContainer();
				name = getEName(eo);
				if ( name != null ) {
					qfn.insert(0, name+".");
				}
			} 
			return qfn.toString();
		}
		return element.toString();
	}

    private String getEName(EObject eo) {
		EStructuralFeature f = eo.eClass().getEStructuralFeature("name");
		if ( f == null ) return null;
		return (String)eo.eGet( f );
	}
	
    public void clear() {
    	errors.clear();
    	warnings.clear();
    }
}
