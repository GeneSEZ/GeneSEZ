/*******************************************************************************
 * Copyright (c) 2005 - 2007 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.debug.processing.handlers;

import java.io.IOException;
import java.util.Stack;

import org.openarchitectureware.debug.communication.Connection;
import org.openarchitectureware.debug.communication.packets.ConfirmationPacket;
import org.openarchitectureware.debug.communication.packets.EventPacket;
import org.openarchitectureware.debug.communication.packets.EventPacketWithFrames;
import org.openarchitectureware.debug.model.SyntaxElementTO;
import org.openarchitectureware.debug.processing.DebugMonitor;
import org.openarchitectureware.debug.processing.IElementAdapter;
import org.openarchitectureware.debug.processing.IRuntimeHandler;
import org.openarchitectureware.debug.processing.IEventHandler;

/**
 * This class handles the communication of debug events on the runtime side.<br>
 * It sends them out (together with addition syntax element information, if required).
 * 
 * @author Clemens Kadura (zAJKa)
 */
public class EventRuntimeHandler implements IRuntimeHandler, IEventHandler {
	public static final int STARTED = 1;

	public static final int SUSPENDED = 2;

	public static final int RESUMED = 3;

	public static final int TERMINATED = 4;

	private Connection connection;

	private DebugMonitor monitor;

	private Stack<Frame> stackFrames = new Stack<Frame>();

	private int cleanStackLevel = 0;

	// -------------------------------------------------------------------------

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.openarchitectureware.debug.processing.IRuntimeHandler#init(org.openarchitectureware.debug.processing.DebugMonitor,
	 *      org.openarchitectureware.debug.communication.Connection)
	 */
	public void init(DebugMonitor monitor, Connection connection) {
		this.monitor = monitor;
		this.connection = connection;
		monitor.addEventHandler(this);
	}

	/**
	 * no need to listen
	 * 
	 * @see org.openarchitectureware.debug.processing.IRuntimeHandler#startListener()
	 */
	public void startListener() {
	}

	// -------------------------------------------------------------------------

	/**
	 * Send STARTED event to the debug server
	 * 
	 * @see org.openarchitectureware.debug.processing.IEventHandler#started()
	 */
	public void started() throws IOException {
		sendEvent(STARTED);
	}

	/**
	 * Push the element onto the stack
	 * 
	 * @see org.openarchitectureware.debug.processing.IEventHandler#preTask(java.lang.Object, int)
	 */
	public void preTask(Object element, Object context, int state) {
		stackFrames.push(new Frame(element, context, state));
	}

	/**
	 * Pop the element from the stack, adjust the cleanStackLevel value if required
	 * 
	 * @see org.openarchitectureware.debug.processing.IEventHandler#postTask()
	 */
	public void postTask(Object context) {
		if (cleanStackLevel >= stackFrames.size())
			cleanStackLevel--;
		stackFrames.pop();
	}

	/**
	 * Send SUSPENDED event to the debug server together with the number of stack elements that are still the same
	 * (cleanStackLevel) since the last suspend and all new SyntaxElementTOs.<br>
	 * Wait for a confirmation. In the meantime other threads could handle for instance variable requests.
	 * 
	 * @see org.openarchitectureware.debug.processing.IEventHandler#suspended()
	 */
	public void suspended() throws IOException {
		EventPacketWithFrames event = new EventPacketWithFrames(SUSPENDED);
		event.cleanStackLevel = cleanStackLevel;

		for (int i = cleanStackLevel; i < stackFrames.size(); i++) {
			Frame frame = stackFrames.get(i);
			SyntaxElementTO to;
			IElementAdapter adapter = monitor.getAdapter(frame.element);
			adapter.setContext(frame.context);
			if (frame.state == NORMAL_FRAME)
				to = adapter.createElementTO(frame.element);
			else
				to = adapter.createEndElementTO(frame.element);
			to.type = adapter.getAdapterType();
			to.frameId = i;
			event.frames.add(to);

		}

		sendAndConfirm(event);
		cleanStackLevel = stackFrames.size();
	}

	/**
	 * Send RESUMED event to the debug server
	 * 
	 * @see org.openarchitectureware.debug.processing.IEventHandler#resumed()
	 */
	public void resumed() throws IOException {
		sendEvent(RESUMED);
	}

	/**
	 * Send TERMINATED event to the debug server
	 * 
	 * @see org.openarchitectureware.debug.processing.IEventHandler#terminated()
	 */
	public void terminated() throws IOException {
		sendEvent(TERMINATED);
	}

	// -------------------------------------------------------------------------

	private void sendEvent(int type) throws IOException {
		EventPacket event = new EventPacket(type);
		sendAndConfirm(event);
	}

	private void sendAndConfirm(EventPacket event) throws IOException {
		int refId = connection.sendPacket(event);
		connection.listenForPacket(ConfirmationPacket.class, refId);
	}

	// -------------------------------------------------------------------------
	private class Frame {
		final Object element;

		final int state;

		final Object context;

		private Frame(Object element, Object context, int state) {
			this.element = element;
			this.context = context;
			this.state = state;
		}
	}

}
