/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.workflow.container;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openarchitectureware.workflow.ConfigurationException;
import org.openarchitectureware.workflow.Workflow;
import org.openarchitectureware.workflow.WorkflowComponent;
import org.openarchitectureware.workflow.WorkflowComponentWithID;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.ao.AbstractWorkflowAdvice;
import org.openarchitectureware.workflow.ast.parser.Location;
import org.openarchitectureware.workflow.config.FeatureComponent;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;
import org.openarchitectureware.workflow.util.ComponentPrinter;

/**
 * A composite <tt>WorkflowComponent</tt>.
 * 
 * @author Sven Efftinge (http://www.efftinge.de)
 * @since 4.0
 */
/**
 * @author Patrick Schoenbach - Initial API and implementation
 * @version $Revision: 1.31 $
 */
public class CompositeComponent extends AbstractWorkflowComponent {
	private static final String COMPONENT_NAME = "Composite Component";

	protected Log log = LogFactory.getLog(getClass());

	private String name;

	private String resource;

	private Location location;

	private Location ownLocation;

	private CompositeComponent container;

	public CompositeComponent(final String name) {
		this.name = name;
	}

	/** All components aggregated by this composite */
	protected List<WorkflowComponent> components = new ArrayList<WorkflowComponent>();

	private String id;

	/**
	 * Returns a list of aggregated components.
	 * 
	 * @return list of components
	 */
	public List<WorkflowComponent> getComponents() {
		return components;
	}

	/**
	 * @see org.openarchitectureware.workflow.lib.AbstractWorkflowComponent#getId()
	 */
	@Override
	public String getId() {
		return id;
	}

	/**
	 * @see org.openarchitectureware.workflow.lib.AbstractWorkflowComponent#setId(java.lang.String)
	 */
	@Override
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @see org.openarchitectureware.workflow.lib.AbstractWorkflowComponent#getLogMessage()
	 */
	@Override
	public String getLogMessage() {
		return "CompositeComponent " + (id != null ? id : "");
	}

	/**
	 * Dispatches the invocation to all aggregated components.
	 * 
	 * @see org.openarchitectureware.workflow.WorkflowComponent#invoke(org.openarchitectureware.workflow.WorkflowContext,
	 *      org.openarchitectureware.workflow.monitor.ProgressMonitor,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	public void invoke(final WorkflowContext ctx, final ProgressMonitor monitor, final Issues issues) {
		internalInvoke(ctx, monitor, issues);
	}

	private void internalInvoke(final WorkflowContext model, final ProgressMonitor monitor, final Issues issues) {
		for (final Iterator<WorkflowComponent> iter = components.iterator(); iter.hasNext();) {
			if (monitor != null && monitor.isCanceled()) {
				break;
			}

			final WorkflowComponent comp = iter.next();

			if ((!(comp instanceof AbstractWorkflowAdvice))) {
				comp.setContainer(this);
				if (monitor != null) {
					monitor.preTask(comp, model);
				}
				log.info(ComponentPrinter.getString(comp));
				comp.invoke(model, monitor, issues);
				if (monitor != null) {
					monitor.postTask(comp, model);
				}
			}
		}
	}

	public void checkConfiguration(final Issues issues) throws ConfigurationException {
		for (final Iterator<WorkflowComponent> iter = components.iterator(); iter.hasNext();) {
			final WorkflowComponent comp = iter.next();
			if (comp instanceof AbstractWorkflowAdvice) {
				AbstractWorkflowAdvice advice = (AbstractWorkflowAdvice) comp;
				String adviceTargetID = advice.getAdviceTarget();
				if (adviceTargetID == null) {
					issues.addError(advice, "No 'adviceTarget' given.");
					continue;
				}
				// log.info("Weaving Advice: " +
				// ComponentPrinter.getString(comp));
				Collection<WorkflowComponent> targetComponents = findComponentByID(adviceTargetID);
				if (targetComponents.size() == 0) {
					issues.addWarning(advice, "No component with ID '" + adviceTargetID + "' found.");
				}
				if (targetComponents.size() > 1) {
					issues.addWarning(advice, "More than on component with ID '" + adviceTargetID + "' found.");
				}
				if (needsToWeave(comp, issues)) {
					for (WorkflowComponent c : targetComponents) {
						((AbstractWorkflowAdvice) comp).weave(c, issues);
					}
				}
			}
		}
		for (final Iterator<WorkflowComponent> iter = components.iterator(); iter.hasNext();) {
			final WorkflowComponent comp = iter.next();
			if ((!(comp instanceof AbstractWorkflowAdvice))) {
				if (log.isDebugEnabled()) {
					log.debug("Checking configuration of: " + ComponentPrinter.getString(comp));
				}
				comp.checkConfiguration(issues);
			}
		}
	}

	private boolean needsToWeave(WorkflowComponent comp, Issues issues) {
		try {
			WorkflowComponent current = comp;
			while (current != null) {
				if (current instanceof WorkflowConditional) {
					WorkflowConditional cond = (WorkflowConditional) current;
					if (!cond.evaluate())
						return false;
				}
				current = current.getContainer();
			}
			return true;
		}
		catch (ConditionEvaluationException ex) {
			issues.addError(this, ex.getMessage());
			return false;
		}
	}

	private Collection<WorkflowComponent> findComponentByID(String adviceTargetID) {
		List<WorkflowComponent> hits = new ArrayList<WorkflowComponent>();
		WorkflowComponent c = this;
		while (c.getContainer() != null) {
			c = c.getContainer();
		}
		((CompositeComponent) c).resolveComponentByID(adviceTargetID, hits);
		return hits;
	}

	private void resolveComponentByID(String adviceTargetID, List<WorkflowComponent> hits) {
		for (WorkflowComponent component : components) {
			if (component instanceof WorkflowComponentWithID) {
				if (adviceTargetID.equals(((WorkflowComponentWithID) component).getId())) {
					hits.add(component);
				}
			}
		}
		for (WorkflowComponent component : components) {
			if (component instanceof CompositeComponent) {
				((CompositeComponent) component).resolveComponentByID(adviceTargetID, hits);
			}
		}
	}

	/**
	 * Returns the name of the component.
	 * 
	 * @return name of component
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the filename of the workflow.
	 * 
	 * @return the filename
	 */
	public String getResource() {
		return resource;
	}

	/**
	 * Sets the filename of the workflow.
	 * 
	 * @param resource
	 *            the filename
	 */
	public void setResource(final String resource) {
		this.resource = resource;
	}

	/**
	 * Returns the location of the entry in the parent workflow file.
	 * 
	 * @see org.openarchitectureware.workflow.lib.AbstractWorkflowComponent#getLocation()
	 */
	@Override
	public Location getLocation() {
		return location;
	}

	/**
	 * Sets the location of the entry in the parent workflow file.
	 * 
	 * @see org.openarchitectureware.workflow.lib.AbstractWorkflowComponent#setLocation(org.openarchitectureware.workflow.ast.parser.Location)
	 */
	@Override
	public void setLocation(final Location location) {
		this.location = location;
	}

	/**
	 * Returns the location of the start and closing tags in the actual workflow
	 * file.
	 * 
	 * @return the location
	 */
	public Location getOwnLocation() {
		return ownLocation;
	}

	/**
	 * Sets the location of the start and closing tags in the actual workflow
	 * file.
	 * 
	 * @param endLocation
	 *            the location
	 */
	// locations are set from VisitorCreator by reflection
	public void setOwnLocation(Location endLocation) {
		this.ownLocation = endLocation;
	}

	/**
	 * Adds a bean.
	 * 
	 * @param obj
	 *            the bean
	 */
	public void addBean(final Object obj) {
		// noop
	}

	/**
	 * Sets the aggregated components of this composite.
	 * 
	 * @param components
	 *            Components to aggregate.
	 */
	public void addComponent(final WorkflowComponent component) {
		components.add(component);
		component.setContainer(this);
	}

	/**
	 * Sets the aggregated components of this composite.
	 * 
	 * @param components
	 *            Components to aggregate.
	 */
	public void addCartridge(final Workflow cartridge) {
		components.add(cartridge);
		cartridge.setContainer(this);
	}

	/**
	 * adds a conditionalcompositecomponent to the list of components
	 * 
	 * @param comp
	 *            the conditional component
	 */
	public void addIf(final IfComponent comp) {
		addComponent(comp);
	}

	/**
	 * adds a feature components to the list of components
	 * 
	 * @param comp
	 *            the feature component
	 */
	public void addFeature(final FeatureComponent comp) {
		addComponent(comp);
	}

	/**
	 * @see org.openarchitectureware.workflow.lib.AbstractWorkflowComponent#getContainer()
	 */
	@Override
	public CompositeComponent getContainer() {
		return container;
	}

	/**
	 * @see org.openarchitectureware.workflow.lib.AbstractWorkflowComponent#setContainer(org.openarchitectureware.workflow.container.CompositeComponent)
	 */
	@Override
	public void setContainer(CompositeComponent container) {
		this.container = container;
	}

	/**
	 * Adds a workflow component.
	 * 
	 * @param comp
	 *            the component
	 */
	public void put(WorkflowComponent comp) {
		addComponent(comp);
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getComponentName()
	 */
	public String getComponentName() {
		return COMPONENT_NAME;
	}

}
