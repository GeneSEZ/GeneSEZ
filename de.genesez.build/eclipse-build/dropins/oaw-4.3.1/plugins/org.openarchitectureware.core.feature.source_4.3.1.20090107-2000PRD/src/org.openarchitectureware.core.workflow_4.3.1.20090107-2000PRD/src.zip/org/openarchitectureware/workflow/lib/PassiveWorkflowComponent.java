package org.openarchitectureware.workflow.lib;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class PassiveWorkflowComponent extends AbstractWorkflowComponent {

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#checkConfiguration(org.openarchitectureware.workflow.issues.Issues)
	 */
	public void checkConfiguration(Issues issues) {
		// do nothing intentionally
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#invoke(org.openarchitectureware.workflow.WorkflowContext,
	 *      org.openarchitectureware.workflow.monitor.ProgressMonitor,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	public void invoke(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
		// do nothing intentionally
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getComponentName()
	 */
	public String getComponentName() {
		return "";
	}
}
