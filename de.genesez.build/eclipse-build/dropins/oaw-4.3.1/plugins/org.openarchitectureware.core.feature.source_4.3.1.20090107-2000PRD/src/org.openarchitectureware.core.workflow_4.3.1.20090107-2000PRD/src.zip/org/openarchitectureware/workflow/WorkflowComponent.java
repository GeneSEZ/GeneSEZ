/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.workflow;

import org.openarchitectureware.workflow.ast.parser.Location;
import org.openarchitectureware.workflow.container.CompositeComponent;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

/**
 * WorkflowComponents are components that can be executed by the
 * openArchitectureWare Workflow Engine.
 * <p>
 * The Workflow Engine will call the
 * {@link #invoke(WorkflowContext, ProgressMonitor)} method at the appropriate
 * time to execute the component's service.
 * 
 * @author Sven Efftinge (http://www.efftinge.de)
 */
public interface WorkflowComponent {

	/**
	 * Invokes the workflow component.
	 * 
	 * @param ctx
	 *            the current workflow context
	 * @param monitor
	 *            implementors should provide some feedback about the progress
	 *            using this monitor
	 * @param issues
	 *            facility for reporting possible issues that occur during
	 *            invocation
	 */
	public void invoke(WorkflowContext ctx, ProgressMonitor monitor, Issues issues);

	/**
	 * Validates the configuration before invocation.
	 * 
	 * @param issues
	 *            facility for reporting configuration issues.
	 */
	public void checkConfiguration(Issues issues);

	/**
	 * Returns the containing component, if there is one.
	 * 
	 * @return the container
	 */
	public CompositeComponent getContainer();

	/**
	 * Sers the containing component.
	 * 
	 * @param container
	 *            the containing component
	 */
	public void setContainer(CompositeComponent container);

	/**
	 * Sets the location in the source file that invokes the current component.
	 * 
	 * @param location
	 *            the location
	 */
	public void setLocation(Location location);

	/**
	 * Returns the location in the source file that invokes the current
	 * component.
	 * 
	 * @return the location
	 */
	public Location getLocation();

	/**
	 * Returns the name of the component.
	 * 
	 * @return the component name
	 * @since 4.3.1
	 */
	public String getComponentName();

}
