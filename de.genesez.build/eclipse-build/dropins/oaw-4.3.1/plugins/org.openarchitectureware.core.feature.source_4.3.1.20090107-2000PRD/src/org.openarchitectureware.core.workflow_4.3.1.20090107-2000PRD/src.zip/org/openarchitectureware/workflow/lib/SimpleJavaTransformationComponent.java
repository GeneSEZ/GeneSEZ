/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.workflow.lib;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public abstract class SimpleJavaTransformationComponent extends AbstractWorkflowComponent {

	private String inputSlot;

	private String outputSlot;

	/**
	 * Sets the name of the input slot.
	 * 
	 * @param slotName
	 *            name of slot
	 */
	public void setInputSlot(final String slotName) {
		inputSlot = slotName;
	}

	/**
	 * Sets the name of the output slot.
	 * 
	 * @param slotName
	 *            name of slot
	 */
	public void setOutputSlot(final String slotName) {
		outputSlot = slotName;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#checkConfiguration(org.openarchitectureware.workflow.issues.Issues)
	 */
	public void checkConfiguration(final Issues issues) {
		if (inputSlot == null) {
			issues.addError(this, "inputSlot not specified");
		}
		if (outputSlot == null) {
			issues.addError(this, "outputSlot not specified");
		}
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#invoke(org.openarchitectureware.workflow.WorkflowContext,
	 *      org.openarchitectureware.workflow.monitor.ProgressMonitor,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	public void invoke(final WorkflowContext ctx, final ProgressMonitor monitor, final Issues issues) {
		final Object in = ctx.get(inputSlot);
		if (in == null) {
			issues.addError(this, "inputSlot empty!");
			return;
		}
		final Object out = ctx.get(outputSlot);
		if (out != null) {
			issues.addWarning(this, "outputSlot not empty");
		}
		final Object result = doTransformation(in, ctx, monitor, issues);
		ctx.set(outputSlot, result);
	}

	protected abstract Object doTransformation(Object inputModel, WorkflowContext ctx, ProgressMonitor monitor,
			Issues issues);

}
