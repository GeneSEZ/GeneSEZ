/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Bernd Kolb and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Bernd Kolb - Initial API and implementation
 *
 * </copyright>
 */

package org.openarchitectureware.workflow.issues.indexed;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MapSet<K,V> implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 2319752836393805017L;
	private final Map<K, Set<V>> map = new HashMap<K, Set<V>>();

    public void put(final K key, final V value) {
        getSet(key).add(value);
    }

    public Set<V> peek(final K key) {
        return map.get(key);
    }

    public Set<V> get(final K key) {
        return getSet(key);
    }

    public Iterator<V> iterator(final K key) {
        return getSet(key).iterator();
    }

    public List<Object> getKeys() {
        final List<Object> keys = new ArrayList<Object>();
        keys.addAll(map.keySet());
        return keys;
    }

    private Set<V> getSet(final K key) {
        Set<V> l = map.get(key);
        if (l == null) {
            l = new HashSet<V>();
            map.put(key, l);
        }
        return l;
    }

    public Iterator<V> iterator() {
        final Set<V> all = new HashSet<V>();
        for (final Iterator<Set<V>> iter = map.values().iterator(); iter.hasNext();) {
            final Set<V> l = iter.next();
            all.addAll(l);
        }
        return all.iterator();
    }

    public boolean containsKey(final Object key) {
        return map.containsKey(key);
    }

    public void remove(final Object key) {
        map.remove(key);
    }

}
