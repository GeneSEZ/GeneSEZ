package org.openarchitectureware.workflow.config;

import org.openarchitectureware.workflow.issues.Issues;

public class GlobalConfigurationHolder {

	private static ConfigurationModel configModel = null;

	/**
	 * Sets the configuration model. This method won't allow to overwrite the existing configuration.
	 * @param cm The configuration
	 * @param issues The Issues object to report errors to
	 */
	public static void setConfigurationModel( ConfigurationModel cm, Issues issues ) {
		setConfigurationModel(cm, issues, false);
	}

	/**
	 * Sets the configuration model
	 * @param cm The configuration
	 * @param issues The Issues object to report errors to
	 * @param overwrite Allow replacement of the configuration model when it was already set
	 */
	public static void setConfigurationModel( ConfigurationModel cm, Issues issues, boolean overwrite ) {
		if ( configModel != null ) {
			if ( !configModel.equals(cm) && !overwrite) {
				issues.addError("configuration model already set!");
			}
		} else {
			configModel = cm;
		}
	}
	
	public static ConfigurationModel getConfiguration() {
		return configModel;
	}

	
}
