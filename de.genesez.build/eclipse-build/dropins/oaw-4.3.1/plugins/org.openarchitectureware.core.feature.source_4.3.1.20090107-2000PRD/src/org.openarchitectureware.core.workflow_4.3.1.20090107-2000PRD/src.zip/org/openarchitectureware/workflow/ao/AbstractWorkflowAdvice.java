/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.workflow.ao;

import java.util.List;

import org.openarchitectureware.workflow.WorkflowComponent;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public abstract class AbstractWorkflowAdvice extends AbstractWorkflowComponent {

	private String target;

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#invoke(org.openarchitectureware.workflow.WorkflowContext,
	 *      org.openarchitectureware.workflow.monitor.ProgressMonitor,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	public final void invoke(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#checkConfiguration(org.openarchitectureware.workflow.issues.Issues)
	 */
	public void checkConfiguration(Issues issues) {
	}

	/**
	 * Sets the target of the advice.
	 * 
	 * @param adviceTarget
	 *            the advice target
	 */
	public void setAdviceTarget(String adviceTarget) {
		this.target = adviceTarget;
	}

	/**
	 * Returns the advice target.
	 * 
	 * @return the advice target
	 */
	public String getAdviceTarget() {
		return target;
	}

	/**
	 * Weaves the advices into the specified <code>component</code>.
	 * 
	 * @param component
	 *            the component
	 * @param issues
	 *            facility for reporting possible issues during weaving.
	 */
	public abstract void weave(WorkflowComponent component, Issues issues);

	protected String buildList(List<String> list) {
		StringBuilder b = new StringBuilder();
		boolean firstTime = true;
		for (String s : list) {
			if (!firstTime) {
				b.append(", ");
			}
			b.append(s);
			firstTime = false;
		}
		return b.toString();
	}

}
