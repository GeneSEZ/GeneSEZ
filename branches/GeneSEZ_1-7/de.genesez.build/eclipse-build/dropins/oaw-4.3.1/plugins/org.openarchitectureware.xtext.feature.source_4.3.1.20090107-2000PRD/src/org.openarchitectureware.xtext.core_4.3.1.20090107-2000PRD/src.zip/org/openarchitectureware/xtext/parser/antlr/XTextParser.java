// $ANTLR 3.0 /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g 2008-02-12 11:20:14

package org.openarchitectureware.xtext.parser.antlr; 

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.antlr.runtime.BitSet;
import org.antlr.runtime.CommonToken;
import org.antlr.runtime.MismatchedSetException;
import org.antlr.runtime.NoViableAltException;
import org.antlr.runtime.Parser;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.Token;
import org.antlr.runtime.TokenStream;
import org.eclipse.emf.ecore.EObject;
import org.openarchitectureware.xtext.MetaModelRegistration;
import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.parser.impl.AntlrUtil;
import org.openarchitectureware.xtext.parser.impl.EcoreModelFactory;
import org.openarchitectureware.xtext.parser.model.ParseTreeManager;
import org.openarchitectureware.xtext.parser.parsetree.Node;
public class XTextParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "ID", "STRING", "XTEXT_INT", "XTEXT_ML_COMMENT", "XTEXT_SL_COMMENT", "XTEXT_WS", "'grammar_name'", "'grammar_nsURI'", "'preventMMGeneration'", "'commentsDisabled'", "'importGrammar'", "'importMetamodel'", "'as'", "';'", "'Native'", "':'", "'['", "']'", "'::'", "'String'", "'Enum'", "'|'", "'='", "'('", "')'", "'URI'", "'?='", "'+='", "'?'", "'*'", "'+'"
    };
    public static final int XTEXT_WS=9;
    public static final int XTEXT_INT=6;
    public static final int XTEXT_SL_COMMENT=8;
    public static final int XTEXT_ML_COMMENT=7;
    public static final int ID=4;
    public static final int EOF=-1;
    public static final int STRING=5;

        public XTextParser(TokenStream input) {
            super(input);
            ruleMemo = new HashMap[24+1];
         }
        

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "/Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g"; }



       	private Token getLastToken() {
    		return input.LT(-1);
    	}
    	private Token getNextToken() {
    		return input.LT(1);
    	}
    	
    	private int line() {
    		Token t = getNextToken();
    		if (t==null)
    			return 1;
    		return t.getLine();
    	}
    	
    	private int start() {
    		Token t = getNextToken();
    		if (t==null)
    			return 0;
    		if (t instanceof CommonToken) {
    			return ((CommonToken)t).getStartIndex();
    		}
    		return t.getTokenIndex();
    	}
    	
    	private int end() {
    		Token t = getLastToken();
    		if (t==null)
    			return 1;
    		if (t instanceof CommonToken) {
    			return ((CommonToken)t).getStopIndex()+1;
    		}
    		return t.getTokenIndex();
    	}
    	
    	protected Object convert(Object arg) {
    		if (arg instanceof org.antlr.runtime.Token) {
    			Token t = (Token) arg;
    			String s = t.getText();
    			if (t.getType() == XTextLexer.ID && s.startsWith("^")) {
    				return s.substring(1);
    			} else if (t.getType()==XTextLexer.STRING) {
    				return s.substring(1,s.length()-1);
    			}
    			return s;
    		}
    		return arg;
    	}
    	
    	
    	private EcoreModelFactory f= new EcoreModelFactory(MetaModelRegistration.getEPackage());
        private ParseTreeManager ptm = new ParseTreeManager();
    	
    	public ParseTreeManager getResult() {
    		return ptm;
    	}
    	
    	private List<ErrorMsg> errors = new ArrayList<ErrorMsg>();
    	public List<ErrorMsg> getErrors() {
    		return errors;
    	}
    	
    	@Override
        public void reportError(RecognitionException e) {
    		String msg = super.getErrorMessage(e,tokenNames);
    		errors.add(AntlrUtil.create(msg,e,tokenNames));
        	ptm.addError(msg, e);
        	ptm.ruleFinished(null, end());
        }



    // $ANTLR start parse
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:128:1: parse returns [Node r] : result= xtextFile EOF ;
    public Node parse() throws RecognitionException {
        Node r = null;

        EObject result = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:129:3: (result= xtextFile EOF )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:129:3: result= xtextFile EOF
            {
            pushFollow(FOLLOW_xtextFile_in_parse54);
            result=xtextFile();
            _fsp--;
            if (failed) return r;
            match(input,EOF,FOLLOW_EOF_in_parse56); if (failed) return r;
            if ( backtracking==0 ) {
              ptm.ruleFinished(result,end());r = ptm.getCurrent();
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end parse


    // $ANTLR start xtextFile
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:132:1: xtextFile returns [EObject result] : ( ( ( 'grammar_name' name= ID )? ( 'grammar_nsURI' nsuri= STRING )? ) | (preventMMGeneration= 'preventMMGeneration' ) ) (commentsflag= 'commentsDisabled' )? (i= importGrammar )* (iMM= importMetamodel )* (r= rule )* ;
    public EObject xtextFile() throws RecognitionException {
        EObject result = null;

        Token name=null;
        Token nsuri=null;
        Token preventMMGeneration=null;
        Token commentsflag=null;
        EObject i = null;

        EObject iMM = null;

        EObject r = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:133:5: ( ( ( ( 'grammar_name' name= ID )? ( 'grammar_nsURI' nsuri= STRING )? ) | (preventMMGeneration= 'preventMMGeneration' ) ) (commentsflag= 'commentsDisabled' )? (i= importGrammar )* (iMM= importMetamodel )* (r= rule )* )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:133:5: ( ( ( 'grammar_name' name= ID )? ( 'grammar_nsURI' nsuri= STRING )? ) | (preventMMGeneration= 'preventMMGeneration' ) ) (commentsflag= 'commentsDisabled' )? (i= importGrammar )* (iMM= importMetamodel )* (r= rule )*
            {
            if ( backtracking==0 ) {
               result = f.create("XtextFile"); 
                     ptm.setModelElement(result);
                   
            }
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:136:5: ( ( ( 'grammar_name' name= ID )? ( 'grammar_nsURI' nsuri= STRING )? ) | (preventMMGeneration= 'preventMMGeneration' ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==EOF||LA3_0==ID||(LA3_0>=10 && LA3_0<=11)||(LA3_0>=13 && LA3_0<=15)||LA3_0==18||(LA3_0>=23 && LA3_0<=24)) ) {
                alt3=1;
            }
            else if ( (LA3_0==12) ) {
                alt3=2;
            }
            else {
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("136:5: ( ( ( 'grammar_name' name= ID )? ( 'grammar_nsURI' nsuri= STRING )? ) | (preventMMGeneration= 'preventMMGeneration' ) )", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:136:6: ( ( 'grammar_name' name= ID )? ( 'grammar_nsURI' nsuri= STRING )? )
                    {
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:136:6: ( ( 'grammar_name' name= ID )? ( 'grammar_nsURI' nsuri= STRING )? )
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:136:7: ( 'grammar_name' name= ID )? ( 'grammar_nsURI' nsuri= STRING )?
                    {
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:136:7: ( 'grammar_name' name= ID )?
                    int alt1=2;
                    int LA1_0 = input.LA(1);

                    if ( (LA1_0==10) ) {
                        alt1=1;
                    }
                    switch (alt1) {
                        case 1 :
                            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:136:8: 'grammar_name' name= ID
                            {
                            if ( backtracking==0 ) {
                              ptm.invokeRule(null,line(),start());
                            }
                            match(input,10,FOLLOW_10_in_xtextFile89); if (failed) return result;
                            if ( backtracking==0 ) {
                              ptm.ruleFinished(getLastToken(),end());
                            }
                            name=(Token)input.LT(1);
                            match(input,ID,FOLLOW_ID_in_xtextFile94); if (failed) return result;
                            if ( backtracking==0 ) {
                              f.set(result, "name", convert(name));
                            }
                            if ( backtracking==0 ) {
                              ptm.ruleFinished(getLastToken(),end());
                            }

                            }
                            break;

                    }

                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:137:6: ( 'grammar_nsURI' nsuri= STRING )?
                    int alt2=2;
                    int LA2_0 = input.LA(1);

                    if ( (LA2_0==11) ) {
                        alt2=1;
                    }
                    switch (alt2) {
                        case 1 :
                            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:137:7: 'grammar_nsURI' nsuri= STRING
                            {
                            if ( backtracking==0 ) {
                              ptm.invokeRule(null,line(),start());
                            }
                            match(input,11,FOLLOW_11_in_xtextFile108); if (failed) return result;
                            if ( backtracking==0 ) {
                              ptm.ruleFinished(getLastToken(),end());
                            }
                            if ( backtracking==0 ) {
                              ptm.invokeRule(null,line(),start());
                            }
                            nsuri=(Token)input.LT(1);
                            match(input,STRING,FOLLOW_STRING_in_xtextFile114); if (failed) return result;
                            if ( backtracking==0 ) {
                              f.set(result, "nsURI", convert(nsuri));
                            }
                            if ( backtracking==0 ) {
                              ptm.ruleFinished(getLastToken(),end());
                            }

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:138:6: (preventMMGeneration= 'preventMMGeneration' )
                    {
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:138:6: (preventMMGeneration= 'preventMMGeneration' )
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:138:7: preventMMGeneration= 'preventMMGeneration'
                    {
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    preventMMGeneration=(Token)input.LT(1);
                    match(input,12,FOLLOW_12_in_xtextFile133); if (failed) return result;
                    if ( backtracking==0 ) {
                      f.set(result, "preventMMGeneration", true);
                    }
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }

                    }


                    }
                    break;

            }

            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:140:5: (commentsflag= 'commentsDisabled' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==13) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:140:6: commentsflag= 'commentsDisabled'
                    {
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    commentsflag=(Token)input.LT(1);
                    match(input,13,FOLLOW_13_in_xtextFile153); if (failed) return result;
                    if ( backtracking==0 ) {
                      f.set(result, "commentsDisabledFlag", true);
                    }
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }

                    }
                    break;

            }

            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:141:5: (i= importGrammar )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==14) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:141:6: i= importGrammar
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(null,line(),start());
            	    }
            	    pushFollow(FOLLOW_importGrammar_in_xtextFile168);
            	    i=importGrammar();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      f.add(result,"imports",convert(i));
            	    }
            	    if ( backtracking==0 ) {
            	      ptm.ruleFinished(i,end());
            	    }

            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:142:5: (iMM= importMetamodel )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0==15) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:142:6: iMM= importMetamodel
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(null,line(),start());
            	    }
            	    pushFollow(FOLLOW_importMetamodel_in_xtextFile183);
            	    iMM=importMetamodel();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      f.add(result,"mmImports",convert(iMM));
            	    }
            	    if ( backtracking==0 ) {
            	      ptm.ruleFinished(iMM,end());
            	    }

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:143:5: (r= rule )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==ID||LA7_0==18||(LA7_0>=23 && LA7_0<=24)) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:143:6: r= rule
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(null,line(),start());
            	    }
            	    pushFollow(FOLLOW_rule_in_xtextFile202);
            	    r=rule();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      f.add(result,"rules",convert(r));
            	    }
            	    if ( backtracking==0 ) {
            	      ptm.ruleFinished(r,end());
            	    }

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end xtextFile


    // $ANTLR start importGrammar
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:146:1: importGrammar returns [EObject result] : 'importGrammar' location= STRING ;
    public EObject importGrammar() throws RecognitionException {
        EObject result = null;

        Token location=null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:147:5: ( 'importGrammar' location= STRING )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:147:5: 'importGrammar' location= STRING
            {
            if ( backtracking==0 ) {
              result = f.create("Import"); 
                     ptm.setModelElement(result);
                  
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,14,FOLLOW_14_in_importGrammar236); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            location=(Token)input.LT(1);
            match(input,STRING,FOLLOW_STRING_in_importGrammar248); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"location",convert(location));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end importGrammar


    // $ANTLR start importMetamodel
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:155:1: importMetamodel returns [EObject result] : 'importMetamodel' location= STRING ( 'as' alias= ID )? ';' ;
    public EObject importMetamodel() throws RecognitionException {
        EObject result = null;

        Token location=null;
        Token alias=null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:156:5: ( 'importMetamodel' location= STRING ( 'as' alias= ID )? ';' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:156:5: 'importMetamodel' location= STRING ( 'as' alias= ID )? ';'
            {
            if ( backtracking==0 ) {
              result = f.create("MetamodelImport"); 
                     ptm.setModelElement(result);
                  
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,15,FOLLOW_15_in_importMetamodel281); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            location=(Token)input.LT(1);
            match(input,STRING,FOLLOW_STRING_in_importMetamodel293); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"location",convert(location));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:161:3: ( 'as' alias= ID )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==16) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:161:4: 'as' alias= ID
                    {
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    match(input,16,FOLLOW_16_in_importMetamodel302); if (failed) return result;
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    alias=(Token)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_importMetamodel314); if (failed) return result;
                    if ( backtracking==0 ) {
                      f.set(result,"alias",convert(alias));
                    }
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }

                    }
                    break;

            }

            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,17,FOLLOW_17_in_importMetamodel327); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end importMetamodel


    // $ANTLR start rule
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:166:1: rule returns [EObject result] : (a= typeRule | b= stringRule | x= lexerRule | c= enumRule );
    public EObject rule() throws RecognitionException {
        EObject result = null;

        EObject a = null;

        EObject b = null;

        EObject x = null;

        EObject c = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:167:6: (a= typeRule | b= stringRule | x= lexerRule | c= enumRule )
            int alt9=4;
            switch ( input.LA(1) ) {
            case ID:
                {
                alt9=1;
                }
                break;
            case 23:
                {
                alt9=2;
                }
                break;
            case 18:
                {
                alt9=3;
                }
                break;
            case 24:
                {
                alt9=4;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("166:1: rule returns [EObject result] : (a= typeRule | b= stringRule | x= lexerRule | c= enumRule );", 9, 0, input);

                throw nvae;
            }

            switch (alt9) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:167:6: a= typeRule
                    {
                    pushFollow(FOLLOW_typeRule_in_rule349);
                    a=typeRule();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      result =a;
                    }

                    }
                    break;
                case 2 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:168:7: b= stringRule
                    {
                    pushFollow(FOLLOW_stringRule_in_rule361);
                    b=stringRule();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      result =b;
                    }

                    }
                    break;
                case 3 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:169:7: x= lexerRule
                    {
                    pushFollow(FOLLOW_lexerRule_in_rule373);
                    x=lexerRule();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      result =x;
                    }

                    }
                    break;
                case 4 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:170:7: c= enumRule
                    {
                    pushFollow(FOLLOW_enumRule_in_rule385);
                    c=enumRule();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      result =c;
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end rule


    // $ANTLR start lexerRule
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:173:1: lexerRule returns [EObject result] : 'Native' name= ID ':' impl= STRING ';' ;
    public EObject lexerRule() throws RecognitionException {
        EObject result = null;

        Token name=null;
        Token impl=null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:174:4: ( 'Native' name= ID ':' impl= STRING ';' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:174:4: 'Native' name= ID ':' impl= STRING ';'
            {
            if ( backtracking==0 ) {
              result = f.create("NativeLexerRule"); 
                     ptm.setModelElement(result);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,18,FOLLOW_18_in_lexerRule410); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            name=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_lexerRule419); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"name",convert(name));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,19,FOLLOW_19_in_lexerRule427); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            impl=(Token)input.LT(1);
            match(input,STRING,FOLLOW_STRING_in_lexerRule436); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"impl",convert(impl));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,17,FOLLOW_17_in_lexerRule445); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end lexerRule


    // $ANTLR start typeRule
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:184:1: typeRule returns [EObject result] : name= ID ( '[' type= typeNameRule ']' )? ':' content= alternatives ';' ;
    public EObject typeRule() throws RecognitionException {
        EObject result = null;

        Token name=null;
        EObject type = null;

        EObject content = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:185:5: (name= ID ( '[' type= typeNameRule ']' )? ':' content= alternatives ';' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:185:5: name= ID ( '[' type= typeNameRule ']' )? ':' content= alternatives ';'
            {
            if ( backtracking==0 ) {
              result = f.create("TypeRule"); 
                     ptm.setModelElement(result);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            name=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_typeRule477); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"name",convert(name));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:189:5: ( '[' type= typeNameRule ']' )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==20) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:189:6: '[' type= typeNameRule ']'
                    {
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    match(input,20,FOLLOW_20_in_typeRule488); if (failed) return result;
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    pushFollow(FOLLOW_typeNameRule_in_typeRule500);
                    type=typeNameRule();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      f.set(result,"type",convert(type));
                    }
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    match(input,21,FOLLOW_21_in_typeRule511); if (failed) return result;
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }

                    }
                    break;

            }

            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,19,FOLLOW_19_in_typeRule522); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            pushFollow(FOLLOW_alternatives_in_typeRule533);
            content=alternatives();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"content",convert(content));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(content,end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,17,FOLLOW_17_in_typeRule545); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end typeRule


    // $ANTLR start typeNameRule
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:198:1: typeNameRule returns [EObject result] : (alias= ID '::' )? name= ID ;
    public EObject typeNameRule() throws RecognitionException {
        EObject result = null;

        Token alias=null;
        Token name=null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:199:5: ( (alias= ID '::' )? name= ID )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:199:5: (alias= ID '::' )? name= ID
            {
            if ( backtracking==0 ) {
              result = f.create("TypeName"); 
                     ptm.setModelElement(result);
                   
            }
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:202:5: (alias= ID '::' )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==ID) ) {
                int LA11_1 = input.LA(2);

                if ( (LA11_1==22) ) {
                    alt11=1;
                }
            }
            switch (alt11) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:202:6: alias= ID '::'
                    {
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    alias=(Token)input.LT(1);
                    match(input,ID,FOLLOW_ID_in_typeNameRule576); if (failed) return result;
                    if ( backtracking==0 ) {
                      f.set(result,"alias",convert(alias));
                    }
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    match(input,22,FOLLOW_22_in_typeNameRule587); if (failed) return result;
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }

                    }
                    break;

            }

            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            name=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_typeNameRule600); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"name",convert(name));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end typeNameRule


    // $ANTLR start stringRule
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:208:1: stringRule returns [EObject result] : 'String' name= ID ':' content= alternatives ';' ;
    public EObject stringRule() throws RecognitionException {
        EObject result = null;

        Token name=null;
        EObject content = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:209:5: ( 'String' name= ID ':' content= alternatives ';' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:209:5: 'String' name= ID ':' content= alternatives ';'
            {
            if ( backtracking==0 ) {
              result = f.create("StringRule"); 
                     ptm.setModelElement(result);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,23,FOLLOW_23_in_stringRule629); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            name=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_stringRule640); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"name",convert(name));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,19,FOLLOW_19_in_stringRule651); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            pushFollow(FOLLOW_alternatives_in_stringRule662);
            content=alternatives();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"content",convert(content));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(content,end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,17,FOLLOW_17_in_stringRule672); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end stringRule


    // $ANTLR start enumRule
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:219:1: enumRule returns [EObject result] : 'Enum' name= ID ( '[' type= typeNameRule ']' )? ':' lit= enumLiteral ( '|' lit1= enumLiteral )* ';' ;
    public EObject enumRule() throws RecognitionException {
        EObject result = null;

        Token name=null;
        EObject type = null;

        EObject lit = null;

        EObject lit1 = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:220:5: ( 'Enum' name= ID ( '[' type= typeNameRule ']' )? ':' lit= enumLiteral ( '|' lit1= enumLiteral )* ';' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:220:5: 'Enum' name= ID ( '[' type= typeNameRule ']' )? ':' lit= enumLiteral ( '|' lit1= enumLiteral )* ';'
            {
            if ( backtracking==0 ) {
               result = f.create("EnumRule"); 
                     ptm.setModelElement(result);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,24,FOLLOW_24_in_enumRule699); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            name=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_enumRule710); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"name",convert(name));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:225:5: ( '[' type= typeNameRule ']' )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==20) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:225:6: '[' type= typeNameRule ']'
                    {
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    match(input,20,FOLLOW_20_in_enumRule722); if (failed) return result;
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    pushFollow(FOLLOW_typeNameRule_in_enumRule734);
                    type=typeNameRule();
                    _fsp--;
                    if (failed) return result;
                    if ( backtracking==0 ) {
                      f.set(result,"type",convert(type));
                    }
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    match(input,21,FOLLOW_21_in_enumRule745); if (failed) return result;
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }

                    }
                    break;

            }

            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,19,FOLLOW_19_in_enumRule756); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            pushFollow(FOLLOW_enumLiteral_in_enumRule767);
            lit=enumLiteral();
            _fsp--;
            if (failed) return result;
            if ( backtracking==0 ) {
              f.add(result,"literals",convert(lit));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(lit,end());
            }
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:230:5: ( '|' lit1= enumLiteral )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==25) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:230:6: '|' lit1= enumLiteral
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(null,line(),start());
            	    }
            	    match(input,25,FOLLOW_25_in_enumRule778); if (failed) return result;
            	    if ( backtracking==0 ) {
            	      ptm.ruleFinished(getLastToken(),end());
            	    }
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(null,line(),start());
            	    }
            	    pushFollow(FOLLOW_enumLiteral_in_enumRule790);
            	    lit1=enumLiteral();
            	    _fsp--;
            	    if (failed) return result;
            	    if ( backtracking==0 ) {
            	      f.add(result,"literals",convert(lit1));
            	    }
            	    if ( backtracking==0 ) {
            	      ptm.ruleFinished(lit1,end());
            	    }

            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,17,FOLLOW_17_in_enumRule802); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end enumRule


    // $ANTLR start enumLiteral
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:235:1: enumLiteral returns [EObject result] : name= ID '=' kw= STRING ;
    public EObject enumLiteral() throws RecognitionException {
        EObject result = null;

        Token name=null;
        Token kw=null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:236:5: (name= ID '=' kw= STRING )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:236:5: name= ID '=' kw= STRING
            {
            if ( backtracking==0 ) {
               result = f.create("EnumLiteral"); 
                     ptm.setModelElement(result);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            name=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_enumLiteral830); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"name",convert(name));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,26,FOLLOW_26_in_enumLiteral840); if (failed) return result;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            kw=(Token)input.LT(1);
            match(input,STRING,FOLLOW_STRING_in_enumLiteral851); if (failed) return result;
            if ( backtracking==0 ) {
              f.set(result,"keyword",convert(kw));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end enumLiteral


    // $ANTLR start alternatives
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:244:1: alternatives returns [EObject r] : s2= group ( '|' s2= group )* ;
    public EObject alternatives() throws RecognitionException {
        EObject r = null;

        EObject s2 = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:245:4: (s2= group ( '|' s2= group )* )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:245:4: s2= group ( '|' s2= group )*
            {
            if ( backtracking==0 ) {
              r = f.create("Alternatives"); 
                     ptm.setModelElement(r);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            pushFollow(FOLLOW_group_in_alternatives879);
            s2=group();
            _fsp--;
            if (failed) return r;
            if ( backtracking==0 ) {
              f.add(r,"alternatives",convert(s2));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(s2,end());
            }
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:249:5: ( '|' s2= group )*
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( (LA14_0==25) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:249:6: '|' s2= group
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(null,line(),start());
            	    }
            	    match(input,25,FOLLOW_25_in_alternatives890); if (failed) return r;
            	    if ( backtracking==0 ) {
            	      ptm.ruleFinished(getLastToken(),end());
            	    }
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(null,line(),start());
            	    }
            	    pushFollow(FOLLOW_group_in_alternatives902);
            	    s2=group();
            	    _fsp--;
            	    if (failed) return r;
            	    if ( backtracking==0 ) {
            	      f.add(r,"alternatives",convert(s2));
            	    }
            	    if ( backtracking==0 ) {
            	      ptm.ruleFinished(s2,end());
            	    }

            	    }
            	    break;

            	default :
            	    break loop14;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end alternatives


    // $ANTLR start group
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:253:1: group returns [EObject r] : x2= terminal (x2= terminal )* ;
    public EObject group() throws RecognitionException {
        EObject r = null;

        EObject x2 = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:254:4: (x2= terminal (x2= terminal )* )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:254:4: x2= terminal (x2= terminal )*
            {
            if ( backtracking==0 ) {
              r = f.create("Group"); 
                  ptm.setModelElement(r);
                 
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            pushFollow(FOLLOW_terminal_in_group934);
            x2=terminal();
            _fsp--;
            if (failed) return r;
            if ( backtracking==0 ) {
              f.add(r,"children",convert(x2));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(x2,end());
            }
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:258:7: (x2= terminal )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( ((LA15_0>=ID && LA15_0<=STRING)||LA15_0==20||LA15_0==27||LA15_0==29) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:258:8: x2= terminal
            	    {
            	    if ( backtracking==0 ) {
            	      ptm.invokeRule(null,line(),start());
            	    }
            	    pushFollow(FOLLOW_terminal_in_group950);
            	    x2=terminal();
            	    _fsp--;
            	    if (failed) return r;
            	    if ( backtracking==0 ) {
            	      f.add(r,"children",convert(x2));
            	    }
            	    if ( backtracking==0 ) {
            	      ptm.ruleFinished(x2,end());
            	    }

            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end group


    // $ANTLR start terminal
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:261:1: terminal returns [EObject r] : ( ( ID ( '=' | '?=' | '+=' ) )=>x1= assignment | x2= abstractToken );
    public EObject terminal() throws RecognitionException {
        EObject r = null;

        EObject x1 = null;

        EObject x2 = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:262:8: ( ( ID ( '=' | '?=' | '+=' ) )=>x1= assignment | x2= abstractToken )
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==ID) ) {
                int LA16_1 = input.LA(2);

                if ( (LA16_1==26) && (synpred1())) {
                    alt16=1;
                }
                else if ( (LA16_1==30) && (synpred1())) {
                    alt16=1;
                }
                else if ( (LA16_1==31) && (synpred1())) {
                    alt16=1;
                }
                else if ( ((LA16_1>=ID && LA16_1<=STRING)||LA16_1==17||LA16_1==20||LA16_1==25||(LA16_1>=27 && LA16_1<=29)||(LA16_1>=32 && LA16_1<=34)) ) {
                    alt16=2;
                }
                else {
                    if (backtracking>0) {failed=true; return r;}
                    NoViableAltException nvae =
                        new NoViableAltException("261:1: terminal returns [EObject r] : ( ( ID ( '=' | '?=' | '+=' ) )=>x1= assignment | x2= abstractToken );", 16, 1, input);

                    throw nvae;
                }
            }
            else if ( (LA16_0==STRING||LA16_0==20||LA16_0==27||LA16_0==29) ) {
                alt16=2;
            }
            else {
                if (backtracking>0) {failed=true; return r;}
                NoViableAltException nvae =
                    new NoViableAltException("261:1: terminal returns [EObject r] : ( ( ID ( '=' | '?=' | '+=' ) )=>x1= assignment | x2= abstractToken );", 16, 0, input);

                throw nvae;
            }
            switch (alt16) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:262:8: ( ID ( '=' | '?=' | '+=' ) )=>x1= assignment
                    {
                    pushFollow(FOLLOW_assignment_in_terminal991);
                    x1=assignment();
                    _fsp--;
                    if (failed) return r;
                    if ( backtracking==0 ) {
                      r =x1;
                    }

                    }
                    break;
                case 2 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:263:2: x2= abstractToken
                    {
                    pushFollow(FOLLOW_abstractToken_in_terminal1001);
                    x2=abstractToken();
                    _fsp--;
                    if (failed) return r;
                    if ( backtracking==0 ) {
                      r =x2;
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end terminal


    // $ANTLR start assignment
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:265:1: assignment returns [EObject r] : feature= ID op= assignOperator tok= abstractToken ;
    public EObject assignment() throws RecognitionException {
        EObject r = null;

        Token feature=null;
        Object op = null;

        EObject tok = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:266:4: (feature= ID op= assignOperator tok= abstractToken )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:266:4: feature= ID op= assignOperator tok= abstractToken
            {
            if ( backtracking==0 ) {
              r = f.create("Assignment"); 
                     ptm.setModelElement(r);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            feature=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_assignment1026); if (failed) return r;
            if ( backtracking==0 ) {
              f.set(r,"feature",convert(feature));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            pushFollow(FOLLOW_assignOperator_in_assignment1038);
            op=assignOperator();
            _fsp--;
            if (failed) return r;
            if ( backtracking==0 ) {
              f.set(r,"operator",convert(op));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(op,end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            pushFollow(FOLLOW_abstractToken_in_assignment1050);
            tok=abstractToken();
            _fsp--;
            if (failed) return r;
            if ( backtracking==0 ) {
              f.set(r,"token",convert(tok));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(tok,end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end assignment


    // $ANTLR start abstractToken
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:274:1: abstractToken returns [EObject r] : (x1= keyword | x2= ruleName | x3= reference | x4= fileReference | x5= paranthesizedElement ) (ct= cardinalityType )? ;
    public EObject abstractToken() throws RecognitionException {
        EObject r = null;

        EObject x1 = null;

        EObject x2 = null;

        EObject x3 = null;

        EObject x4 = null;

        EObject x5 = null;

        Object ct = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:275:4: ( (x1= keyword | x2= ruleName | x3= reference | x4= fileReference | x5= paranthesizedElement ) (ct= cardinalityType )? )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:275:4: (x1= keyword | x2= ruleName | x3= reference | x4= fileReference | x5= paranthesizedElement ) (ct= cardinalityType )?
            {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:275:4: (x1= keyword | x2= ruleName | x3= reference | x4= fileReference | x5= paranthesizedElement )
            int alt17=5;
            switch ( input.LA(1) ) {
            case STRING:
                {
                alt17=1;
                }
                break;
            case ID:
                {
                alt17=2;
                }
                break;
            case 20:
                {
                alt17=3;
                }
                break;
            case 29:
                {
                alt17=4;
                }
                break;
            case 27:
                {
                alt17=5;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return r;}
                NoViableAltException nvae =
                    new NoViableAltException("275:4: (x1= keyword | x2= ruleName | x3= reference | x4= fileReference | x5= paranthesizedElement )", 17, 0, input);

                throw nvae;
            }

            switch (alt17) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:275:5: x1= keyword
                    {
                    pushFollow(FOLLOW_keyword_in_abstractToken1073);
                    x1=keyword();
                    _fsp--;
                    if (failed) return r;
                    if ( backtracking==0 ) {
                      r =x1;
                    }

                    }
                    break;
                case 2 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:276:4: x2= ruleName
                    {
                    pushFollow(FOLLOW_ruleName_in_abstractToken1083);
                    x2=ruleName();
                    _fsp--;
                    if (failed) return r;
                    if ( backtracking==0 ) {
                      r =x2;
                    }

                    }
                    break;
                case 3 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:277:4: x3= reference
                    {
                    pushFollow(FOLLOW_reference_in_abstractToken1093);
                    x3=reference();
                    _fsp--;
                    if (failed) return r;
                    if ( backtracking==0 ) {
                      r =x3;
                    }

                    }
                    break;
                case 4 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:278:4: x4= fileReference
                    {
                    pushFollow(FOLLOW_fileReference_in_abstractToken1103);
                    x4=fileReference();
                    _fsp--;
                    if (failed) return r;
                    if ( backtracking==0 ) {
                      r =x4;
                    }

                    }
                    break;
                case 5 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:279:4: x5= paranthesizedElement
                    {
                    pushFollow(FOLLOW_paranthesizedElement_in_abstractToken1114);
                    x5=paranthesizedElement();
                    _fsp--;
                    if (failed) return r;
                    if ( backtracking==0 ) {
                      r =x5;
                    }

                    }
                    break;

            }

            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:280:4: (ct= cardinalityType )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( ((LA18_0>=32 && LA18_0<=34)) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:280:5: ct= cardinalityType
                    {
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    pushFollow(FOLLOW_cardinalityType_in_abstractToken1126);
                    ct=cardinalityType();
                    _fsp--;
                    if (failed) return r;
                    if ( backtracking==0 ) {
                      f.set(r,"cardinality",convert(ct));
                    }
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(ct,end());
                    }

                    }
                    break;

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end abstractToken


    // $ANTLR start paranthesizedElement
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:283:1: paranthesizedElement returns [EObject r] : '(' x2= alternatives ')' ;
    public EObject paranthesizedElement() throws RecognitionException {
        EObject r = null;

        EObject x2 = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:284:4: ( '(' x2= alternatives ')' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:284:4: '(' x2= alternatives ')'
            {
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,27,FOLLOW_27_in_paranthesizedElement1148); if (failed) return r;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            pushFollow(FOLLOW_alternatives_in_paranthesizedElement1158);
            x2=alternatives();
            _fsp--;
            if (failed) return r;
            if ( backtracking==0 ) {
              r =x2;ptm.ruleFinished(x2,end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,28,FOLLOW_28_in_paranthesizedElement1166); if (failed) return r;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end paranthesizedElement


    // $ANTLR start fileReference
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:289:1: fileReference returns [EObject r] : 'URI' ;
    public EObject fileReference() throws RecognitionException {
        EObject r = null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:290:6: ( 'URI' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:290:6: 'URI'
            {
            if ( backtracking==0 ) {
              r =f.create("FileRef");
                     ptm.setModelElement(r);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,29,FOLLOW_29_in_fileReference1194); if (failed) return r;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end fileReference


    // $ANTLR start keyword
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:296:1: keyword returns [EObject r] : s= STRING ;
    public EObject keyword() throws RecognitionException {
        EObject r = null;

        Token s=null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:297:4: (s= STRING )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:297:4: s= STRING
            {
            if ( backtracking==0 ) {
              r =f.create("Keyword");
                     ptm.setModelElement(r);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            s=(Token)input.LT(1);
            match(input,STRING,FOLLOW_STRING_in_keyword1221); if (failed) return r;
            if ( backtracking==0 ) {
               f.set(r,"value",convert(s));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end keyword


    // $ANTLR start ruleName
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:303:1: ruleName returns [EObject r] : id= ID ;
    public EObject ruleName() throws RecognitionException {
        EObject r = null;

        Token id=null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:304:4: (id= ID )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:304:4: id= ID
            {
            if ( backtracking==0 ) {
              r =f.create("RuleName"); 
                     ptm.setModelElement(r);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            id=(Token)input.LT(1);
            match(input,ID,FOLLOW_ID_in_ruleName1248); if (failed) return r;
            if ( backtracking==0 ) {
              f.set(r,"name",convert(id));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end ruleName


    // $ANTLR start reference
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:309:1: reference returns [EObject r] : '[' type= typeNameRule ( '|' temp_ruleName= ruleName )? ']' ;
    public EObject reference() throws RecognitionException {
        EObject r = null;

        EObject type = null;

        EObject temp_ruleName = null;


        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:310:4: ( '[' type= typeNameRule ( '|' temp_ruleName= ruleName )? ']' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:310:4: '[' type= typeNameRule ( '|' temp_ruleName= ruleName )? ']'
            {
            if ( backtracking==0 ) {
              r =f.create("CrossReference"); 
                     ptm.setModelElement(r);
                   
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,20,FOLLOW_20_in_reference1272); if (failed) return r;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            pushFollow(FOLLOW_typeNameRule_in_reference1283);
            type=typeNameRule();
            _fsp--;
            if (failed) return r;
            if ( backtracking==0 ) {
              f.set(r,"type",convert(type));
            }
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:315:4: ( '|' temp_ruleName= ruleName )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==25) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:316:4: '|' temp_ruleName= ruleName
                    {
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    match(input,25,FOLLOW_25_in_reference1297); if (failed) return r;
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }
                    if ( backtracking==0 ) {
                      ptm.invokeRule(null,line(),start());
                    }
                    pushFollow(FOLLOW_ruleName_in_reference1308);
                    temp_ruleName=ruleName();
                    _fsp--;
                    if (failed) return r;
                    if ( backtracking==0 ) {
                      f.set(r,"ruleName",convert(temp_ruleName));
                    }
                    if ( backtracking==0 ) {
                      ptm.ruleFinished(getLastToken(),end());
                    }

                    }
                    break;

            }

            if ( backtracking==0 ) {
              ptm.invokeRule(null,line(),start());
            }
            match(input,21,FOLLOW_21_in_reference1323); if (failed) return r;
            if ( backtracking==0 ) {
              ptm.ruleFinished(getLastToken(),end());
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return r;
    }
    // $ANTLR end reference


    // $ANTLR start assignOperator
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:321:1: assignOperator returns [Object e] : ( '=' | '?=' | '+=' );
    public Object assignOperator() throws RecognitionException {
        Object e = null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:322:6: ( '=' | '?=' | '+=' )
            int alt20=3;
            switch ( input.LA(1) ) {
            case 26:
                {
                alt20=1;
                }
                break;
            case 30:
                {
                alt20=2;
                }
                break;
            case 31:
                {
                alt20=3;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return e;}
                NoViableAltException nvae =
                    new NoViableAltException("321:1: assignOperator returns [Object e] : ( '=' | '?=' | '+=' );", 20, 0, input);

                throw nvae;
            }

            switch (alt20) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:322:6: '='
                    {
                    match(input,26,FOLLOW_26_in_assignOperator1342); if (failed) return e;
                    if ( backtracking==0 ) {
                      e=f.enumLit("AssignOperator","ASSIGN");
                    }

                    }
                    break;
                case 2 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:323:6: '?='
                    {
                    match(input,30,FOLLOW_30_in_assignOperator1351); if (failed) return e;
                    if ( backtracking==0 ) {
                      e=f.enumLit("AssignOperator","BOOLASSIGN");
                    }

                    }
                    break;
                case 3 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:324:6: '+='
                    {
                    match(input,31,FOLLOW_31_in_assignOperator1360); if (failed) return e;
                    if ( backtracking==0 ) {
                      e=f.enumLit("AssignOperator","ADD");
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end assignOperator


    // $ANTLR start cardinalityType
    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:327:1: cardinalityType returns [Object e] : ( '?' | '*' | '+' );
    public Object cardinalityType() throws RecognitionException {
        Object e = null;

        try {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:328:6: ( '?' | '*' | '+' )
            int alt21=3;
            switch ( input.LA(1) ) {
            case 32:
                {
                alt21=1;
                }
                break;
            case 33:
                {
                alt21=2;
                }
                break;
            case 34:
                {
                alt21=3;
                }
                break;
            default:
                if (backtracking>0) {failed=true; return e;}
                NoViableAltException nvae =
                    new NoViableAltException("327:1: cardinalityType returns [Object e] : ( '?' | '*' | '+' );", 21, 0, input);

                throw nvae;
            }

            switch (alt21) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:328:6: '?'
                    {
                    match(input,32,FOLLOW_32_in_cardinalityType1380); if (failed) return e;
                    if ( backtracking==0 ) {
                      e=f.enumLit("CardinalityType","OPTIONAL");
                    }

                    }
                    break;
                case 2 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:329:6: '*'
                    {
                    match(input,33,FOLLOW_33_in_cardinalityType1389); if (failed) return e;
                    if ( backtracking==0 ) {
                      e=f.enumLit("CardinalityType","ANY");
                    }

                    }
                    break;
                case 3 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:330:6: '+'
                    {
                    match(input,34,FOLLOW_34_in_cardinalityType1398); if (failed) return e;
                    if ( backtracking==0 ) {
                      e=f.enumLit("CardinalityType","ONEORMORE");
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return e;
    }
    // $ANTLR end cardinalityType

    // $ANTLR start synpred1
    public void synpred1_fragment() throws RecognitionException {   
        // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:262:8: ( ID ( '=' | '?=' | '+=' ) )
        // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:262:9: ID ( '=' | '?=' | '+=' )
        {
        match(input,ID,FOLLOW_ID_in_synpred1977); if (failed) return ;
        if ( input.LA(1)==26||(input.LA(1)>=30 && input.LA(1)<=31) ) {
            input.consume();
            errorRecovery=false;failed=false;
        }
        else {
            if (backtracking>0) {failed=true; return ;}
            MismatchedSetException mse =
                new MismatchedSetException(null,input);
            recoverFromMismatchedSet(input,mse,FOLLOW_set_in_synpred1979);    throw mse;
        }


        }
    }
    // $ANTLR end synpred1

    public final boolean synpred1() {
        backtracking++;
        int start = input.mark();
        try {
            synpred1_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !failed;
        input.rewind(start);
        backtracking--;
        failed=false;
        return success;
    }


 

    public static final BitSet FOLLOW_xtextFile_in_parse54 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_parse56 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_10_in_xtextFile89 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_xtextFile94 = new BitSet(new long[]{0x000000000184E812L});
    public static final BitSet FOLLOW_11_in_xtextFile108 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_STRING_in_xtextFile114 = new BitSet(new long[]{0x000000000184E012L});
    public static final BitSet FOLLOW_12_in_xtextFile133 = new BitSet(new long[]{0x000000000184E012L});
    public static final BitSet FOLLOW_13_in_xtextFile153 = new BitSet(new long[]{0x000000000184C012L});
    public static final BitSet FOLLOW_importGrammar_in_xtextFile168 = new BitSet(new long[]{0x000000000184C012L});
    public static final BitSet FOLLOW_importMetamodel_in_xtextFile183 = new BitSet(new long[]{0x0000000001848012L});
    public static final BitSet FOLLOW_rule_in_xtextFile202 = new BitSet(new long[]{0x0000000001840012L});
    public static final BitSet FOLLOW_14_in_importGrammar236 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_STRING_in_importGrammar248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_importMetamodel281 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_STRING_in_importMetamodel293 = new BitSet(new long[]{0x0000000000030000L});
    public static final BitSet FOLLOW_16_in_importMetamodel302 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_importMetamodel314 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_importMetamodel327 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_typeRule_in_rule349 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_stringRule_in_rule361 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_lexerRule_in_rule373 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_enumRule_in_rule385 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_lexerRule410 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_lexerRule419 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_lexerRule427 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_STRING_in_lexerRule436 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_lexerRule445 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_typeRule477 = new BitSet(new long[]{0x0000000000180000L});
    public static final BitSet FOLLOW_20_in_typeRule488 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_typeNameRule_in_typeRule500 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_typeRule511 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_typeRule522 = new BitSet(new long[]{0x0000000028100030L});
    public static final BitSet FOLLOW_alternatives_in_typeRule533 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_typeRule545 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_typeNameRule576 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_22_in_typeNameRule587 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_typeNameRule600 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_stringRule629 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_stringRule640 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_stringRule651 = new BitSet(new long[]{0x0000000028100030L});
    public static final BitSet FOLLOW_alternatives_in_stringRule662 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_17_in_stringRule672 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_enumRule699 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ID_in_enumRule710 = new BitSet(new long[]{0x0000000000180000L});
    public static final BitSet FOLLOW_20_in_enumRule722 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_typeNameRule_in_enumRule734 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_enumRule745 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_19_in_enumRule756 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_enumLiteral_in_enumRule767 = new BitSet(new long[]{0x0000000002020000L});
    public static final BitSet FOLLOW_25_in_enumRule778 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_enumLiteral_in_enumRule790 = new BitSet(new long[]{0x0000000002020000L});
    public static final BitSet FOLLOW_17_in_enumRule802 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_enumLiteral830 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_26_in_enumLiteral840 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_STRING_in_enumLiteral851 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_group_in_alternatives879 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_25_in_alternatives890 = new BitSet(new long[]{0x0000000028100030L});
    public static final BitSet FOLLOW_group_in_alternatives902 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_terminal_in_group934 = new BitSet(new long[]{0x0000000028100032L});
    public static final BitSet FOLLOW_terminal_in_group950 = new BitSet(new long[]{0x0000000028100032L});
    public static final BitSet FOLLOW_assignment_in_terminal991 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_abstractToken_in_terminal1001 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_assignment1026 = new BitSet(new long[]{0x00000000C4000000L});
    public static final BitSet FOLLOW_assignOperator_in_assignment1038 = new BitSet(new long[]{0x0000000028100030L});
    public static final BitSet FOLLOW_abstractToken_in_assignment1050 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_keyword_in_abstractToken1073 = new BitSet(new long[]{0x0000000700000002L});
    public static final BitSet FOLLOW_ruleName_in_abstractToken1083 = new BitSet(new long[]{0x0000000700000002L});
    public static final BitSet FOLLOW_reference_in_abstractToken1093 = new BitSet(new long[]{0x0000000700000002L});
    public static final BitSet FOLLOW_fileReference_in_abstractToken1103 = new BitSet(new long[]{0x0000000700000002L});
    public static final BitSet FOLLOW_paranthesizedElement_in_abstractToken1114 = new BitSet(new long[]{0x0000000700000002L});
    public static final BitSet FOLLOW_cardinalityType_in_abstractToken1126 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_27_in_paranthesizedElement1148 = new BitSet(new long[]{0x0000000028100030L});
    public static final BitSet FOLLOW_alternatives_in_paranthesizedElement1158 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_28_in_paranthesizedElement1166 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_29_in_fileReference1194 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_keyword1221 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_ruleName1248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_reference1272 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_typeNameRule_in_reference1283 = new BitSet(new long[]{0x0000000002200000L});
    public static final BitSet FOLLOW_25_in_reference1297 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ruleName_in_reference1308 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_reference1323 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_26_in_assignOperator1342 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_30_in_assignOperator1351 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_31_in_assignOperator1360 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_32_in_cardinalityType1380 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_33_in_cardinalityType1389 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_34_in_cardinalityType1398 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_synpred1977 = new BitSet(new long[]{0x00000000C4000000L});
    public static final BitSet FOLLOW_set_in_synpred1979 = new BitSet(new long[]{0x0000000000000002L});

}