// $ANTLR 3.0 /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g 2008-02-12 11:20:15

package org.openarchitectureware.xtext.parser.antlr; 

import java.util.ArrayList;
import java.util.List;

import org.antlr.runtime.CharStream;
import org.antlr.runtime.EarlyExitException;
import org.antlr.runtime.Lexer;
import org.antlr.runtime.MismatchedSetException;
import org.antlr.runtime.NoViableAltException;
import org.antlr.runtime.RecognitionException;
import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.parser.impl.AntlrUtil;

public class XTextLexer extends Lexer {
    public static final int T29=29;
    public static final int T28=28;
    public static final int T27=27;
    public static final int T26=26;
    public static final int T25=25;
    public static final int ID=4;
    public static final int Tokens=35;
    public static final int T24=24;
    public static final int EOF=-1;
    public static final int T23=23;
    public static final int T22=22;
    public static final int T21=21;
    public static final int T20=20;
    public static final int XTEXT_WS=9;
    public static final int T10=10;
    public static final int XTEXT_INT=6;
    public static final int T11=11;
    public static final int T12=12;
    public static final int T13=13;
    public static final int XTEXT_ML_COMMENT=7;
    public static final int XTEXT_SL_COMMENT=8;
    public static final int T14=14;
    public static final int T34=34;
    public static final int T15=15;
    public static final int T33=33;
    public static final int T16=16;
    public static final int T17=17;
    public static final int T18=18;
    public static final int T30=30;
    public static final int T19=19;
    public static final int T32=32;
    public static final int STRING=5;
    public static final int T31=31;

       private List<ErrorMsg> errors = new ArrayList<ErrorMsg>();
    	public List<ErrorMsg> getErrors() {
    		return errors;
    	}
    	
    	public String getErrorMessage(RecognitionException e, String[] tokenNames) { 
    		String msg = super.getErrorMessage(e,tokenNames);
    		errors.add(AntlrUtil.create(msg,e,tokenNames));
    		return msg; 
    	} 

    public XTextLexer() {;} 
    public XTextLexer(CharStream input) {
        super(input);
    }
    public String getGrammarFileName() { return "/Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g"; }

    // $ANTLR start T10
    public void mT10() throws RecognitionException {
        try {
            int _type = T10;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:30:7: ( 'grammar_name' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:30:7: 'grammar_name'
            {
            match("grammar_name"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T10

    // $ANTLR start T11
    public void mT11() throws RecognitionException {
        try {
            int _type = T11;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:31:7: ( 'grammar_nsURI' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:31:7: 'grammar_nsURI'
            {
            match("grammar_nsURI"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T11

    // $ANTLR start T12
    public void mT12() throws RecognitionException {
        try {
            int _type = T12;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:32:7: ( 'preventMMGeneration' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:32:7: 'preventMMGeneration'
            {
            match("preventMMGeneration"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T12

    // $ANTLR start T13
    public void mT13() throws RecognitionException {
        try {
            int _type = T13;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:33:7: ( 'commentsDisabled' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:33:7: 'commentsDisabled'
            {
            match("commentsDisabled"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T13

    // $ANTLR start T14
    public void mT14() throws RecognitionException {
        try {
            int _type = T14;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:34:7: ( 'importGrammar' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:34:7: 'importGrammar'
            {
            match("importGrammar"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T14

    // $ANTLR start T15
    public void mT15() throws RecognitionException {
        try {
            int _type = T15;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:35:7: ( 'importMetamodel' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:35:7: 'importMetamodel'
            {
            match("importMetamodel"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T15

    // $ANTLR start T16
    public void mT16() throws RecognitionException {
        try {
            int _type = T16;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:36:7: ( 'as' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:36:7: 'as'
            {
            match("as"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T16

    // $ANTLR start T17
    public void mT17() throws RecognitionException {
        try {
            int _type = T17;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:37:7: ( ';' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:37:7: ';'
            {
            match(';'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T17

    // $ANTLR start T18
    public void mT18() throws RecognitionException {
        try {
            int _type = T18;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:38:7: ( 'Native' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:38:7: 'Native'
            {
            match("Native"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T18

    // $ANTLR start T19
    public void mT19() throws RecognitionException {
        try {
            int _type = T19;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:39:7: ( ':' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:39:7: ':'
            {
            match(':'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T19

    // $ANTLR start T20
    public void mT20() throws RecognitionException {
        try {
            int _type = T20;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:40:7: ( '[' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:40:7: '['
            {
            match('['); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T20

    // $ANTLR start T21
    public void mT21() throws RecognitionException {
        try {
            int _type = T21;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:41:7: ( ']' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:41:7: ']'
            {
            match(']'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T21

    // $ANTLR start T22
    public void mT22() throws RecognitionException {
        try {
            int _type = T22;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:42:7: ( '::' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:42:7: '::'
            {
            match("::"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T22

    // $ANTLR start T23
    public void mT23() throws RecognitionException {
        try {
            int _type = T23;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:43:7: ( 'String' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:43:7: 'String'
            {
            match("String"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T23

    // $ANTLR start T24
    public void mT24() throws RecognitionException {
        try {
            int _type = T24;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:44:7: ( 'Enum' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:44:7: 'Enum'
            {
            match("Enum"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T24

    // $ANTLR start T25
    public void mT25() throws RecognitionException {
        try {
            int _type = T25;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:45:7: ( '|' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:45:7: '|'
            {
            match('|'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T25

    // $ANTLR start T26
    public void mT26() throws RecognitionException {
        try {
            int _type = T26;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:46:7: ( '=' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:46:7: '='
            {
            match('='); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T26

    // $ANTLR start T27
    public void mT27() throws RecognitionException {
        try {
            int _type = T27;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:47:7: ( '(' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:47:7: '('
            {
            match('('); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T27

    // $ANTLR start T28
    public void mT28() throws RecognitionException {
        try {
            int _type = T28;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:48:7: ( ')' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:48:7: ')'
            {
            match(')'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T28

    // $ANTLR start T29
    public void mT29() throws RecognitionException {
        try {
            int _type = T29;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:49:7: ( 'URI' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:49:7: 'URI'
            {
            match("URI"); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T29

    // $ANTLR start T30
    public void mT30() throws RecognitionException {
        try {
            int _type = T30;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:50:7: ( '?=' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:50:7: '?='
            {
            match("?="); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T30

    // $ANTLR start T31
    public void mT31() throws RecognitionException {
        try {
            int _type = T31;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:51:7: ( '+=' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:51:7: '+='
            {
            match("+="); 


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T31

    // $ANTLR start T32
    public void mT32() throws RecognitionException {
        try {
            int _type = T32;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:52:7: ( '?' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:52:7: '?'
            {
            match('?'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T32

    // $ANTLR start T33
    public void mT33() throws RecognitionException {
        try {
            int _type = T33;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:53:7: ( '*' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:53:7: '*'
            {
            match('*'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T33

    // $ANTLR start T34
    public void mT34() throws RecognitionException {
        try {
            int _type = T34;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:54:7: ( '+' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:54:7: '+'
            {
            match('+'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end T34

    // $ANTLR start STRING
    public void mSTRING() throws RecognitionException {
        try {
            int _type = STRING;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:335:5: ( '\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\"' ) )* '\"' | '\\'' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\'' ) )* '\\'' )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0=='\"') ) {
                alt3=1;
            }
            else if ( (LA3_0=='\'') ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("334:1: STRING : ( '\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\"' ) )* '\"' | '\\'' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\'' ) )* '\\'' );", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:335:5: '\"' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\"' ) )* '\"'
                    {
                    match('\"'); 
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:335:9: ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\"' ) )*
                    loop1:
                    do {
                        int alt1=3;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0=='\\') ) {
                            alt1=1;
                        }
                        else if ( ((LA1_0>='\u0000' && LA1_0<='!')||(LA1_0>='#' && LA1_0<='[')||(LA1_0>=']' && LA1_0<='\uFFFE')) ) {
                            alt1=2;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:335:11: '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' )
                    	    {
                    	    match('\\'); 
                    	    if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='b'||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t' ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;
                    	case 2 :
                    	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:335:55: ~ ( '\\\\' | '\"' )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFE') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);

                    match('\"'); 

                    }
                    break;
                case 2 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:336:5: '\\'' ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\'' ) )* '\\''
                    {
                    match('\''); 
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:336:10: ( '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' ) | ~ ( '\\\\' | '\\'' ) )*
                    loop2:
                    do {
                        int alt2=3;
                        int LA2_0 = input.LA(1);

                        if ( (LA2_0=='\\') ) {
                            alt2=1;
                        }
                        else if ( ((LA2_0>='\u0000' && LA2_0<='&')||(LA2_0>='(' && LA2_0<='[')||(LA2_0>=']' && LA2_0<='\uFFFE')) ) {
                            alt2=2;
                        }


                        switch (alt2) {
                    	case 1 :
                    	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:336:12: '\\\\' ( 'b' | 't' | 'n' | 'f' | 'r' | '\\\"' | '\\'' | '\\\\' )
                    	    {
                    	    match('\\'); 
                    	    if ( input.LA(1)=='\"'||input.LA(1)=='\''||input.LA(1)=='\\'||input.LA(1)=='b'||input.LA(1)=='f'||input.LA(1)=='n'||input.LA(1)=='r'||input.LA(1)=='t' ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;
                    	case 2 :
                    	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:336:56: ~ ( '\\\\' | '\\'' )
                    	    {
                    	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='&')||(input.LA(1)>='(' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFE') ) {
                    	        input.consume();

                    	    }
                    	    else {
                    	        MismatchedSetException mse =
                    	            new MismatchedSetException(null,input);
                    	        recover(mse);    throw mse;
                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop2;
                        }
                    } while (true);

                    match('\''); 

                    }
                    break;

            }
            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end STRING

    // $ANTLR start ID
    public void mID() throws RecognitionException {
        try {
            int _type = ID;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:339:2: ( ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )* )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:339:2: ( '^' )? ( 'a' .. 'z' | 'A' .. 'Z' | '_' ) ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:339:2: ( '^' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0=='^') ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:339:3: '^'
                    {
                    match('^'); 

                    }
                    break;

            }

            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }

            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:339:32: ( 'a' .. 'z' | 'A' .. 'Z' | '_' | '0' .. '9' )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>='0' && LA5_0<='9')||(LA5_0>='A' && LA5_0<='Z')||LA5_0=='_'||(LA5_0>='a' && LA5_0<='z')) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end ID

    // $ANTLR start XTEXT_INT
    public void mXTEXT_INT() throws RecognitionException {
        try {
            int _type = XTEXT_INT;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:343:2: ( ( '0' .. '9' )+ )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:343:2: ( '0' .. '9' )+
            {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:343:2: ( '0' .. '9' )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>='0' && LA6_0<='9')) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:343:3: '0' .. '9'
            	    {
            	    matchRange('0','9'); 

            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end XTEXT_INT

    // $ANTLR start XTEXT_ML_COMMENT
    public void mXTEXT_ML_COMMENT() throws RecognitionException {
        try {
            int _type = XTEXT_ML_COMMENT;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:347:9: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:347:9: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match("/*"); 

            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:347:14: ( options {greedy=false; } : . )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0=='*') ) {
                    int LA7_1 = input.LA(2);

                    if ( (LA7_1=='/') ) {
                        alt7=2;
                    }
                    else if ( ((LA7_1>='\u0000' && LA7_1<='.')||(LA7_1>='0' && LA7_1<='\uFFFE')) ) {
                        alt7=1;
                    }


                }
                else if ( ((LA7_0>='\u0000' && LA7_0<=')')||(LA7_0>='+' && LA7_0<='\uFFFE')) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:347:42: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            match("*/"); 

            channel=HIDDEN;

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end XTEXT_ML_COMMENT

    // $ANTLR start XTEXT_SL_COMMENT
    public void mXTEXT_SL_COMMENT() throws RecognitionException {
        try {
            int _type = XTEXT_SL_COMMENT;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:351:7: ( '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n' )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:351:7: '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n'
            {
            match("//"); 

            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:351:12: (~ ( '\\n' | '\\r' ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( ((LA8_0>='\u0000' && LA8_0<='\t')||(LA8_0>='\u000B' && LA8_0<='\f')||(LA8_0>='\u000E' && LA8_0<='\uFFFE')) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:351:12: ~ ( '\\n' | '\\r' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFE') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:351:26: ( '\\r' )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0=='\r') ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:351:26: '\\r'
                    {
                    match('\r'); 

                    }
                    break;

            }

            match('\n'); 
            channel=HIDDEN;

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end XTEXT_SL_COMMENT

    // $ANTLR start XTEXT_WS
    public void mXTEXT_WS() throws RecognitionException {
        try {
            int _type = XTEXT_WS;
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:354:12: ( ( ' ' | '\\t' | '\\r' | '\\n' )+ )
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:354:12: ( ' ' | '\\t' | '\\r' | '\\n' )+
            {
            // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:354:12: ( ' ' | '\\t' | '\\r' | '\\n' )+
            int cnt10=0;
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( ((LA10_0>='\t' && LA10_0<='\n')||LA10_0=='\r'||LA10_0==' ') ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||input.LA(1)=='\r'||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt10 >= 1 ) break loop10;
                        EarlyExitException eee =
                            new EarlyExitException(10, input);
                        throw eee;
                }
                cnt10++;
            } while (true);

            channel=HIDDEN;

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end XTEXT_WS

    public void mTokens() throws RecognitionException {
        // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:10: ( T10 | T11 | T12 | T13 | T14 | T15 | T16 | T17 | T18 | T19 | T20 | T21 | T22 | T23 | T24 | T25 | T26 | T27 | T28 | T29 | T30 | T31 | T32 | T33 | T34 | STRING | ID | XTEXT_INT | XTEXT_ML_COMMENT | XTEXT_SL_COMMENT | XTEXT_WS )
        int alt11=31;
        switch ( input.LA(1) ) {
        case 'g':
            {
            int LA11_1 = input.LA(2);

            if ( (LA11_1=='r') ) {
                int LA11_26 = input.LA(3);

                if ( (LA11_26=='a') ) {
                    int LA11_43 = input.LA(4);

                    if ( (LA11_43=='m') ) {
                        int LA11_52 = input.LA(5);

                        if ( (LA11_52=='m') ) {
                            int LA11_60 = input.LA(6);

                            if ( (LA11_60=='a') ) {
                                int LA11_67 = input.LA(7);

                                if ( (LA11_67=='r') ) {
                                    int LA11_73 = input.LA(8);

                                    if ( (LA11_73=='_') ) {
                                        int LA11_80 = input.LA(9);

                                        if ( (LA11_80=='n') ) {
                                            switch ( input.LA(10) ) {
                                            case 'a':
                                                {
                                                int LA11_90 = input.LA(11);

                                                if ( (LA11_90=='m') ) {
                                                    int LA11_96 = input.LA(12);

                                                    if ( (LA11_96=='e') ) {
                                                        int LA11_102 = input.LA(13);

                                                        if ( ((LA11_102>='0' && LA11_102<='9')||(LA11_102>='A' && LA11_102<='Z')||LA11_102=='_'||(LA11_102>='a' && LA11_102<='z')) ) {
                                                            alt11=27;
                                                        }
                                                        else {
                                                            alt11=1;}
                                                    }
                                                    else {
                                                        alt11=27;}
                                                }
                                                else {
                                                    alt11=27;}
                                                }
                                                break;
                                            case 's':
                                                {
                                                int LA11_91 = input.LA(11);

                                                if ( (LA11_91=='U') ) {
                                                    int LA11_97 = input.LA(12);

                                                    if ( (LA11_97=='R') ) {
                                                        int LA11_103 = input.LA(13);

                                                        if ( (LA11_103=='I') ) {
                                                            int LA11_109 = input.LA(14);

                                                            if ( ((LA11_109>='0' && LA11_109<='9')||(LA11_109>='A' && LA11_109<='Z')||LA11_109=='_'||(LA11_109>='a' && LA11_109<='z')) ) {
                                                                alt11=27;
                                                            }
                                                            else {
                                                                alt11=2;}
                                                        }
                                                        else {
                                                            alt11=27;}
                                                    }
                                                    else {
                                                        alt11=27;}
                                                }
                                                else {
                                                    alt11=27;}
                                                }
                                                break;
                                            default:
                                                alt11=27;}

                                        }
                                        else {
                                            alt11=27;}
                                    }
                                    else {
                                        alt11=27;}
                                }
                                else {
                                    alt11=27;}
                            }
                            else {
                                alt11=27;}
                        }
                        else {
                            alt11=27;}
                    }
                    else {
                        alt11=27;}
                }
                else {
                    alt11=27;}
            }
            else {
                alt11=27;}
            }
            break;
        case 'p':
            {
            int LA11_2 = input.LA(2);

            if ( (LA11_2=='r') ) {
                int LA11_27 = input.LA(3);

                if ( (LA11_27=='e') ) {
                    int LA11_44 = input.LA(4);

                    if ( (LA11_44=='v') ) {
                        int LA11_53 = input.LA(5);

                        if ( (LA11_53=='e') ) {
                            int LA11_61 = input.LA(6);

                            if ( (LA11_61=='n') ) {
                                int LA11_68 = input.LA(7);

                                if ( (LA11_68=='t') ) {
                                    int LA11_74 = input.LA(8);

                                    if ( (LA11_74=='M') ) {
                                        int LA11_81 = input.LA(9);

                                        if ( (LA11_81=='M') ) {
                                            int LA11_86 = input.LA(10);

                                            if ( (LA11_86=='G') ) {
                                                int LA11_92 = input.LA(11);

                                                if ( (LA11_92=='e') ) {
                                                    int LA11_98 = input.LA(12);

                                                    if ( (LA11_98=='n') ) {
                                                        int LA11_104 = input.LA(13);

                                                        if ( (LA11_104=='e') ) {
                                                            int LA11_110 = input.LA(14);

                                                            if ( (LA11_110=='r') ) {
                                                                int LA11_115 = input.LA(15);

                                                                if ( (LA11_115=='a') ) {
                                                                    int LA11_119 = input.LA(16);

                                                                    if ( (LA11_119=='t') ) {
                                                                        int LA11_122 = input.LA(17);

                                                                        if ( (LA11_122=='i') ) {
                                                                            int LA11_125 = input.LA(18);

                                                                            if ( (LA11_125=='o') ) {
                                                                                int LA11_127 = input.LA(19);

                                                                                if ( (LA11_127=='n') ) {
                                                                                    int LA11_128 = input.LA(20);

                                                                                    if ( ((LA11_128>='0' && LA11_128<='9')||(LA11_128>='A' && LA11_128<='Z')||LA11_128=='_'||(LA11_128>='a' && LA11_128<='z')) ) {
                                                                                        alt11=27;
                                                                                    }
                                                                                    else {
                                                                                        alt11=3;}
                                                                                }
                                                                                else {
                                                                                    alt11=27;}
                                                                            }
                                                                            else {
                                                                                alt11=27;}
                                                                        }
                                                                        else {
                                                                            alt11=27;}
                                                                    }
                                                                    else {
                                                                        alt11=27;}
                                                                }
                                                                else {
                                                                    alt11=27;}
                                                            }
                                                            else {
                                                                alt11=27;}
                                                        }
                                                        else {
                                                            alt11=27;}
                                                    }
                                                    else {
                                                        alt11=27;}
                                                }
                                                else {
                                                    alt11=27;}
                                            }
                                            else {
                                                alt11=27;}
                                        }
                                        else {
                                            alt11=27;}
                                    }
                                    else {
                                        alt11=27;}
                                }
                                else {
                                    alt11=27;}
                            }
                            else {
                                alt11=27;}
                        }
                        else {
                            alt11=27;}
                    }
                    else {
                        alt11=27;}
                }
                else {
                    alt11=27;}
            }
            else {
                alt11=27;}
            }
            break;
        case 'c':
            {
            int LA11_3 = input.LA(2);

            if ( (LA11_3=='o') ) {
                int LA11_28 = input.LA(3);

                if ( (LA11_28=='m') ) {
                    int LA11_45 = input.LA(4);

                    if ( (LA11_45=='m') ) {
                        int LA11_54 = input.LA(5);

                        if ( (LA11_54=='e') ) {
                            int LA11_62 = input.LA(6);

                            if ( (LA11_62=='n') ) {
                                int LA11_69 = input.LA(7);

                                if ( (LA11_69=='t') ) {
                                    int LA11_75 = input.LA(8);

                                    if ( (LA11_75=='s') ) {
                                        int LA11_82 = input.LA(9);

                                        if ( (LA11_82=='D') ) {
                                            int LA11_87 = input.LA(10);

                                            if ( (LA11_87=='i') ) {
                                                int LA11_93 = input.LA(11);

                                                if ( (LA11_93=='s') ) {
                                                    int LA11_99 = input.LA(12);

                                                    if ( (LA11_99=='a') ) {
                                                        int LA11_105 = input.LA(13);

                                                        if ( (LA11_105=='b') ) {
                                                            int LA11_111 = input.LA(14);

                                                            if ( (LA11_111=='l') ) {
                                                                int LA11_116 = input.LA(15);

                                                                if ( (LA11_116=='e') ) {
                                                                    int LA11_120 = input.LA(16);

                                                                    if ( (LA11_120=='d') ) {
                                                                        int LA11_123 = input.LA(17);

                                                                        if ( ((LA11_123>='0' && LA11_123<='9')||(LA11_123>='A' && LA11_123<='Z')||LA11_123=='_'||(LA11_123>='a' && LA11_123<='z')) ) {
                                                                            alt11=27;
                                                                        }
                                                                        else {
                                                                            alt11=4;}
                                                                    }
                                                                    else {
                                                                        alt11=27;}
                                                                }
                                                                else {
                                                                    alt11=27;}
                                                            }
                                                            else {
                                                                alt11=27;}
                                                        }
                                                        else {
                                                            alt11=27;}
                                                    }
                                                    else {
                                                        alt11=27;}
                                                }
                                                else {
                                                    alt11=27;}
                                            }
                                            else {
                                                alt11=27;}
                                        }
                                        else {
                                            alt11=27;}
                                    }
                                    else {
                                        alt11=27;}
                                }
                                else {
                                    alt11=27;}
                            }
                            else {
                                alt11=27;}
                        }
                        else {
                            alt11=27;}
                    }
                    else {
                        alt11=27;}
                }
                else {
                    alt11=27;}
            }
            else {
                alt11=27;}
            }
            break;
        case 'i':
            {
            int LA11_4 = input.LA(2);

            if ( (LA11_4=='m') ) {
                int LA11_29 = input.LA(3);

                if ( (LA11_29=='p') ) {
                    int LA11_46 = input.LA(4);

                    if ( (LA11_46=='o') ) {
                        int LA11_55 = input.LA(5);

                        if ( (LA11_55=='r') ) {
                            int LA11_63 = input.LA(6);

                            if ( (LA11_63=='t') ) {
                                switch ( input.LA(7) ) {
                                case 'M':
                                    {
                                    int LA11_76 = input.LA(8);

                                    if ( (LA11_76=='e') ) {
                                        int LA11_83 = input.LA(9);

                                        if ( (LA11_83=='t') ) {
                                            int LA11_88 = input.LA(10);

                                            if ( (LA11_88=='a') ) {
                                                int LA11_94 = input.LA(11);

                                                if ( (LA11_94=='m') ) {
                                                    int LA11_100 = input.LA(12);

                                                    if ( (LA11_100=='o') ) {
                                                        int LA11_106 = input.LA(13);

                                                        if ( (LA11_106=='d') ) {
                                                            int LA11_112 = input.LA(14);

                                                            if ( (LA11_112=='e') ) {
                                                                int LA11_117 = input.LA(15);

                                                                if ( (LA11_117=='l') ) {
                                                                    int LA11_121 = input.LA(16);

                                                                    if ( ((LA11_121>='0' && LA11_121<='9')||(LA11_121>='A' && LA11_121<='Z')||LA11_121=='_'||(LA11_121>='a' && LA11_121<='z')) ) {
                                                                        alt11=27;
                                                                    }
                                                                    else {
                                                                        alt11=6;}
                                                                }
                                                                else {
                                                                    alt11=27;}
                                                            }
                                                            else {
                                                                alt11=27;}
                                                        }
                                                        else {
                                                            alt11=27;}
                                                    }
                                                    else {
                                                        alt11=27;}
                                                }
                                                else {
                                                    alt11=27;}
                                            }
                                            else {
                                                alt11=27;}
                                        }
                                        else {
                                            alt11=27;}
                                    }
                                    else {
                                        alt11=27;}
                                    }
                                    break;
                                case 'G':
                                    {
                                    int LA11_77 = input.LA(8);

                                    if ( (LA11_77=='r') ) {
                                        int LA11_84 = input.LA(9);

                                        if ( (LA11_84=='a') ) {
                                            int LA11_89 = input.LA(10);

                                            if ( (LA11_89=='m') ) {
                                                int LA11_95 = input.LA(11);

                                                if ( (LA11_95=='m') ) {
                                                    int LA11_101 = input.LA(12);

                                                    if ( (LA11_101=='a') ) {
                                                        int LA11_107 = input.LA(13);

                                                        if ( (LA11_107=='r') ) {
                                                            int LA11_113 = input.LA(14);

                                                            if ( ((LA11_113>='0' && LA11_113<='9')||(LA11_113>='A' && LA11_113<='Z')||LA11_113=='_'||(LA11_113>='a' && LA11_113<='z')) ) {
                                                                alt11=27;
                                                            }
                                                            else {
                                                                alt11=5;}
                                                        }
                                                        else {
                                                            alt11=27;}
                                                    }
                                                    else {
                                                        alt11=27;}
                                                }
                                                else {
                                                    alt11=27;}
                                            }
                                            else {
                                                alt11=27;}
                                        }
                                        else {
                                            alt11=27;}
                                    }
                                    else {
                                        alt11=27;}
                                    }
                                    break;
                                default:
                                    alt11=27;}

                            }
                            else {
                                alt11=27;}
                        }
                        else {
                            alt11=27;}
                    }
                    else {
                        alt11=27;}
                }
                else {
                    alt11=27;}
            }
            else {
                alt11=27;}
            }
            break;
        case 'a':
            {
            int LA11_5 = input.LA(2);

            if ( (LA11_5=='s') ) {
                int LA11_30 = input.LA(3);

                if ( ((LA11_30>='0' && LA11_30<='9')||(LA11_30>='A' && LA11_30<='Z')||LA11_30=='_'||(LA11_30>='a' && LA11_30<='z')) ) {
                    alt11=27;
                }
                else {
                    alt11=7;}
            }
            else {
                alt11=27;}
            }
            break;
        case ';':
            {
            alt11=8;
            }
            break;
        case 'N':
            {
            int LA11_7 = input.LA(2);

            if ( (LA11_7=='a') ) {
                int LA11_31 = input.LA(3);

                if ( (LA11_31=='t') ) {
                    int LA11_48 = input.LA(4);

                    if ( (LA11_48=='i') ) {
                        int LA11_56 = input.LA(5);

                        if ( (LA11_56=='v') ) {
                            int LA11_64 = input.LA(6);

                            if ( (LA11_64=='e') ) {
                                int LA11_71 = input.LA(7);

                                if ( ((LA11_71>='0' && LA11_71<='9')||(LA11_71>='A' && LA11_71<='Z')||LA11_71=='_'||(LA11_71>='a' && LA11_71<='z')) ) {
                                    alt11=27;
                                }
                                else {
                                    alt11=9;}
                            }
                            else {
                                alt11=27;}
                        }
                        else {
                            alt11=27;}
                    }
                    else {
                        alt11=27;}
                }
                else {
                    alt11=27;}
            }
            else {
                alt11=27;}
            }
            break;
        case ':':
            {
            int LA11_8 = input.LA(2);

            if ( (LA11_8==':') ) {
                alt11=13;
            }
            else {
                alt11=10;}
            }
            break;
        case '[':
            {
            alt11=11;
            }
            break;
        case ']':
            {
            alt11=12;
            }
            break;
        case 'S':
            {
            int LA11_11 = input.LA(2);

            if ( (LA11_11=='t') ) {
                int LA11_34 = input.LA(3);

                if ( (LA11_34=='r') ) {
                    int LA11_49 = input.LA(4);

                    if ( (LA11_49=='i') ) {
                        int LA11_57 = input.LA(5);

                        if ( (LA11_57=='n') ) {
                            int LA11_65 = input.LA(6);

                            if ( (LA11_65=='g') ) {
                                int LA11_72 = input.LA(7);

                                if ( ((LA11_72>='0' && LA11_72<='9')||(LA11_72>='A' && LA11_72<='Z')||LA11_72=='_'||(LA11_72>='a' && LA11_72<='z')) ) {
                                    alt11=27;
                                }
                                else {
                                    alt11=14;}
                            }
                            else {
                                alt11=27;}
                        }
                        else {
                            alt11=27;}
                    }
                    else {
                        alt11=27;}
                }
                else {
                    alt11=27;}
            }
            else {
                alt11=27;}
            }
            break;
        case 'E':
            {
            int LA11_12 = input.LA(2);

            if ( (LA11_12=='n') ) {
                int LA11_35 = input.LA(3);

                if ( (LA11_35=='u') ) {
                    int LA11_50 = input.LA(4);

                    if ( (LA11_50=='m') ) {
                        int LA11_58 = input.LA(5);

                        if ( ((LA11_58>='0' && LA11_58<='9')||(LA11_58>='A' && LA11_58<='Z')||LA11_58=='_'||(LA11_58>='a' && LA11_58<='z')) ) {
                            alt11=27;
                        }
                        else {
                            alt11=15;}
                    }
                    else {
                        alt11=27;}
                }
                else {
                    alt11=27;}
            }
            else {
                alt11=27;}
            }
            break;
        case '|':
            {
            alt11=16;
            }
            break;
        case '=':
            {
            alt11=17;
            }
            break;
        case '(':
            {
            alt11=18;
            }
            break;
        case ')':
            {
            alt11=19;
            }
            break;
        case 'U':
            {
            int LA11_17 = input.LA(2);

            if ( (LA11_17=='R') ) {
                int LA11_36 = input.LA(3);

                if ( (LA11_36=='I') ) {
                    int LA11_51 = input.LA(4);

                    if ( ((LA11_51>='0' && LA11_51<='9')||(LA11_51>='A' && LA11_51<='Z')||LA11_51=='_'||(LA11_51>='a' && LA11_51<='z')) ) {
                        alt11=27;
                    }
                    else {
                        alt11=20;}
                }
                else {
                    alt11=27;}
            }
            else {
                alt11=27;}
            }
            break;
        case '?':
            {
            int LA11_18 = input.LA(2);

            if ( (LA11_18=='=') ) {
                alt11=21;
            }
            else {
                alt11=23;}
            }
            break;
        case '+':
            {
            int LA11_19 = input.LA(2);

            if ( (LA11_19=='=') ) {
                alt11=22;
            }
            else {
                alt11=25;}
            }
            break;
        case '*':
            {
            alt11=24;
            }
            break;
        case '\"':
        case '\'':
            {
            alt11=26;
            }
            break;
        case 'A':
        case 'B':
        case 'C':
        case 'D':
        case 'F':
        case 'G':
        case 'H':
        case 'I':
        case 'J':
        case 'K':
        case 'L':
        case 'M':
        case 'O':
        case 'P':
        case 'Q':
        case 'R':
        case 'T':
        case 'V':
        case 'W':
        case 'X':
        case 'Y':
        case 'Z':
        case '^':
        case '_':
        case 'b':
        case 'd':
        case 'e':
        case 'f':
        case 'h':
        case 'j':
        case 'k':
        case 'l':
        case 'm':
        case 'n':
        case 'o':
        case 'q':
        case 'r':
        case 's':
        case 't':
        case 'u':
        case 'v':
        case 'w':
        case 'x':
        case 'y':
        case 'z':
            {
            alt11=27;
            }
            break;
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
            {
            alt11=28;
            }
            break;
        case '/':
            {
            int LA11_24 = input.LA(2);

            if ( (LA11_24=='/') ) {
                alt11=30;
            }
            else if ( (LA11_24=='*') ) {
                alt11=29;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("1:1: Tokens : ( T10 | T11 | T12 | T13 | T14 | T15 | T16 | T17 | T18 | T19 | T20 | T21 | T22 | T23 | T24 | T25 | T26 | T27 | T28 | T29 | T30 | T31 | T32 | T33 | T34 | STRING | ID | XTEXT_INT | XTEXT_ML_COMMENT | XTEXT_SL_COMMENT | XTEXT_WS );", 11, 24, input);

                throw nvae;
            }
            }
            break;
        case '\t':
        case '\n':
        case '\r':
        case ' ':
            {
            alt11=31;
            }
            break;
        default:
            NoViableAltException nvae =
                new NoViableAltException("1:1: Tokens : ( T10 | T11 | T12 | T13 | T14 | T15 | T16 | T17 | T18 | T19 | T20 | T21 | T22 | T23 | T24 | T25 | T26 | T27 | T28 | T29 | T30 | T31 | T32 | T33 | T34 | STRING | ID | XTEXT_INT | XTEXT_ML_COMMENT | XTEXT_SL_COMMENT | XTEXT_WS );", 11, 0, input);

            throw nvae;
        }

        switch (alt11) {
            case 1 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:10: T10
                {
                mT10(); 

                }
                break;
            case 2 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:14: T11
                {
                mT11(); 

                }
                break;
            case 3 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:18: T12
                {
                mT12(); 

                }
                break;
            case 4 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:22: T13
                {
                mT13(); 

                }
                break;
            case 5 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:26: T14
                {
                mT14(); 

                }
                break;
            case 6 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:30: T15
                {
                mT15(); 

                }
                break;
            case 7 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:34: T16
                {
                mT16(); 

                }
                break;
            case 8 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:38: T17
                {
                mT17(); 

                }
                break;
            case 9 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:42: T18
                {
                mT18(); 

                }
                break;
            case 10 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:46: T19
                {
                mT19(); 

                }
                break;
            case 11 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:50: T20
                {
                mT20(); 

                }
                break;
            case 12 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:54: T21
                {
                mT21(); 

                }
                break;
            case 13 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:58: T22
                {
                mT22(); 

                }
                break;
            case 14 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:62: T23
                {
                mT23(); 

                }
                break;
            case 15 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:66: T24
                {
                mT24(); 

                }
                break;
            case 16 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:70: T25
                {
                mT25(); 

                }
                break;
            case 17 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:74: T26
                {
                mT26(); 

                }
                break;
            case 18 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:78: T27
                {
                mT27(); 

                }
                break;
            case 19 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:82: T28
                {
                mT28(); 

                }
                break;
            case 20 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:86: T29
                {
                mT29(); 

                }
                break;
            case 21 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:90: T30
                {
                mT30(); 

                }
                break;
            case 22 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:94: T31
                {
                mT31(); 

                }
                break;
            case 23 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:98: T32
                {
                mT32(); 

                }
                break;
            case 24 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:102: T33
                {
                mT33(); 

                }
                break;
            case 25 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:106: T34
                {
                mT34(); 

                }
                break;
            case 26 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:110: STRING
                {
                mSTRING(); 

                }
                break;
            case 27 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:117: ID
                {
                mID(); 

                }
                break;
            case 28 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:120: XTEXT_INT
                {
                mXTEXT_INT(); 

                }
                break;
            case 29 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:130: XTEXT_ML_COMMENT
                {
                mXTEXT_ML_COMMENT(); 

                }
                break;
            case 30 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:147: XTEXT_SL_COMMENT
                {
                mXTEXT_SL_COMMENT(); 

                }
                break;
            case 31 :
                // /Users/user/Documents/workspace/ws-apg-prototype/xtext.core/bin/XText.g:1:164: XTEXT_WS
                {
                mXTEXT_WS(); 

                }
                break;

        }

    }


 

}