/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.emf.check;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.WorkflowInterruptedException;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public abstract class EMFChecker extends AbstractWorkflowComponent {

	private String modelSlot;

	private final Map<Class<?>, Method> cache = new HashMap<Class<?>, Method>();

	private Issues issues;

	private boolean abortOnError;

	/**
	 * Sets the model slot.
	 * 
	 * @param slot
	 *            name of file
	 */
	public final void setModelSlot(final String slot) {
		modelSlot = slot;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#checkConfiguration(org.openarchitectureware.workflow.issues.Issues)
	 */
	public final void checkConfiguration(final Issues issues) {
		if (modelSlot == null) {
			issues.addError(this, "no model slot specified.", this);
		}
	}

	/**
	 * Sets if execution is aborted in case of an error or not.
	 * 
	 * @param abort
	 *            If <code>true</code>, execution is aborted on error, otherwise
	 *            not.
	 */
	public final void setAbortOnError(final boolean abort) {
		abortOnError = abort;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#invoke(org.openarchitectureware.workflow.WorkflowContext,
	 *      org.openarchitectureware.workflow.monitor.ProgressMonitor,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	@SuppressWarnings("unchecked")
	public final void invoke(final WorkflowContext ctx, final ProgressMonitor monitor, final Issues issues) {
		this.issues = issues;

		final Object model = ctx.get(modelSlot);

		if (model == null) {
			issues.addError(this, "nothing found in slot '" + modelSlot + "'", this);
			return;
		}

		Iterator<EObject> allElements = null;
		if (model instanceof EList) {
			allElements = EcoreUtil.getAllContents(Collections.singleton(((EList) model).get(0)));
		}
		else if (model instanceof EObject) {
			allElements = EcoreUtil.getAllContents(Collections.singleton(model));
		}
		else {
			issues.addError(this, "content of slot '" + modelSlot + "' is neither an EObject nor an EList.", this);
		}

		while (allElements.hasNext()) {
			final EObject e = allElements.next();
			final Class<?> cls = e.getClass();
			final Method m = getCheckMethodFor(cls);
			if (m == null) {
				continue;
			}
			invokeCheckMethod(m, e);
		}

		if (abortOnError && issues.hasErrors())
			throw new WorkflowInterruptedException("Errors found during validation.");

	}

	/**
	 * Returrns the issues.
	 * 
	 * @return the issues
	 */
	protected final Issues getIssues() {
		return issues;
	}

	private Method getCheckMethodFor(final Class<?> cls) {
		if (cache.containsKey(cls))
			return cache.get(cls);
		Class<?> currentClass = cls;
		while (currentClass != null) {
			Method m = tryToFindMethod(currentClass);
			if (m != null) {
				cache.put(cls, m);
				return m;
			}
			for (int i = 0; i < currentClass.getInterfaces().length; i++) {
				final Class<?> interfaceClass = currentClass.getInterfaces()[i];
				m = tryToFindMethod(interfaceClass);
				if (m != null) {
					cache.put(cls, m);
					return m;
				}
			}
			currentClass = currentClass.getSuperclass();
		}
		return null;
	}

	private Method tryToFindMethod(final Class<?> cls) {
		try {
			return getClass().getMethod("check", new Class[] { cls });
		}
		catch (final SecurityException e) {
		}
		catch (final NoSuchMethodException e) {
		}
		return null;
	}

	private void invokeCheckMethod(final Method m, final EObject e) {
		try {
			m.invoke(this, new Object[] { e });
		}
		catch (final InvocationTargetException ite) {
			issues.addError(this, "cannot invoker check( " + e.getClass() + " ), internal error: "
					+ ite.getCause().getMessage(), ite.getCause());
		}
		catch (final Exception ex) {
			issues.addError(this, "cannot invoker check( " + e.getClass() + " ): " + ex.getMessage(), ex);
		}
	}
}
