
package org.openarchitectureware.graphviz.wizards;

import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.editor.wizards.AbstractNewFileWizard;

import org.openarchitectureware.graphviz.DotEditorPlugin;

public class NewDotFileWizard extends AbstractNewFileWizard {

	@Override
	protected LanguageUtilities getUtilities() {
		return DotEditorPlugin.getDefault().getUtilities();
	}
}
