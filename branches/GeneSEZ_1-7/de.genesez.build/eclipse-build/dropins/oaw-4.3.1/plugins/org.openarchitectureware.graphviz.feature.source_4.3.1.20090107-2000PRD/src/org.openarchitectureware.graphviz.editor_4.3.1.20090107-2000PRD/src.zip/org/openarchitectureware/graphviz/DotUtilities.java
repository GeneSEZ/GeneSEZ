package org.openarchitectureware.graphviz;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.jface.text.rules.IPartitionTokenScanner;
import org.openarchitectureware.xtext.AbstractLanguageUtilities;
import org.openarchitectureware.xtext.AbstractXtextEditorPlugin;
import org.openarchitectureware.xtext.XtextFile;
import org.openarchitectureware.xtext.parser.IXtextParser;

import org.openarchitectureware.graphviz.parser.XtextParser;

public class DotUtilities extends AbstractLanguageUtilities {

	// enforce eager registration of metamodel
	private static final EPackage EPACKAGE = org.openarchitectureware.graphviz.MetaModelRegistration.getEPackage();
	
	@Override
	protected IXtextParser internalParse(InputStream inputStream) {
		return new XtextParser(inputStream);
	}

	public String getFileExtension() {
		return "dot";
	}

	public EPackage getEPackage() {
		return EPACKAGE;
	}

	List<String> r = new ArrayList<String>();
	{
		r.add("ne");
		r.add("w");
		r.add("nw");
		r.add("--");
		r.add("edge");
		r.add("digraph");
		r.add("graph");
		r.add("sw");
		r.add("node");
		r.add("subgraph");
		r.add("->");
		r.add("n");
		r.add("strict");
		r.add("s");
		r.add("e");
		r.add("se");
	}
	public List<String> allKeywords() {
		return r;
	}

	protected ClassLoader getClassLoader() {
		return this.getClass().getClassLoader();
	}

	public IPartitionTokenScanner getPartitionScanner() {
		return new GeneratedPartitionScanner();
	}

	@Override
	public AbstractXtextEditorPlugin getXtextEditorPlugin() {
		return DotEditorPlugin.getDefault();
	}
	
	@Override
	public String getPackageForExtensions() {
		return "org::openarchitectureware::graphviz";
	}
	
	public XtextFile getXtextFile() {
		return MetaModelRegistration.getXtextFile();
	}
	

}
