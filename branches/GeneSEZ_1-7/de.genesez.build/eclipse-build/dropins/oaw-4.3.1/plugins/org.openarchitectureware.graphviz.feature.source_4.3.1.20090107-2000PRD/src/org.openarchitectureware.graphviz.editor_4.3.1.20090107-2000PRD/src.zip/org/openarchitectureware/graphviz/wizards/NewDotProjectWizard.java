package org.openarchitectureware.graphviz.wizards;

import org.openarchitectureware.xtext.LanguageUtilities;
import org.openarchitectureware.xtext.editor.wizards.AbstractNewProjectWizard;

import org.openarchitectureware.graphviz.DotEditorPlugin;

public class NewDotProjectWizard extends AbstractNewProjectWizard {

	public NewDotProjectWizard() {
		super();
		setLangName("dot");
		setGeneratorProjectName("org.openarchitectureware.graphviz.generator");
		setDslProjectName("org.openarchitectureware.graphviz");
		setFileExtension("dot");
		setPackageName("org/openarchitectureware/graphviz/");
	}
	
	@Override
	protected LanguageUtilities getUtilities() {
		return DotEditorPlugin.getDefault().getUtilities();
	}
}

