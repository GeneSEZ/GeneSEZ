package org.openarchitectureware.util.uml2ecore;

import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;

public class ParamChecker extends AbstractWorkflowComponent {

	private static final String COMPONENT_NAME = "Parameter Checker";

	private boolean resPerTlP;
	private String modelUri;

	/**
	 * Sets if a separate resource will be created for each top level package or
	 * not.
	 * 
	 * @param resourcePerTLP
	 *            If <code>true</code>, a separate resource will be created for
	 *            each top level package, if <code>false</code>, only one single
	 *            resource wil be created.
	 */
	public void setResourcePerToplevelPackage(boolean resourcePerTLP) {
		resPerTlP = resourcePerTLP;
	}

	/**
	 * Sets the URI.
	 * 
	 * @param uri
	 *            the URI
	 */
	public void setUri(String uri) {
		modelUri = uri;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#checkConfiguration(org.openarchitectureware.workflow.issues.Issues)
	 */
	public void checkConfiguration(Issues issues) {
		if (modelUri.endsWith(".ecore")) {
			if (resPerTlP) {
				issues
						.addError(this,
								"if you specify resourcePerToplevelPackage='true', the uri parameter must point to a directory!");
			}
		}
		else {
			if (!resPerTlP) {
				issues
						.addError(this,
								"if you specify resourcePerToplevelPackage='false', the uri parameter must point to a .ecore file!");
			}

		}

	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#invoke(org.openarchitectureware.workflow.WorkflowContext,
	 *      org.openarchitectureware.workflow.monitor.ProgressMonitor,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	public void invoke(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
		// do nothing - this is ok.
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getComponentName()
	 */
	public String getComponentName() {
		return COMPONENT_NAME;
	}
}
