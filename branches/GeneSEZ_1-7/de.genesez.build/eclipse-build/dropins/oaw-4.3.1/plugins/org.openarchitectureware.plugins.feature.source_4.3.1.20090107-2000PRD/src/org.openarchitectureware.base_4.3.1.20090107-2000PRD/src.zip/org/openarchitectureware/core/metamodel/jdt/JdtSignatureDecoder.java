package org.openarchitectureware.core.metamodel.jdt;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.Signature;
import org.openarchitectureware.expression.TypeNameUtil;
import org.openarchitectureware.expression.parser.SyntaxConstants;
import org.openarchitectureware.internal.OawLog;

/**
 * Decodes type signatures to oAW's representation.
 * @author thoms
 * @since 4.3.1
 */
public class JdtSignatureDecoder {
	private static final String IDENTIFIER = "\\w+(?:[\\./]\\w+)*";
	private static Map<String,String> collectiontypesCache = new WeakHashMap<String, String>();  
	
	private static final Pattern SIG_PRIMITIVES = Pattern.compile ("\\A(["
		+ Signature.C_BYTE
		+ Signature.C_CHAR
		+ Signature.C_DOUBLE
		+ Signature.C_FLOAT
		+ Signature.C_INT
		+ Signature.C_LONG
		+ Signature.C_SHORT
		+ Signature.C_VOID
		+ Signature.C_BOOLEAN
		+ "])\\z");
	private static final Pattern SIG_TYPEVARIABLE = Pattern.compile ("\\AT("+IDENTIFIER+");\\z");
	private static final Pattern SIG_ARRAY = Pattern.compile("\\A\\"+Signature.C_ARRAY+"(.+)\\z");
	private static final Pattern SIG_CAPTURE = Pattern.compile("\\A("+Signature.C_CAPTURE+".+)\\z");
	private static final Pattern SIG_CLASSTYPE = Pattern.compile("\\A([LQ])(.+);\\z");
	private static final String OPTIONALTYPEPARAMETERS = "("+Signature.C_GENERIC_START+"(.+)"+Signature.C_GENERIC_END+")?";
	private static final Pattern SIG_TYPEARGUMENTS = Pattern.compile("\\A("+IDENTIFIER+")"+OPTIONALTYPEPARAMETERS+"(?:\\$.+)?\\z");

	public static String decodeTypeSignature (String signature, IType usingType) {
		if (signature == null || signature.length()==0) {
			return signature;
		}
		
		Matcher matcher = null;
		
		matcher = SIG_PRIMITIVES.matcher(signature);
		if (matcher.matches()) {
			return decodePrimitiveSignature(matcher.group(1), usingType);
		}
		matcher = SIG_TYPEVARIABLE.matcher(signature);
		if (matcher.matches()) {
			return decodeIdentifier(matcher.group(1), usingType);
		}
		matcher = SIG_ARRAY.matcher(signature);
		if (matcher.matches()) {
			return decodeArraySignature(matcher.group(1), usingType);
		}
		matcher = SIG_CAPTURE.matcher(signature);
		if (matcher.matches()) {
			return decodeCaptureSignature(matcher.group(1), usingType);
		}
		matcher = SIG_CLASSTYPE.matcher(signature);
		if (matcher.matches()) {
			return decodeClasstypeSignature(matcher.group(2), usingType);
		}
		
		try {
			String[][] result = usingType.resolveType(Signature.toString(signature));
			if (result == null)
				return Signature.toString(signature).replaceAll("\\.", SyntaxConstants.NS_DELIM);
			if (result.length > 0) {
				StringBuffer buff = new StringBuffer();
				for (int i = 0; i < result[0].length; i++) {
					String part = result[0][i];
					buff.append(part);
					if (i < result[0].length - 1) {
						buff.append(".");
					}
				}
				String fqn = buff.toString();
				return fqn.replaceAll("\\.", SyntaxConstants.NS_DELIM);
			}
		}
		catch (JavaModelException e) {
			OawLog.logError(e);
		}
		return null;

	}
	
	private static String decodeIdentifier (String signature, IType usingType) {
		try {
			if (signature != null && usingType != null) {
				String[][] result = usingType.resolveType(signature);
				if (result == null)
					return TypeNameUtil.convertJavaTypeName(signature);
				if (result.length > 0) {
					StringBuffer buff = new StringBuffer();
					for (int i = 0; i < result[0].length; i++) {
						String part = result[0][i];
						buff.append(part);
						if (i < result[0].length - 1) {
							buff.append(".");
						}
					}
					String fqn = buff.toString();
					return TypeNameUtil.convertJavaTypeName(fqn);
				}
			} else if (signature != null) {
				return TypeNameUtil.convertJavaTypeName(signature);
			} else {
				return null;
			}
		}
		catch (JavaModelException e) {
			OawLog.logError(e);
		}
		catch (IllegalArgumentException e) {
			OawLog.logError(e);
		}
		return null;
	}

	private static String decodePrimitiveSignature(String group, IType usingType) {
		assert group.length()==1;
		
		char type = group.charAt(0);
		switch (type) {
			case Signature.C_BYTE: return "Integer";
			case Signature.C_CHAR: return "String";
			case Signature.C_DOUBLE: return "Real";
			case Signature.C_FLOAT: return "Real";
			case Signature.C_INT: return "Integer";
			case Signature.C_LONG: return "Integer";
			case Signature.C_SHORT: return "Integer";
			case Signature.C_VOID: return "Void";
			case Signature.C_BOOLEAN: return "Boolean";
		}
		assert false;
		return null;
	}
	
	private static String decodeArraySignature(String signature, IType usingType) {
		final String innerType = decodeTypeSignature(signature, usingType);
		return "List["+innerType+"]";
	}

	private static String decodeCaptureSignature(String signature, IType usingType) {
		throw new UnsupportedOperationException("cannot handle type captures: "+signature);
	}

	private static String decodeClasstypeSignature(String signature, IType usingType) {
		Matcher matcher = SIG_TYPEARGUMENTS.matcher(signature);
		if (!matcher.matches()) {
			throw new IllegalArgumentException(signature);
		}
		final String identifier = decodeIdentifier(matcher.group(1), usingType);
		String innerType = matcher.group(3);
		if (innerType==null || !isCollectionType(identifier)) {
			return identifier;
		} else {
			String coltype = getCollectionType(identifier);
			innerType = decodeTypeSignature(innerType, usingType);
			StringBuilder result = new StringBuilder();
			result.append(coltype);
			result.append("[");
			result.append(innerType);
			result.append("]");
			return result.toString();
		}
	}
	
	private static boolean isCollectionType (String identifier) {
		return getCollectionType(identifier)!=null;
	}
	
	private static String getCollectionType (String identifier) {
		String coltype = collectiontypesCache.get(identifier);
		if (coltype == null) {
			try {
				Class<?> cls = Class.forName(identifier.replaceAll(SyntaxConstants.NS_DELIM, "."));
				if (List.class.isAssignableFrom(cls)) {
					coltype = "List";
					collectiontypesCache.put(identifier, coltype);
				} else if (Set.class.isAssignableFrom(cls)) {
					coltype = "Set";
					collectiontypesCache.put(identifier, coltype);
				} else if (Collection.class.isAssignableFrom(cls)) {
					coltype = "Collection";
					collectiontypesCache.put(identifier, coltype);
				}				
			} catch (RuntimeException e) {
				coltype = null;
			} catch (ClassNotFoundException e) {
				coltype = null;
			}
		}
		return coltype;
	}
	
}
