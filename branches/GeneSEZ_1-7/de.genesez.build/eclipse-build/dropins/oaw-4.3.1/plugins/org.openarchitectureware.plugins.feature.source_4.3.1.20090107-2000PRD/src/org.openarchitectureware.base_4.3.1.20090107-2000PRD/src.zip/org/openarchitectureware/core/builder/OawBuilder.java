/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.core.builder;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.IJarEntryResource;
import org.eclipse.jdt.core.IJavaElement;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.openarchitectureware.OawPlugin;
import org.openarchitectureware.ResourceContributor;
import org.openarchitectureware.core.IOawProject;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.internal.OawLog;

public class OawBuilder extends IncrementalProjectBuilder {

	class OawDeltaVisitor implements IResourceDeltaVisitor, IResourceVisitor {
		private IProgressMonitor monitor;
		private Set<String> extensions;

		public OawDeltaVisitor(final IProgressMonitor monitor) {
			this.monitor = monitor;
			extensions = new HashSet<String>();
			ResourceContributor[] contributors = OawPlugin.getRegisteredResourceContributors();
			for (ResourceContributor resourceContributor : contributors) {
				extensions.add(resourceContributor.getFileExtension());
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see org.eclipse.core.resources.IResourceDeltaVisitor#visit(org.eclipse.core.resources.IResourceDelta)
		 */
		public boolean visit(final IResourceDelta delta) throws CoreException {
			final IResource resource = delta.getResource();
			if (isOawResource(resource)) {
				switch (delta.getKind()) {
				case IResourceDelta.ADDED:
					// handle added resource
					OawMarkerManager.deleteMarkers((IFile) resource);
					reloadResource((IFile) resource);
					break;
				case IResourceDelta.REMOVED:
					// handle removed resource
					handleRemovement((IFile) resource);
					break;
				case IResourceDelta.CHANGED:
					// handle changed resource
					reloadResource((IFile) resource);
					break;
				}
			}
			monitor.worked(1);
			return true;
		}

		private boolean isOawResource(final IResource resource) {
			return resource instanceof IFile && extensions.contains(((IFile) resource).getFileExtension())
					&& isOnJavaClassPath(resource);
		}

		public boolean visit(final IResource resource) {
			if (isOawResource(resource)) {
				reloadResource((IFile) resource);
			}
			monitor.worked(1);
			return true;
		}

	}

	boolean isOnJavaClassPath(final IResource resource) {
		final IJavaProject jp = JavaCore.create(resource.getProject());
		if (jp != null)
			return jp.isOnClasspath(resource);
		return false;
	}

	public static final String getBUILDER_ID() {
		return OawPlugin.getId() + ".oawBuilder";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.eclipse.core.internal.events.InternalBuilder#build(int,
	 *      java.util.Map, org.eclipse.core.runtime.IProgressMonitor)
	 */
	@SuppressWarnings("unchecked")
	@Override
	protected IProject[] build(final int kind, final Map args, final IProgressMonitor monitor) throws CoreException {
		try {
			if (kind == FULL_BUILD) {
				fullBuild(monitor);
			} else {
				final IResourceDelta delta = getDelta(getProject());
				if (delta == null) {
					fullBuild(monitor);
				} else {
					incrementalBuild(delta, monitor);
				}
			}
		} catch (final Throwable e) {
			e.printStackTrace();
		}
		IOawProject p = OawPlugin.getOawModelManager().findProject(getProject());
		p.analyze(monitor);
		return null;
	}

	void reloadResource(final IFile resource) {
		if (resource.exists()) {
			final IOawProject project = OawPlugin.getOawModelManager().findProject(resource);
			if (project != null) {
				final IOawResource r = project.findOawResource(resource);
				if (r != null) {
					if (r.refresh())
						resource.getLocalTimeStamp();
				}
			}
		}
	}

	public void handleRemovement(final IFile resource) {
		final IOawProject project = OawPlugin.getOawModelManager().findProject(resource);
		if (project != null) {
			project.unregisterOawResource(project.findOawResource(resource));
		} else {
			OawLog.logInfo("No oaw project found for " + resource.getProject().getName());
		}
	}

	protected void fullBuild(final IProgressMonitor monitor) throws CoreException {
		final IOawProject project = OawPlugin.getOawModelManager().findProject(getProject().getFullPath());
		if (project != null) {
			getProject().accept(new OawDeltaVisitor(monitor));
			IJavaProject jp = JavaCore.create(getProject());
			IPackageFragmentRoot[] roots = jp.getPackageFragmentRoots();
			Set<String> extensions = new HashSet<String>();
			ResourceContributor[] contributors = OawPlugin.getRegisteredResourceContributors();
			for (ResourceContributor resourceContributor : contributors) {
				extensions.add(resourceContributor.getFileExtension());
			}
			for (int i = 0; i < roots.length; i++) {
				IPackageFragmentRoot root = roots[i];
				if (!root.isArchive() && !root.isExternal())
					continue;

				boolean closeRoot = false;
				
				try {
					if (!root.isOpen()) {
						root.open(monitor);
						closeRoot = true;
					}

					processExternalResources(project, "", root.getNonJavaResources(), extensions);
					for (IJavaElement element : root.getChildren()) {
						if (element instanceof IPackageFragment) {
							IPackageFragment fragment = (IPackageFragment)element;
							String name = fragment.getElementName().replaceAll("\\.", "::");
							if (name.length() > 0)
								name += "::";
							processExternalResources(project, name, fragment.getNonJavaResources(), extensions);
						}
					}
				} finally {
					if (closeRoot)
						root.close();
				}
			}
		} else {
			OawLog.logInfo("Couldn't create oawproject for project " + getProject().getName());
		}
	}

	private void processExternalResources(IOawProject project, String path, Object[] resources, Set<String> extensions) {
		for (Object resource : resources) {
			if (!(resource instanceof IJarEntryResource))
				continue;

			IJarEntryResource entry = (IJarEntryResource)resource;
			if (!entry.isFile())
				continue;

			String name = entry.getName();
			for (String ext : extensions) {
				if (name.endsWith(ext) && (name.length() > (ext.length() + 1))) {
					char dot = name.charAt(name.length() - ext.length() - 1);
					if (dot == '.') {
						String fqn = path + name.substring(0, name.length() - ext.length() - 1);
						project.loadOawResource(fqn, ext, true);
						break;
					}
				}
			}
		}
	}
	
	protected void incrementalBuild(final IResourceDelta delta, final IProgressMonitor monitor) throws CoreException {
		final OawDeltaVisitor visitor = new OawDeltaVisitor(monitor);
		delta.accept(visitor);
	}
}
