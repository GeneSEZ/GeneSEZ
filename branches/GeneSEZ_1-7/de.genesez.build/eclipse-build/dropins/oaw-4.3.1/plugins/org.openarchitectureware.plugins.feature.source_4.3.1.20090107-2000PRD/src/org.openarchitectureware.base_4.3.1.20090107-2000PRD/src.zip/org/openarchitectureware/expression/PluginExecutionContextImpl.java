/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.expression;

import java.util.Map;

import org.openarchitectureware.core.IOawProject;
import org.openarchitectureware.core.PluginExecutionContext;

public class PluginExecutionContextImpl extends ExecutionContextImpl implements PluginExecutionContext {
    private final IOawProject project;

    public PluginExecutionContextImpl(final IOawProject xp, final TypeSystemImpl ts) {
        super(new PluginResourceManager (xp), ts, null);
        project = xp;
    }

    protected PluginExecutionContextImpl (ResourceManager resourceManager, Resource currentResource, TypeSystemImpl typeSystem, Map<String, Variable> vars, 
            Map<String, Variable> globalVars, IOawProject xp) {
        super (resourceManager, currentResource, typeSystem, vars, globalVars, null, null, null, null,null, null);
        project = xp;
    }
    
    @Override
    public PluginExecutionContextImpl cloneContext() {
        final PluginExecutionContextImpl result = new PluginExecutionContextImpl (resourceManager, currentResource(), typeSystem, getVisibleVariables(), getGlobalVariables(), project);
        return result;
    }


    public static  class PluginResourceManager implements ResourceManager {
        private IOawProject project;

        public PluginResourceManager(final IOawProject project) {
            this.project = project;
        }

        public Resource loadResource(final String fullyQualifiedName, final String extension) {
            return project.findOawResource(fullyQualifiedName,extension);
        }

        public void setFileEncoding(final String fileEncoding) {
        }

        public void registerParser(final String template_extension, final ResourceParser parser) {
        }
    }

}
