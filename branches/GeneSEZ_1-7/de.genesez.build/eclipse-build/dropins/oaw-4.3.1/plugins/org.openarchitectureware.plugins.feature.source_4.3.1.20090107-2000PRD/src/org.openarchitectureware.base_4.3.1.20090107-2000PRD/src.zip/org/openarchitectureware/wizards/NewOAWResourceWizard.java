/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.wizards;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.eclipse.ui.wizards.newresource.BasicNewResourceWizard;

public abstract class NewOAWResourceWizard extends BasicNewResourceWizard {

	private NewOAWResourcePage mainPage;

	private final String extension;

	private final String title;

	private final String description;

	private final String initial;

	private final String initialContents;

	private String charSet;

	/**
	 * Creates a wizard for creating a new file resource in the workspace.
	 */
	public NewOAWResourceWizard(final String initial, final String extension, final String title,
			final String description, final String initialContents) {
		super();
		this.initial = initial;
		this.extension = extension;
		this.title = title;
		this.description = description;
		this.initialContents = initialContents;
	}

	public NewOAWResourceWizard(final String initial, final String extension, final String title,
			final String description, final String initialContents, final String charSet) {
		this(initial, extension, title, description, initialContents);
		this.charSet = charSet;
	}

	/*
	 * (non-Javadoc) Method declared on IWizard.
	 */
	@Override
	public void addPages() {
		super.addPages();
		mainPage = new NewOAWResourcePage("newFilePage1", getSelection(), initial, extension, initialContents, charSet);//$NON-NLS-1$
		mainPage.setTitle(title);
		mainPage.setDescription(description);
		addPage(mainPage);
	}

	/*
	 * (non-Javadoc) Method declared on IWorkbenchWizard.
	 */

	@Override
	public void init(final IWorkbench workbench, final IStructuredSelection currentSelection) {
		super.init(workbench, currentSelection);
		setWindowTitle("New File");
		setNeedsProgressMonitor(true);
	}

	/*
	 * (non-Javadoc) Method declared on BasicNewResourceWizard.
	 */
	@Override
	protected void initializeDefaultPageImageDescriptor() {
		final ImageDescriptor desc = AbstractUIPlugin.imageDescriptorFromPlugin("org.eclipse.ui.ide",
				"$nl$/icons/full/wizban/newfile_wiz.png");
		setDefaultPageImageDescriptor(desc);
	}

	@Override
	public boolean canFinish() {
		return mainPage.getFileName().endsWith("." + extension);
	}

	/*
	 * (non-Javadoc) Method declared on IWizard.
	 */
	@Override
	public boolean performFinish() {
		final IFile file = mainPage.createNewFile();
		if (file == null)
			return false;

		selectAndReveal(file);
		// Open editor on new file.
		EclipseHelper.openFileToEdit(getShell(), file);
		return true;
	}
}
