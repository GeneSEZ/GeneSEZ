/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.wizards;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.dialogs.WizardNewFileCreationPage;
import org.openarchitectureware.internal.OawLog;

public class NewOAWResourcePage extends WizardNewFileCreationPage {

	private final String extension;
	private String initialContents;
	private String charSet;

	public NewOAWResourcePage(final String pageName, final IStructuredSelection selection, final String initial,
			final String extension, final String initialContents) {
		super(pageName, selection);
		setFileName(initial);
		this.extension = extension;
		this.initialContents = initialContents;
	}

	public NewOAWResourcePage(final String pageName, final IStructuredSelection selection, final String initial,
			final String extension, final String initialContents, final String charSet) {
		this(pageName, selection, initial, extension, initialContents);
		this.charSet = charSet;
	}

	@Override
	public IFile createNewFile() {
		try {
			final IFile file = super.createNewFile();
			if (file != null && charSet != null) {
				file.setCharset(charSet, new NullProgressMonitor());
			}
			return file;
		}
		catch (final CoreException e) {
			OawLog.logError("Core exception", e);
			return null;
		}
	}

	@Override
	public String getErrorMessage() {
		if (!getFileName().endsWith("." + extension))
			return "extension must be ." + extension;
		return null;
	}

	@Override
	protected InputStream getInitialContents() {
		if (initialContents == null) {
			initialContents = "";
		}
		return new ByteArrayInputStream(initialContents.getBytes());
	}
}
