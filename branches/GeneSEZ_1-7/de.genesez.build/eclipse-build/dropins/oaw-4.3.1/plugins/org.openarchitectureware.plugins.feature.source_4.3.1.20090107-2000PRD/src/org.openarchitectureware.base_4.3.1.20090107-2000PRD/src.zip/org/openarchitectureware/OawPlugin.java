/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.openarchitectureware.core.IOawModelManager;
import org.openarchitectureware.core.IOawProject;
import org.openarchitectureware.core.builder.OawNature;
import org.openarchitectureware.core.internal.OawModelManager;
import org.openarchitectureware.core.metamodel.MetamodelContributorRegistry;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.ExecutionContextImpl;
import org.openarchitectureware.expression.PluginExecutionContextImpl;
import org.openarchitectureware.expression.TypeSystemImpl;
import org.openarchitectureware.internal.OawLog;
import org.openarchitectureware.type.MetaModel;
import org.openarchitectureware.xtend.XtendFile;
import org.osgi.framework.BundleContext;

/**
 * The main plugin class
 */
public class OawPlugin extends AbstractUIPlugin {

	private static final String RESOURCE_CONTRIBUTOR_ID = "org.openarchitectureware.base.resourceContributor";

	public static final String PLUGIN_ID = "org.openarchitectureware.base";

	// The shared instance.
	private static OawPlugin plugin;

	private static HashMap<String, ResourceContributor> contributors;

	private IOawModelManager oawModelManager;

	private final IPropertyChangeListener listener = new IPropertyChangeListener() {

		public void propertyChange(PropertyChangeEvent event) {
			Job job = new Job("Analyzing workspace...") {

				@Override
				protected IStatus run(IProgressMonitor monitor) {
					try {
						new WorkspaceModifyOperation() {
							@Override
							protected void execute(IProgressMonitor monitor) throws CoreException,
									java.lang.reflect.InvocationTargetException, InterruptedException {
								OawPlugin.getOawModelManager().analyze(monitor);
							}
						}.run(monitor);
					}
					catch (InvocationTargetException e) {
						OawLog.logError(e);
					}
					catch (InterruptedException e) {
						OawLog.logError(e);
					}
					return Status.OK_STATUS;
				}

			};
			job.schedule();
		}
	};

	/**
	 * The constructor.
	 */
	public OawPlugin() {
		plugin = this;
		oawModelManager = new OawModelManager();
	}

	/**
	 * Returns the shared instance.
	 */
	public static OawPlugin getDefault() {
		return plugin;
	}

	public static ExecutionContext getExecutionContext(final IJavaProject project) {
		final IOawProject xp = OawPlugin.getOawModelManager().findProject(project.getPath());
		final ExecutionContextImpl ctx = new PluginExecutionContextImpl(xp, new TypeSystemImpl());

		final List<? extends MetamodelContributor> contr = MetamodelContributorRegistry
				.getActiveMetamodelContributors(project);
		for (MetamodelContributor contributor : contr) {
			final MetaModel[] metamodels = contributor.getMetamodels(project, ctx);
			for (int i = 0; i < metamodels.length; i++) {
				ctx.registerMetaModel(metamodels[i]);
			}
		}
		return ctx;
	}

	public static String getId() {
		return getDefault().getBundle().getSymbolicName();
	}

	/**
	 * Returns an image descriptor for the image file at the given plug-in
	 * relative path.
	 * 
	 * @param path
	 *            the path
	 * @return the image descriptor
	 */
	public static ImageDescriptor getImageDescriptor(final String path) {
		return AbstractUIPlugin.imageDescriptorFromPlugin(getId(), path);
	}

	public static final String getNatureId() {
		return OawNature.NATURE_ID;
	}

	public static IOawModelManager getOawModelManager() {
		return getDefault().oawModelManager;
	}

	public static ResourceContributor getRegisteredResourceContributorFor(String fileExtension) {
		if (contributors == null) {
			contributors = new HashMap<String, ResourceContributor>();
			for (ResourceContributor contr : getRegisteredResourceContributors()) {
				contributors.put(contr.getFileExtension(), contr);
			}
		}

		return contributors.get(fileExtension);
	}

	public static ResourceContributor[] getRegisteredResourceContributors() {
		final IExtensionRegistry registry = Platform.getExtensionRegistry();
		final IExtensionPoint point = registry.getExtensionPoint(OawPlugin.RESOURCE_CONTRIBUTOR_ID);
		final Set<ResourceContributor> contrs = new HashSet<ResourceContributor>();
		if (point != null) {
			final IExtension[] extensions = point.getExtensions();
			for (int i = 0; i < extensions.length; i++) {
				final IExtension extension = extensions[i];
				final IConfigurationElement[] configs = extension.getConfigurationElements();
				for (int j = 0; j < configs.length; j++) {
					final IConfigurationElement element = configs[j];
					try {
						contrs.add((ResourceContributor) element.createExecutableExtension("class"));
					}
					catch (final CoreException e) {
						OawLog.logError(e);
					}
				}
			}
		}
		return contrs.toArray(new ResourceContributor[contrs.size()]);
	}

	/**
	 * Returns the standard display to be used. The method first checks, if the
	 * thread calling this method has an associated display. If so, this display
	 * is returned. Otherwise the method returns the default display.
	 */
	public static Display getStandardDisplay() {
		Display display = Display.getCurrent();
		if (display == null) {
			display = Display.getDefault();
		}
		return display;
	}

	public final static boolean isXtendFile(final Object object) {
		if (object instanceof IFile)
			return XtendFile.FILE_EXTENSION.equals(((IFile) object).getFileExtension());
		return false;
	}

	/**
	 * This method is called upon plug-in activation
	 */
	@Override
	public void start(final BundleContext context) throws Exception {
		super.start(context);
		getPreferenceStore().addPropertyChangeListener(listener);

		// pre-initalize classpaths to avoid deadlock with ProjectAnalyzers and
		// EmfToolsPlugin
		IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
		for (IProject project : projects) {
			if (project.isOpen() && project.isNatureEnabled("org.eclipse.jdt.core.javanature")) {
				IJavaProject javaProject = JavaCore.create(project);
				javaProject.getResolvedClasspath(true);
			}
		}

		// // initialize mm contributors
		// Map<String, Contributor> registeredMetamodelContributors =
		// MetamodelContributorRegistry.getRegisteredMetamodelContributors();
		// for (Contributor c : registeredMetamodelContributors.values()) {
		// c.getMetaModelContributor();
		// }
	}

	/**
	 * This method is called when the plug-in is stopped
	 */
	@Override
	public void stop(final BundleContext context) throws Exception {
		super.stop(context);
		getPreferenceStore().removePropertyChangeListener(listener);
		plugin = null;
	}
}
