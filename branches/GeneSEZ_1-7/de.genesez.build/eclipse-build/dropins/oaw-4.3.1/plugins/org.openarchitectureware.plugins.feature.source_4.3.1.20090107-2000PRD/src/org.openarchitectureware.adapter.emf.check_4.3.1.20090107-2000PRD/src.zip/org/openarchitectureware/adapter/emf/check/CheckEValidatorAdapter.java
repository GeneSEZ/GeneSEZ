/*******************************************************************************
 * <copyright>
 * Copyright (c) 2008 itemis AG and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * committers of openArchitectureWare - initial API and implementation
 * </copyright>
 *******************************************************************************/
package org.openarchitectureware.adapter.emf.check;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EValidator;
import org.openarchitectureware.check.CheckUtils;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.ExecutionContextImpl;
import org.openarchitectureware.expression.ResourceManager;
import org.openarchitectureware.expression.ResourceManagerDefaultImpl;
import org.openarchitectureware.expression.TypeSystemImpl;
import org.openarchitectureware.type.emf.EmfMetaModel;
import org.openarchitectureware.workflow.ConfigurationException;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.issues.IssuesImpl;
import org.openarchitectureware.xtend.ast.ExtensionFile;

/**
 * An implementation of {@link org.eclipse.emf.ecore.EValidator} that executes
 * oAW checks. Further EValidators can be nested.
 * 
 * Check files can be added with reparse option. If true, the check files are
 * reparse on each validation.
 * 
 * @author Jan K�hnlein
 */
public class CheckEValidatorAdapter implements EValidator {

	private List<CheckFileWithContext> _checkFiles;

	private EValidator _nestedValidator;

	private EPackage _ePackage;
	
	private ResourceManager _externalResourceManager;

	public CheckEValidatorAdapter(EPackage ePackage) {
		_ePackage = ePackage;
		_checkFiles = new ArrayList<CheckFileWithContext>();
	}

	public CheckEValidatorAdapter(EPackage ePackage,
			EValidator existingValidator) {
		this(ePackage);
		if (existingValidator != null) {
			_nestedValidator = existingValidator;
		}
	}

	public void addCheckFile(CheckFileWithContext checkFile) {
		_checkFiles.add(checkFile);
	}

	/**
	 * Adds a check file.
	 * 
	 * @param checkFileName
	 * @param isReparseOnValidation
	 *            if true, the check file is reparsed on each validation.
	 */
	public void addCheckFile(String checkFileName, boolean isReparseOnValidation) {
		CheckFileWithContext checkFileWithContext = new CheckFileWithContext(
				checkFileName);
		final ExtensionFile parsedCheckFile = (ExtensionFile) new ResourceManagerDefaultImpl()
				.loadResource(checkFileWithContext.getFileName(),
						CheckUtils.FILE_EXTENSION);
		if (parsedCheckFile == null) {
			throw new ConfigurationException("Cannot find check file "
					+ checkFileName);
		}
		_checkFiles.add(checkFileWithContext);
	}

	public boolean validate(EObject eObject, DiagnosticChain diagnostics,
			Map<Object, Object> context) {
		return validate(eObject.eClass(), eObject, diagnostics, context);
	}

	public boolean validate(EClass eClass, EObject eObject,
			DiagnosticChain diagnostics, Map<Object, Object> context) {
		List<EObject> allElements = Collections.singletonList(eObject);
		boolean isValid = runOawCheck(diagnostics, allElements);
		if (_nestedValidator != null) {
			isValid &= _nestedValidator.validate(eClass, eObject, diagnostics,
					context);
		}
		return isValid;
	}

	public boolean validate(EDataType dataType, Object value,
			DiagnosticChain diagnostics, Map<Object, Object> context) {
		List<?> allElements = Collections.singletonList(dataType);
		boolean isValid = runOawCheck(diagnostics, allElements);
		if (_nestedValidator != null) {
			isValid &= _nestedValidator.validate(dataType, value, diagnostics,
					context);
		}
		return isValid;
	}

	
	public void setExternalResourceManager(ResourceManager externalResourceManager) {
		_externalResourceManager = externalResourceManager;
	}
	
	private ResourceManager getResourceManager() {
		if(_externalResourceManager != null) {
			return _externalResourceManager;
		}
		return new ResourceManagerDefaultImpl();
	}

	private ExecutionContext createExecutionContext(
			CheckFileWithContext checkFile, ResourceManager resourceManager) {
		final Set<EPackage> allEPackages = new HashSet<EPackage>();
		allEPackages.add(_ePackage);
		for (String nsURI : checkFile.getImportedEPackageNsUris()) {
			try {
				EPackage importedEPackage = EPackage.Registry.INSTANCE
						.getEPackage(nsURI);
				if (importedEPackage != null) {
					allEPackages.add(importedEPackage);
				}
			} catch (Exception exc) {
				Log.logError(exc);
			}
		}
		TypeSystemImpl typeSystem = new TypeSystemImpl();
		typeSystem.registerMetaModel(new EmfMetaModel() {
			private EPackage[] _allEPackages = allEPackages
					.toArray(new EPackage[allEPackages.size()]);

			@Override
			protected EPackage[] allPackages() {
				return _allEPackages;
			}
		});
		ExecutionContext executionContext = new ExecutionContextImpl(
				resourceManager, typeSystem, null);
		return executionContext;
	}

	private boolean runOawCheck(DiagnosticChain diagnostics, List<?> allElements) {
		boolean isValid = true;
		for (CheckFileWithContext checkFile : _checkFiles) {
			Issues issues = new IssuesImpl();
			ResourceManager resourceManager = getResourceManager();
			ExtensionFile parsedCheckFile = (ExtensionFile) resourceManager
					.loadResource(checkFile.getFileName(),
							CheckUtils.FILE_EXTENSION);
			ExecutionContext executionContext = createExecutionContext(checkFile, resourceManager);
			runOawCheck(parsedCheckFile, allElements, diagnostics,
					executionContext);
			isValid &= issues.hasErrors();
		}
		return isValid;
	}

	private Issues runOawCheck(ExtensionFile parsedCheckFile,
			List<?> allElements, DiagnosticChain diagnostics,
			ExecutionContext executionContext) {
		Issues issues = new IssuesImpl();
		parsedCheckFile.check(executionContext, allElements, issues, false);
		IssuesDiagnosticAdapter.addDiagnosticFromIssues(diagnostics, issues);
		return issues;
	}

}
