/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.core.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IStorage;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.core.runtime.jobs.Job;
import org.eclipse.jdt.core.ElementChangedEvent;
import org.eclipse.jdt.core.IElementChangedListener;
import org.eclipse.jdt.core.IJavaElementDelta;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.openarchitectureware.OawPlugin;
import org.openarchitectureware.ResourceContributor;
import org.openarchitectureware.core.IOawProject;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.core.builder.OawBuilder;
import org.openarchitectureware.core.builder.OawMarkerManager;
import org.openarchitectureware.core.builder.OawNature;
import org.openarchitectureware.internal.OawLog;

public class OawProject implements IOawProject {

	private static final Set<IJavaProject> initializing = new HashSet<IJavaProject>();

	final IJavaProject project;

	public OawProject(final IJavaProject resource) {
		project = resource;
		try {
			final IProject[] ps = project.getProject().getReferencedProjects();
			for (int i = 0; i < ps.length; i++) {
				if (initializing.add(project)) {
					try {
						OawPlugin.getOawModelManager().findProject(ps[i]);
					} finally {
						initializing.remove(project);
					}
				}
			}
		} catch (final CoreException e) {
			OawLog.logError(e);
		}
		JavaCore.addElementChangedListener(new IElementChangedListener() {

			public void elementChanged(ElementChangedEvent event) {
				if (fromJar.isEmpty())
					return;
				if (containsRemovedClassPathEntry(event.getDelta()
						.getAffectedChildren()))
					removeResourcesFromJar();
			}
		}, ElementChangedEvent.POST_CHANGE);

		Job j = new Job("Initializing " + project.getElementName()) {
			@Override
			protected IStatus run(final IProgressMonitor monitor) {
				try {
					final IProject p = project.getProject();
					if (p.isAccessible()
							&& p.isNatureEnabled(OawNature.NATURE_ID)) {
						p.build(IncrementalProjectBuilder.CLEAN_BUILD,
								OawBuilder.getBUILDER_ID(),
								new HashMap<Object, Object>(), monitor);
					}
				} catch (final CoreException e) {
					OawLog.logError(e);
				}
				return Status.OK_STATUS;
			}
		};
		j.setRule(project.getResource().getWorkspace().getRuleFactory()
				.buildRule());
		j.schedule();
	}

	protected boolean containsRemovedClassPathEntry(
			IJavaElementDelta[] affectedChildren) {
		for (int i = 0; i < affectedChildren.length; i++) {
			IJavaElementDelta delta = affectedChildren[i];
			if ((delta.getFlags() & IJavaElementDelta.F_REMOVED_FROM_CLASSPATH) != 0) {
				return true;
			}
			if (containsRemovedClassPathEntry(delta.getAffectedChildren())) {
				return true;
			}
		}
		return false;
	}

	protected void removeResourcesFromJar() {
		for (OawResourceID id : fromJar) {
			resources.remove(id);
		}
	}

	private final Map<OawResourceID, IOawResource> resources = new HashMap<OawResourceID, IOawResource>();

	private Set<OawResourceID> fromJar = new HashSet<OawResourceID>();

	/**
	 * @see IOawProject#getRegisteredResources()
	 */
	public IOawResource[] getRegisteredResources() {
		return resources.values().toArray(new IOawResource[resources.size()]);
	}

	/**
	 * @see IOawProject#getAllRegisteredResources()
	 */
	public IOawResource[] getAllRegisteredResources() {
		Set<IOawResource> result = new HashSet<IOawResource>();
		result.addAll(Arrays.asList(getRegisteredResources()));
		for (IOawProject p : getAllReferencedProjects()) {
			result.addAll(Arrays.asList(p.getRegisteredResources()));
		}
		return result.toArray(new IOawResource[resources.size()]);
	}

	/**
	 * @see IOawProject#getReferencedProjects()
	 */
	public IOawProject[] getReferencedProjects() {
		Set<IOawProject> result = new HashSet<IOawProject>();
		try {
			IProject[] projects = getProject().getProject()
					.getReferencedProjects();
			for (IProject project : projects) {
				IOawProject p = OawPlugin.getOawModelManager().findProject(
						project);
				if (p != null)
					result.add(p);
			}
		} catch (CoreException e) {
			OawLog.logError(e);
		}
		return result.toArray(new IOawProject[result.size()]);
	}
	
	/**
	 * @see IOawProject#getAllReferencedProjects()
	 */
	public IOawProject[] getAllReferencedProjects() {
		Set<IOawProject> result = new HashSet<IOawProject>();
		IOawProject[] projects = getReferencedProjects();
		result.addAll(Arrays.asList(projects));
		for (IOawProject project : projects) {
			result.addAll(Arrays.asList(project.getAllReferencedProjects()));
		}
		return result.toArray(new IOawProject[result.size()]);
	}

	public IJavaProject getProject() {
		return project;
	}

	/**
	 * @see IOawProject#unregisterOawResource(IOawResource)
	 */
	public void unregisterOawResource(final IOawResource res) {
		if (res != null) {
			if (res.getUnderlyingStorage() instanceof IFile)
				OawMarkerManager.deleteMarkers((IFile) res
						.getUnderlyingStorage());
			resources.remove(new OawResourceID(res.getFullyQualifiedName(), res
					.getFileExtension()));
		}
	}

	/**
	 * @see IOawProject#findOawResource(String, String)
	 */
	public IOawResource findOawResource(final String fqn, final String extension) {
		assert (fqn != null);
		assert (extension != null);
		if (OawPlugin.getRegisteredResourceContributorFor(extension)==null)
			return null;
		// for performance reasons ask the cache first
		IOawResource res = findCachedOawResource(fqn, extension);
		if (res != null)
			return res;
		// ask to load the resource without looking into jars
		res = loadOawResource(fqn, extension, false);
		if (res != null)
			return res;
		// look into jars
		return loadOawResource(fqn, extension, true);
	}

	/**
	 * 
	 * @param fqn
	 *            Full qualified name of the searched resource
	 * @param extension
	 * @param visitedProjects
	 *            For build path cycle detection
	 * @return The cached resource or <code>null</code> if the resource is not
	 *         known
	 */
	private IOawResource findCachedOawResource(String fqn, String extension) {
		IOawResource res = resources.get(new OawResourceID(fqn, extension));
		if (res == null)
			return null;
		
		// eliminate stale resources
		IResource workspaceResource = ResourcesPlugin.getWorkspace().getRoot().findMember((res.getUnderlyingStorage().getFullPath()));
		if (workspaceResource != null && workspaceResource.exists())
			return res;
		else {			
			resources.remove(new OawResourceID(fqn, extension));
			return null;
		}
	}

	/**
	 * @see IOawProject#loadOawResource(String, String, boolean)
	 */
	public IOawResource loadOawResource(final String fqn,
			final String extension, boolean searchJars) {
		Set<String> visited = new HashSet<String>();
		return loadOawResource2(fqn, extension, searchJars, visited);
	}

	private IOawResource loadOawResource2(final String fqn,
			final String extension, boolean searchJars, Set<String> visited) {
		assert (fqn != null);
		assert (extension != null);
		
		if (visited.contains(project.getProject().getName()))
			return null;
		visited.add(project.getProject().getName());
		
		// search the resource using JDT
		IStorage storage = JDTUtil.findStorage(project, new OawResourceID(fqn,
				extension), searchJars);
		
		// Found in this project?
		if (storage != null && (searchJars || (storage instanceof IFile))) {
			IOawResource result = null;
			// get the file extension and find the appropriate ResourceContributor for this
			// kind of resource (Xpand/Xtend)
			String fileExtension = storage.getName().substring(
					storage.getName().lastIndexOf(".") + 1);
			final ResourceContributor contr = OawPlugin
					.getRegisteredResourceContributorFor(fileExtension);
			
			// we have a registered contributor for this resource
			if (contr != null) {
				// load the resource using the ResourceContributor
				result = contr.create(storage, fqn);
				if (result != null) {
					// cache this resource
					resources.put(new OawResourceID(fqn, extension), result);
					// remember, because we need to clean the cache, if
					// a jar has been removed
					if (!(storage instanceof IFile)) {
						fromJar.add(new OawResourceID(fqn, extension));
					}
					return result;
				}
			}
		}
		
		// if reached here then the resource was not found in the current project. 
		// Now we perform the same search on all referenced projects.
		try {
			final IProject[] p = project.getProject().getReferencedProjects();
			for (int i = 0; i < p.length; i++) {
				IProject project = p[i];
				final OawProject oawp = (OawProject) OawPlugin
						.getOawModelManager().findProject(project);
				if (oawp != null) {
					IOawResource result;

					// for performance reasons ask the cache first
					result = oawp.findCachedOawResource(fqn, extension);
					if (result != null)
						return result;

					result = oawp.loadOawResource2(fqn, extension, searchJars, visited);
					if (result != null)
						return result;
				}
			}
		} catch (final CoreException e) {
			OawLog.logError(e);
		}
		return null;
	}

	/**
	 * @see IOawProject#findOawResource(IPath, boolean)
	 */
	public IOawResource findOawResource(final IStorage file) {
		if (file == null)
			return null;
		OawResourceID id = JDTUtil.findOawResourceID(project, file);
		if (id == null) {
			return null;
		}
		return findOawResource(id.name, id.extension);
	}

	/**
	 * @see IOawProject#analyze(IProgressMonitor)
	 */
	public void analyze(final IProgressMonitor monitor) {
		for (final Iterator<IOawResource> iter = new ArrayList<IOawResource>(resources.values()).iterator(); iter
				.hasNext();) {
			if (monitor.isCanceled())
				return;
			IOawResource resource = iter.next();
			synchronized (resource) {
				resource.analyze();
			}
			monitor.worked(1);
		}
	}

	/**
	 * Returns the name of the underlying project.
	 */
	public String toString() {
		return project.getPath().toString();
	}

}
