package org.openarchitectureware.core.internal;

import java.util.regex.Pattern;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IStorage;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.Path;
import org.eclipse.jdt.core.IJarEntryResource;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IPackageFragmentRoot;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.openarchitectureware.internal.OawLog;

public class JDTUtil {

	private static final Pattern patternNamespace = Pattern.compile("::");
	private static final Pattern patternSlash = Pattern.compile("/");

	/**
	 * find the path for the oaw name space and extension
	 * 
	 * @param project
	 *            - the javaproject
	 * @param oawns
	 *            - oaw name space (i.e. 'my::xtend::File')
	 * @param ext
	 *            - file extension (i.e. 'ext')
	 * @return
	 */
	public static IStorage findStorage(final IJavaProject project, final OawResourceID id, final boolean searchJars) {
		final IPath p = path(id);
		try {
			final IPackageFragmentRoot[] roots = project.getPackageFragmentRoots();
			for (final IPackageFragmentRoot root : roots) {
				if (!root.isArchive() && !root.isExternal()) {
					final IResource res = root.getUnderlyingResource();

					IResource r = null;
					if (res != null) {
						r = project.getProject().findMember(res.getProjectRelativePath().append(p));
					}
					if (r instanceof IFile)
						return (IFile) r;
				}
				else if (searchJars) {
					final IStorage storage = loadFromJar(id, root);
					if (storage != null)
						return storage;
				}
			}
		}
		catch (final JavaModelException e) {
			OawLog.logInfo(e);
		}
		return null;
	}

	public static IStorage loadFromJar(final OawResourceID id, final IPackageFragmentRoot root)
			throws JavaModelException {

		String path;
		String fileName;

		{
			String[] elements = id.toString().split("::");

			StringBuilder pathBuilder = new StringBuilder();
			for (int i = 0; i < (elements.length - 1); ++i) {
				if (i > 0)
					pathBuilder.append(".");
				pathBuilder.append(elements[i]);
			}
			path = pathBuilder.toString();
			
			fileName = elements[elements.length - 1]; 
		}

		Object[] resources;

		if (path.length() > 0) {
			IPackageFragment fragment = root.getPackageFragment(path);
			if ((fragment == null) || !fragment.exists())
				return null;
			resources = fragment.getNonJavaResources();
		} else {
			resources = root.getNonJavaResources();
		}

		for (Object resource : resources) {
			if (!(resource instanceof IJarEntryResource))
				continue;

			IJarEntryResource entry = (IJarEntryResource)resource;
			if (!entry.isFile())
				continue;

			if (entry.getName().equals(fileName))
				return entry;
		}
		return null;
	}

	public static OawResourceID findOawResourceID(final IJavaProject project, final IStorage file) {
		if (file == null)
			return null;
		try {
			final IPackageFragmentRoot[] roots = project.getPackageFragmentRoots();
			for (final IPackageFragmentRoot root : roots) {
				if (root.getPath().isPrefixOf(file.getFullPath())) {
					final IPath shortOne = file.getFullPath().removeFirstSegments(root.getPath().segmentCount())
							.setDevice(null);
					String ns = shortOne.removeFileExtension().toString();
					ns = patternSlash.matcher(ns).replaceAll("::");
					return new OawResourceID(ns, shortOne.getFileExtension());
				}
			}
		}
		catch (final JavaModelException e1) {
			OawLog.logInfo(e1);
		}
		return null;
	}

	public static IJavaProject getJProject(final IStorage s) {
		if (s instanceof IFile)
			return JavaCore.create(((IFile) s).getProject());
		else {
			final IProject[] projects = ResourcesPlugin.getWorkspace().getRoot().getProjects();
			for (final IProject project : projects) {
				final IJavaProject p = JavaCore.create(project);
				if (p.exists()) {
					IPackageFragmentRoot[] roots;
					try {
						roots = p.getPackageFragmentRoots();
						for (final IPackageFragmentRoot root : roots) {
							if (root.getPath().isPrefixOf(s.getFullPath()))
								return p;
						}
					}
					catch (final JavaModelException e) {
						OawLog.logError(e);
					}
				}
			}
		}
		return null;
	}

	private static IPath path(final OawResourceID id) {
		return new Path(patternNamespace.matcher(id.name).replaceAll("/") + "." + id.extension);
	}

	public static String getQualifiedName(final IStorage source) {
		final OawResourceID id = findOawResourceID(getJProject(source), source);
		if (id != null)
			return id.name;
		return null;
	}

}
