/*******************************************************************************
 * Copyright (c) 2005 - 2007 committers of openArchitectureWare and others. All
 * rights reserved. This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License v1.0 which
 * accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: committers of openArchitectureWare - initial API and
 * implementation
 ******************************************************************************/
package org.openarchitectureware.console;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.Assert;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;
import org.eclipse.ui.texteditor.ITextEditor;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.internal.OawLog;

/**
 * OawConsoleHyperLink is a hyperlink to a oAW-related resource.
 * 
 * @author Sven Efftinge (http://www.efftinge.de)
 * @author Peter Friese
 */
public class OawConsoleHyperLink implements org.eclipse.ui.console.IHyperlink {

	private final IResource res;
	private final int start;
	private final int length;
	private int lineNumber;

	public OawConsoleHyperLink(IOawResource res, int start, int length) {
		if (res != null && res.getUnderlyingStorage() instanceof IFile) {
			this.res = (IFile) res.getUnderlyingStorage();
		} else {
			this.res = null;
		}
		this.start = start;
		this.length = length;
	}

	public OawConsoleHyperLink(IResource res, int start, int length) {
		this.res = res;
		this.start = start;
		this.length = length;
		this.lineNumber = -1;
	}

	public OawConsoleHyperLink(IResource res, int lineNumber) {
		this.res = res;
		Assert.isTrue(lineNumber >= 1, "Linenumbers must be >= 1");
		this.lineNumber = lineNumber - 1;
		this.start = -1;
		this.length = -1;
	}

	public void linkActivated() {
		if (lineNumber == -1) {
			revealRange();
		} else {
			gotoLine();
		}
	}

	private void revealRange() {
		try {
			IEditorPart opened;
			opened = IDE.openEditor(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage(), (IFile) res);
			if (opened instanceof ITextEditor) {
				ITextEditor editor = (ITextEditor) opened;
				editor.selectAndReveal(start, length);
			}
		} catch (PartInitException e) {
			OawLog.logError(e);
		}
	}

	private void gotoLine() {
		try {
			IEditorPart opened;
			opened = IDE.openEditor(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage(), (IFile) res);
			if (opened instanceof ITextEditor) {
				ITextEditor editor = (ITextEditor) opened;
				editor.selectAndReveal(start, length);
				IWorkbenchPage page = editor.getSite().getPage();
				page.activate(editor);
			}
		} catch (PartInitException e) {
			OawLog.logError(e);
		}
	}

	public void linkEntered() {
	}

	public void linkExited() {
	}

}
