/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.core.builder;

import java.lang.reflect.InvocationTargetException;

import org.eclipse.core.filebuffers.FileBuffers;
import org.eclipse.core.filebuffers.ITextFileBuffer;
import org.eclipse.core.filebuffers.ITextFileBufferManager;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.ui.actions.WorkspaceModifyOperation;
import org.openarchitectureware.OawPlugin;
import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.internal.OawLog;

public class OawMarkerManager {

	static final String getMARKER_TYPE() {
		return OawPlugin.getId() + ".problem";
	}

	public static void addMarker(final IFile file, final AnalysationIssue issue) {
		try {
			final IMarker marker = file.createMarker(getMARKER_TYPE());
			final int severity = (issue.isWarning()) ? IMarker.SEVERITY_WARNING : IMarker.SEVERITY_ERROR;
			int start = -1, end = -1;
			if (issue.getElement() != null) {
				start = issue.getElement().getStart();
				end = issue.getElement().getEnd();
			}
			internalAddMarker(file, marker, issue.getMessage(), severity, start, end);
		}
		catch (final CoreException e) {
		}
	}

	public static void addErrorMarker(final IFile file, final String message, final int severity, final int start,
			final int end) {
		try {
			final IMarker marker = file.createMarker(getMARKER_TYPE());
			internalAddMarker(file, marker, message, severity, start, end);
		}
		catch (final CoreException e) {
			OawLog.logError(e);
		}
	}

	public static void addWarningMarker(final IFile file, final String message, final int severity, final int start,
			final int end) {
		try {
			final IMarker marker = file.createMarker(getMARKER_TYPE());
			internalAddMarker(file, marker, message, severity, start, end);
		}
		catch (final CoreException e) {
		}
	}

	private final static void internalAddMarker(final IFile file, final IMarker marker, final String message,
			final int severity, final int start, final int end) {
		try {
			new WorkspaceModifyOperation() {

				@Override
				protected void execute(final IProgressMonitor monitor) throws CoreException, InvocationTargetException,
						InterruptedException {

					try {
						marker.setAttribute(IMarker.MESSAGE, message);
						marker.setAttribute(IMarker.SEVERITY, severity);
						int s = start;
						if (start == -1) {
							s = 1;
						}
						int e = end;
						if (end <= start) {
							e = start + 1;
						}
						marker.setAttribute(IMarker.CHAR_START, s);
						marker.setAttribute(IMarker.CHAR_END, e);
						final ITextFileBufferManager mgr = FileBuffers.getTextFileBufferManager();
						if (mgr != null) {
							final IPath location = file.getFullPath();
							try {
								mgr.connect(location, new NullProgressMonitor());
								final ITextFileBuffer buff = mgr.getTextFileBuffer(file.getFullPath());
								if (buff != null) {
									final IDocument doc = buff.getDocument();
									int line = doc.getLineOfOffset(start);

									// Markers specify lines 1-relative whereas
									// in documents the first line is line 0
									line++;
									marker.setAttribute(IMarker.LINE_NUMBER, doc.getLineOfOffset(start));
									marker.setAttribute(IMarker.LOCATION, "line: " + line);
								}
							}
							finally {
								mgr.disconnect(location, new NullProgressMonitor());
							}
						}
					}
					catch (final CoreException e) {
						OawLog.logError(e);
					}
					catch (final BadLocationException e) {
						OawLog.logError(e);
					}
				}
			}.run(new NullProgressMonitor());
		}
		catch (final Exception e) {
			OawLog.logError(e);
		}
	}

	public static void deleteMarkers(final IResource file) {
		try {
			if (file.exists()) {
				new WorkspaceModifyOperation() {

					@Override
					protected void execute(final IProgressMonitor monitor) throws CoreException,
							InvocationTargetException, InterruptedException {
						file.deleteMarkers(getMARKER_TYPE(), true, IResource.DEPTH_INFINITE);
					}

				}.run(new NullProgressMonitor());
			}
		}
		catch (final Exception ce) {
			OawLog.logError(ce);
		}
	}
}
