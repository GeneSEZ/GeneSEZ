/*******************************************************************************
 * Copyright (c) 2005 - 2008 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.xsd.type;

import org.eclipse.emf.ecore.util.FeatureMap;
import org.openarchitectureware.type.AbstractTypeImpl;
import org.openarchitectureware.type.Feature;
import org.openarchitectureware.type.baseimpl.PropertyImpl;
import org.openarchitectureware.xsd.XSDMetaModel;

/**
 * @author Moritz Eysholdt
 */
public class EFeatureMapEntryTypeImpl extends AbstractTypeImpl {

	private XSDMetaModel model;

	public EFeatureMapEntryTypeImpl(XSDMetaModel model, String name) {
		super(model.getTypeSystem(), name);
		this.model = model;
	}

	public Feature[] getContributedFeatures() {
		return new Feature[] {
				new PropertyImpl(this, "value", getTypeSystem().getObjectType()) {
					public Object get(Object target) {
						FeatureMap.Entry ent = (FeatureMap.Entry) target;
						return ent.getValue();
					}
				}, new PropertyImpl(this, "feature", model.getEFeatureType()) {
					public Object get(Object target) {
						FeatureMap.Entry ent = (FeatureMap.Entry) target;
						return ent.getEStructuralFeature();
					}
				} };
	}

	public boolean isInstance(Object o) {
		return o instanceof FeatureMap.Entry;
	}

	public Object newInstance() {
		throw new UnsupportedOperationException(
				"Feature map entries can not be instantiated outside EObjects");
	}

}
