/*******************************************************************************
 * Copyright (c) 2005 - 2008 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.xsd;

/**
 * @author Moritz Eysholdt
 */
import java.io.IOException;
import java.util.HashMap;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.GenericXMLResourceFactoryImpl;
import org.openarchitectureware.emf.EcoreUtil2;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;
import org.openarchitectureware.xsd.util.XSDUtil;

public class XMLProcessor extends AbstractWorkflowComponent {

	private static final String COMPONENT_NAME = "XML Processor";

	private String uri;
	private String outUri;

	/**
	 * Sets the input URI.
	 * 
	 * @param uri
	 *            the URI
	 */
	public void setUri(String uri) {
		this.uri = uri;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#checkConfiguration(org.openarchitectureware.workflow.issues.Issues)
	 */
	public void checkConfiguration(Issues issues) {
	}

	/**
	 * Sets the output URI.
	 * 
	 * @param outUri
	 *            the URI
	 */
	public void setOutUri(String outUri) {
		this.outUri = outUri;
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#invoke(org.openarchitectureware.workflow.WorkflowContext,
	 *      org.openarchitectureware.workflow.monitor.ProgressMonitor,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	public void invoke(WorkflowContext ctx, ProgressMonitor monitor,
			Issues issues) {
		ResourceSet rs = new ResourceSetImpl();
		URI u = EcoreUtil2.getURI(uri);
		// GenericXMLResourceImpl r = new GenericXMLResourceImpl(u);
		Resource r = new GenericXMLResourceFactoryImpl().createResource(u);
		rs.getResources().add(r);

		try {
			r.load(new HashMap<String, Object>());
			if (outUri != null && !outUri.equals("")) {
				r.setURI(XSDUtil.strToURI(outUri));
			}

			EObject o = r.getContents().get(0);
			XMLMixedContentFormater f = new XMLMixedContentFormater();
			f.beautifyMixedContent(0, o);
			HashMap<String, Object> prop = new HashMap<String, Object>();
			prop.put(XMLResource.OPTION_FORMATTED, Boolean.TRUE);
			prop.put(XMLResource.OPTION_LINE_WIDTH, 40);
			r.save(prop);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getComponentName()
	 */
	public String getComponentName() {
		return COMPONENT_NAME;
	}
}
