/*******************************************************************************
 * Copyright (c) 2005 - 2008 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.xsd.plugin;

import java.util.Collection;

import org.eclipse.jdt.core.IJavaProject;
import org.openarchitectureware.MetamodelContributor;
import org.openarchitectureware.expression.TypeSystem;
import org.openarchitectureware.type.MetaModel;

/**
 * @author Moritz Eysholdt
 */
public class XSDMetamodelContributor implements MetamodelContributor {

	public XSDMetamodelContributor() {
		//XSDToolsPlugin.traceLog("XsdMetaModelContributor constructed");
	}

	public MetaModel[] getMetamodels(IJavaProject project, TypeSystem ctx) {
		XSDToolsPlugin plugin = XSDToolsPlugin.getDefault();
		XSDMetamodelStore store = plugin.getXSDStore();
		Collection<MetaModel> mms = store.getMetamodels(project.getProject());

		XSDToolsPlugin.traceLog("getMetaModels("
				+ project.getProject().getName() + ") -> " + mms);

		return mms.toArray(new MetaModel[mms.size()]);
	}
}
