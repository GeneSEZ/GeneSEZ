/*******************************************************************************
 * Copyright (c) 2005 - 2008 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.xsd.type;

import java.util.Map;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.ETypedElement;
import org.eclipse.emf.ecore.EcorePackage;
import org.openarchitectureware.expression.TypeSystem;
import org.openarchitectureware.type.AbstractTypeImpl;
import org.openarchitectureware.type.Feature;
import org.openarchitectureware.type.Type;
import org.openarchitectureware.type.baseimpl.OperationImpl;
import org.openarchitectureware.type.baseimpl.PropertyImpl;

/**
 * @author Moritz Eysholdt
 */
public class EMapEntryType extends AbstractTypeImpl {

	public static boolean isEMapEntry(ETypedElement element) {
		EClassifier t = element.getEType();
		return element != null && element.eContainer() instanceof EClass
				&& t != null && t.getInstanceClass() != null
				&& Map.Entry.class.isAssignableFrom(t.getInstanceClass())
				&& !element.isMany();
	}

	public static boolean isEMapEntryObject(Object o) {
		return o instanceof Map.Entry;
	}

	private Type keyType;
	private Type valueType;

	public EMapEntryType(TypeSystem typeSystem, String name,
			EClassifier innerType) {
		super(typeSystem, name);
		determineTypes(innerType);
	}

	private void determineTypes(EClassifier emfType) {
		EClass str2str = EcorePackage.Literals.ESTRING_TO_STRING_MAP_ENTRY;
		if (emfType instanceof EClass
				&& str2str.isSuperTypeOf((EClass) emfType)) {
			keyType = getTypeSystem().getStringType();
			valueType = getTypeSystem().getStringType();
		} else {
			keyType = getTypeSystem().getObjectType();
			valueType = getTypeSystem().getObjectType();
		}
	}

	public Feature[] getContributedFeatures() {
		return new Feature[] { new PropertyImpl(this, "value", valueType) {
			@SuppressWarnings("unchecked")
			public Object get(Object target) {
				Map.Entry ent = (Map.Entry) target;
				return ent.getValue();
			}
		}, new PropertyImpl(this, "key", keyType) {
			@SuppressWarnings("unchecked")
			public Object get(Object target) {
				Map.Entry ent = (Map.Entry) target;
				return ent.getKey();
			}
		}, new OperationImpl(this, "setValue", valueType, valueType) {
			@SuppressWarnings("unchecked")
			protected Object evaluateInternal(Object target, Object[] params) {
				Map.Entry ent = (Map.Entry) target;
				Object old = ent.getValue();
				ent.setValue(params[0]);
				return old;
			}
		} };
	}

	public Type getKeyType() {
		return keyType;
	}

	public Type getValueType() {
		return valueType;
	}

	public boolean isInstance(Object o) {
		return o instanceof Map.Entry;
	}

	public Object newInstance() {
		throw new UnsupportedOperationException(
				"Map entries can not be instantiated standlaone");
	}

}
