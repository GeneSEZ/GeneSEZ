/*******************************************************************************
 * Copyright (c) 2005 - 2008 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.xsd.type;

import javax.xml.namespace.QName;

import org.openarchitectureware.expression.TypeSystem;
import org.openarchitectureware.type.AbstractTypeImpl;
import org.openarchitectureware.type.Feature;
import org.openarchitectureware.type.Type;
import org.openarchitectureware.type.baseimpl.PropertyImpl;

/**
 * @author Moritz Eysholdt
 */
public class QNameType extends AbstractTypeImpl {

	public QNameType(TypeSystem typeSystem, String name) {
		super(typeSystem, name);
	}

	public Feature[] getContributedFeatures() {
		final Type string = getTypeSystem().getStringType();
		return new Feature[] { new PropertyImpl(this, "namespaceURI", string) {
			public Object get(Object target) {
				QName q = (QName) target;
				return q.getNamespaceURI();
			}
		}, new PropertyImpl(this, "localPart", string) {
			public Object get(Object target) {
				QName q = (QName) target;
				return q.getLocalPart();
			}
		}, new PropertyImpl(this, "prefix", string) {
			public Object get(Object target) {
				QName q = (QName) target;
				return q.getPrefix();
			}
		} };
	}

	public boolean isInstance(Object o) {
		return o instanceof QName;
	}

	public Object newInstance() {
		return new UnsupportedOperationException(
				"Qnames can not be instanciated manually.");
	}

}
