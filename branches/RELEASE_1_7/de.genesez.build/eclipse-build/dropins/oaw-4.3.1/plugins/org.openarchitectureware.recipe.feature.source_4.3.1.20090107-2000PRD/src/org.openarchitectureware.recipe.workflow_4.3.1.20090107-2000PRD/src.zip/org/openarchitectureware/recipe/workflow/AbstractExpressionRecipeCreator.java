/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.recipe.workflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.openarchitectureware.expression.ExecutionContextImpl;
import org.openarchitectureware.expression.ExpressionFacade;
import org.openarchitectureware.expression.Resource;
import org.openarchitectureware.expression.Variable;
import org.openarchitectureware.recipe.core.Check;
import org.openarchitectureware.type.MetaModel;

public abstract class AbstractExpressionRecipeCreator extends RecipeCreationComponent {

	private List<String> extensions = new ArrayList<String>();
	private List<String> imports = new ArrayList<String>();
	private List<MetaModel> metamodels = new ArrayList<MetaModel>();

	/**
	 * Adds a metamodel.
	 * 
	 * @param metamodel
	 *            the metamodel
	 */
	public void addMetaModel(MetaModel metamodel) {
		metamodels.add(metamodel);
	}

	/**
	 * Adds an extension.
	 * 
	 * @param extension
	 *            the extension
	 */
	public void addExtension(String extension) {
		extensions.add(extension);
	}

	/**
	 * Adds an import.
	 * 
	 * @param imp
	 *            the import
	 */
	public void addImport(String imp) {
		imports.add(imp);
	}

	@Override
	protected Collection<Check> createRecipes(Object model, String project) {
		ExecutionContextImpl ctx = new ExecutionContextImpl();
		for (MetaModel mm : metamodels) {
			ctx.registerMetaModel(mm);
		}
		ctx = (ExecutionContextImpl) ctx.cloneWithVariable(new Variable("this", model));
		ctx = (ExecutionContextImpl) ctx.cloneWithResource(new Resource() {

			public String getFullyQualifiedName() {
				return "recipe-creation";
			}

			public String[] getImportedExtensions() {
				return extensions.toArray(new String[extensions.size()]);
			}

			public String[] getImportedNamespaces() {
				return imports.toArray(new String[imports.size()]);
			}

			public void setFullyQualifiedName(String arg0) {

			}
		});
		ExpressionFacade facade = new ExpressionFacade(ctx);

		return internalCreateRecipes(facade, project);
	}

	protected abstract Collection<Check> internalCreateRecipes(ExpressionFacade facade, String project);

}
