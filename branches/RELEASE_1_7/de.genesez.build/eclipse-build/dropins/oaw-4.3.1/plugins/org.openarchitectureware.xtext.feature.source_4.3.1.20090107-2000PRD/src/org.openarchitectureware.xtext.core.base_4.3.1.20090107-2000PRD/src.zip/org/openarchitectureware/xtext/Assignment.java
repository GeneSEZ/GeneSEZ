/**
 * <copyright>
 * </copyright>
 *
 * $Id: Assignment.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Assignment</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.Assignment#getFeature <em>Feature</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.Assignment#getToken <em>Token</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.Assignment#getOperator <em>Operator</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getAssignment()
 * @model
 * @generated
 */
public interface Assignment extends Element {
	/**
	 * Returns the value of the '<em><b>Feature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Feature</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Feature</em>' attribute.
	 * @see #setFeature(String)
	 * @see org.openarchitectureware.xtext.XtextPackage#getAssignment_Feature()
	 * @model
	 * @generated
	 */
	String getFeature();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.Assignment#getFeature <em>Feature</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Feature</em>' attribute.
	 * @see #getFeature()
	 * @generated
	 */
	void setFeature(String value);

	/**
	 * Returns the value of the '<em><b>Token</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Token</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Token</em>' containment reference.
	 * @see #setToken(AbstractToken)
	 * @see org.openarchitectureware.xtext.XtextPackage#getAssignment_Token()
	 * @model containment="true"
	 * @generated
	 */
	AbstractToken getToken();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.Assignment#getToken <em>Token</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Token</em>' containment reference.
	 * @see #getToken()
	 * @generated
	 */
	void setToken(AbstractToken value);

	/**
	 * Returns the value of the '<em><b>Operator</b></em>' attribute.
	 * The literals are from the enumeration {@link org.openarchitectureware.xtext.AssignOperator}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Operator</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operator</em>' attribute.
	 * @see org.openarchitectureware.xtext.AssignOperator
	 * @see #setOperator(AssignOperator)
	 * @see org.openarchitectureware.xtext.XtextPackage#getAssignment_Operator()
	 * @model
	 * @generated
	 */
	AssignOperator getOperator();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.Assignment#getOperator <em>Operator</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operator</em>' attribute.
	 * @see org.openarchitectureware.xtext.AssignOperator
	 * @see #getOperator()
	 * @generated
	 */
	void setOperator(AssignOperator value);

} // Assignment
