/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.parser.model;

import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.List;

import org.antlr.runtime.CommonToken;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.Token;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.emf.ecore.EObject;
import org.openarchitectureware.xtext.parser.parsetree.Error;
import org.openarchitectureware.xtext.parser.parsetree.Node;
import org.openarchitectureware.xtext.parser.parsetree.ParsetreeFactory;

public class ParseTreeManagerNeu {

	Stack<Node> nodes = new Stack<Node>();
	
	private Node current = null;

	public ParseTreeManagerNeu() {
		// create the root.
		current = ParsetreeFactory.eINSTANCE.createNode();
		current.setLine(1);
	}

	public void createNode(EObject grammarElement) {
		nodes.push(current);
		current = ParsetreeFactory.eINSTANCE.createNode();
		current.setGrammarElement(grammarElement);
	}

	public void destroyNode() {
		current = nodes.pop();
	}
	
	private void invokeRule(int line, int start) {
		current.setLine(line);
		current.setStart(start);
		if (!nodes.isEmpty()) {
			current.setParent(nodes.peek());
		}
	}

	public void setModelElement(Enumerator value) {
		if (value instanceof EObject)
			current.setModelElement((EObject)value);
	}

	public void setModelElement(EObject value) {
		current.setModelElement(value);
		if (NodeUtil.getNode(value) == null)
			value.eAdapters().add(new NodeAdapter(current));
	}

	public Token ruleFinished(Token o) {
		current.setToken((Token) o);
		return ruleFinishedInternal(o, line(o), start(o), end(o));
	}

	public <T> T ruleFinished(T o) {
		RangeAdapter ra = getRangeAdapter(current);
		return ruleFinishedInternal(o, line(ra), start(ra), end(ra));
	}
	
	public <T> T ruleFinishedInternal(T o, int line, int start, int end) {
		current.setLine(line);
		current.setStart(start);
		current.setEnd(end);

		if (!nodes.isEmpty()) {
			Node parent = nodes.pop();
			getRangeAdapter(parent).add(current);
			current.setParent(parent);
			current = parent;
		}

		return o;
	}

	private RangeAdapter getRangeAdapter(Node parent) {
		for (Adapter a : parent.eAdapters()) {
			if (a instanceof RangeAdapter) {
				return (RangeAdapter) a;

			}
		}
		RangeAdapter ra = new RangeAdapter();
		parent.eAdapters().add(ra);
		return ra;
	}

	public Node getCurrent() {
		return this.current;
	}

	@SuppressWarnings("unchecked")
	public void addError(String message, RecognitionException ex) {
		Error e = ParsetreeFactory.eINSTANCE.createError();
		e.setMessage(message);
		e.setException(ex);
		current.getErrors().add(e);
	}

	private int line(Token t) {
		if (t==null)
			return 1;
		return t.getLine();
	}
        
   	private int line(RangeAdapter adapter) {
   		if ((adapter == null) || adapter.isEmpty())
   			return 1;
   		return adapter.getLine();
   	}

	private int start(Token t) {
		if (t==null)
			return 0;
		if (t instanceof CommonToken) {
			return ((CommonToken)t).getStartIndex();
		}
		return t.getTokenIndex();
	}
        
   	private int start(RangeAdapter adapter) {
   		if ((adapter == null) || adapter.isEmpty())
   			return 0;
   		return adapter.getStart();
   	}

	private int end(Token t) {
		if (t==null)
			return 1;
		if (t instanceof CommonToken) {
			return ((CommonToken)t).getStopIndex()+1;
		}
		return t.getTokenIndex();
	}

	private int end(RangeAdapter adapter) {
		if ((adapter == null) || adapter.isEmpty())
			return 1;
		return adapter.getEnd();
	}

	private static class Stack<E> {
		List<E> holder = new ArrayList<E>();

		public E push(E item) {
			holder.add(item);
			return item;
		}

		public E peek() {
			int len = holder.size() - 1;
			if (len == -1)
				throw new EmptyStackException();
			return holder.get(len);
		}

		public E pop() {
			int len = holder.size() - 1;
			if (len == -1)
				throw new EmptyStackException();
			E element = holder.get(len);
			holder.remove(len);
			return element;
		}
		
		public boolean isEmpty() {
			return holder.isEmpty();
		}
	}
}
