/**
 * <copyright>
 * </copyright>
 *
 * $Id: ParsetreePackage.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext.parser.parsetree;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreeFactory
 * @model kind="package"
 * @generated
 */
public interface ParsetreePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "parsetree";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.eclipse.org/emp/xtext/parsetree";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "parsetree";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ParsetreePackage eINSTANCE = org.openarchitectureware.xtext.parser.parsetree.impl.ParsetreePackageImpl.init();

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.parser.parsetree.impl.NodeImpl <em>Node</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.parser.parsetree.impl.NodeImpl
	 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ParsetreePackageImpl#getNode()
	 * @generated
	 */
	int NODE = 0;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__CHILDREN = 0;

	/**
	 * The feature id for the '<em><b>Parent</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__PARENT = 1;

	/**
	 * The feature id for the '<em><b>Token</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__TOKEN = 2;

	/**
	 * The feature id for the '<em><b>Model Element</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__MODEL_ELEMENT = 3;

	/**
	 * The feature id for the '<em><b>Grammar Element</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__GRAMMAR_ELEMENT = 4;

	/**
	 * The feature id for the '<em><b>Line</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__LINE = 5;

	/**
	 * The feature id for the '<em><b>Start</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__START = 6;

	/**
	 * The feature id for the '<em><b>End</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__END = 7;

	/**
	 * The feature id for the '<em><b>Errors</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE__ERRORS = 8;

	/**
	 * The number of structural features of the '<em>Node</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NODE_FEATURE_COUNT = 9;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.parser.parsetree.impl.ErrorImpl <em>Error</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ErrorImpl
	 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ParsetreePackageImpl#getError()
	 * @generated
	 */
	int ERROR = 1;

	/**
	 * The feature id for the '<em><b>Message</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERROR__MESSAGE = 0;

	/**
	 * The feature id for the '<em><b>Exception</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERROR__EXCEPTION = 1;

	/**
	 * The number of structural features of the '<em>Error</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ERROR_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '<em>Token</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.antlr.runtime.Token
	 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ParsetreePackageImpl#getToken()
	 * @generated
	 */
	int TOKEN = 2;

	/**
	 * The meta object id for the '<em>Recognition Exception</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.antlr.runtime.RecognitionException
	 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ParsetreePackageImpl#getRecognitionException()
	 * @generated
	 */
	int RECOGNITION_EXCEPTION = 3;


	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.parser.parsetree.Node <em>Node</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Node</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node
	 * @generated
	 */
	EClass getNode();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Children</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getChildren()
	 * @see #getNode()
	 * @generated
	 */
	EReference getNode_Children();

	/**
	 * Returns the meta object for the container reference '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getParent <em>Parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Parent</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getParent()
	 * @see #getNode()
	 * @generated
	 */
	EReference getNode_Parent();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getToken <em>Token</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Token</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getToken()
	 * @see #getNode()
	 * @generated
	 */
	EAttribute getNode_Token();

	/**
	 * Returns the meta object for the reference '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getModelElement <em>Model Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Model Element</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getModelElement()
	 * @see #getNode()
	 * @generated
	 */
	EReference getNode_ModelElement();

	/**
	 * Returns the meta object for the reference '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getGrammarElement <em>Grammar Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Grammar Element</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getGrammarElement()
	 * @see #getNode()
	 * @generated
	 */
	EReference getNode_GrammarElement();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getLine <em>Line</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Line</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getLine()
	 * @see #getNode()
	 * @generated
	 */
	EAttribute getNode_Line();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getStart <em>Start</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getStart()
	 * @see #getNode()
	 * @generated
	 */
	EAttribute getNode_Start();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getEnd <em>End</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>End</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getEnd()
	 * @see #getNode()
	 * @generated
	 */
	EAttribute getNode_End();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getErrors <em>Errors</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Errors</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getErrors()
	 * @see #getNode()
	 * @generated
	 */
	EReference getNode_Errors();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.parser.parsetree.Error <em>Error</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Error</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Error
	 * @generated
	 */
	EClass getError();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.parser.parsetree.Error#getMessage <em>Message</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Message</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Error#getMessage()
	 * @see #getError()
	 * @generated
	 */
	EAttribute getError_Message();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.parser.parsetree.Error#getException <em>Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Exception</em>'.
	 * @see org.openarchitectureware.xtext.parser.parsetree.Error#getException()
	 * @see #getError()
	 * @generated
	 */
	EAttribute getError_Exception();

	/**
	 * Returns the meta object for data type '{@link org.antlr.runtime.Token <em>Token</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Token</em>'.
	 * @see org.antlr.runtime.Token
	 * @model instanceClass="org.antlr.runtime.Token"
	 * @generated
	 */
	EDataType getToken();

	/**
	 * Returns the meta object for data type '{@link org.antlr.runtime.RecognitionException <em>Recognition Exception</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Recognition Exception</em>'.
	 * @see org.antlr.runtime.RecognitionException
	 * @model instanceClass="org.antlr.runtime.RecognitionException"
	 * @generated
	 */
	EDataType getRecognitionException();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ParsetreeFactory getParsetreeFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.parser.parsetree.impl.NodeImpl <em>Node</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.parser.parsetree.impl.NodeImpl
		 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ParsetreePackageImpl#getNode()
		 * @generated
		 */
		EClass NODE = eINSTANCE.getNode();

		/**
		 * The meta object literal for the '<em><b>Children</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NODE__CHILDREN = eINSTANCE.getNode_Children();

		/**
		 * The meta object literal for the '<em><b>Parent</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NODE__PARENT = eINSTANCE.getNode_Parent();

		/**
		 * The meta object literal for the '<em><b>Token</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE__TOKEN = eINSTANCE.getNode_Token();

		/**
		 * The meta object literal for the '<em><b>Model Element</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NODE__MODEL_ELEMENT = eINSTANCE.getNode_ModelElement();

		/**
		 * The meta object literal for the '<em><b>Grammar Element</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NODE__GRAMMAR_ELEMENT = eINSTANCE.getNode_GrammarElement();

		/**
		 * The meta object literal for the '<em><b>Line</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE__LINE = eINSTANCE.getNode_Line();

		/**
		 * The meta object literal for the '<em><b>Start</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE__START = eINSTANCE.getNode_Start();

		/**
		 * The meta object literal for the '<em><b>End</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NODE__END = eINSTANCE.getNode_End();

		/**
		 * The meta object literal for the '<em><b>Errors</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NODE__ERRORS = eINSTANCE.getNode_Errors();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.parser.parsetree.impl.ErrorImpl <em>Error</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ErrorImpl
		 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ParsetreePackageImpl#getError()
		 * @generated
		 */
		EClass ERROR = eINSTANCE.getError();

		/**
		 * The meta object literal for the '<em><b>Message</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ERROR__MESSAGE = eINSTANCE.getError_Message();

		/**
		 * The meta object literal for the '<em><b>Exception</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ERROR__EXCEPTION = eINSTANCE.getError_Exception();

		/**
		 * The meta object literal for the '<em>Token</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.antlr.runtime.Token
		 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ParsetreePackageImpl#getToken()
		 * @generated
		 */
		EDataType TOKEN = eINSTANCE.getToken();

		/**
		 * The meta object literal for the '<em>Recognition Exception</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.antlr.runtime.RecognitionException
		 * @see org.openarchitectureware.xtext.parser.parsetree.impl.ParsetreePackageImpl#getRecognitionException()
		 * @generated
		 */
		EDataType RECOGNITION_EXCEPTION = eINSTANCE.getRecognitionException();

	}

} //ParsetreePackage
