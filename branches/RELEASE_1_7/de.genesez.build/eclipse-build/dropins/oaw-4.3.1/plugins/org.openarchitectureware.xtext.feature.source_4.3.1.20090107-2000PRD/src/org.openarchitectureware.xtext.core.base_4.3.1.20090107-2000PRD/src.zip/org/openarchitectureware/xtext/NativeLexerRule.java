/**
 * <copyright>
 * </copyright>
 *
 * $Id: NativeLexerRule.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Native Lexer Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.NativeLexerRule#getImpl <em>Impl</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getNativeLexerRule()
 * @model
 * @generated
 */
public interface NativeLexerRule extends Rule {
	/**
	 * Returns the value of the '<em><b>Impl</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Impl</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Impl</em>' attribute.
	 * @see #setImpl(String)
	 * @see org.openarchitectureware.xtext.XtextPackage#getNativeLexerRule_Impl()
	 * @model
	 * @generated
	 */
	String getImpl();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.NativeLexerRule#getImpl <em>Impl</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Impl</em>' attribute.
	 * @see #getImpl()
	 * @generated
	 */
	void setImpl(String value);

} // NativeLexerRule
