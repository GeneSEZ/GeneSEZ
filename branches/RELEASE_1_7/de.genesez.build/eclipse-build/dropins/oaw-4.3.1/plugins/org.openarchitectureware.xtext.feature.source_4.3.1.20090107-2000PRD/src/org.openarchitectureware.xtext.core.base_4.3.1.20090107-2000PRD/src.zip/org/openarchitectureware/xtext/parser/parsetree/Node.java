/**
 * <copyright>
 * </copyright>
 *
 * $Id: Node.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext.parser.parsetree;

import org.antlr.runtime.Token;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Node</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Node#getChildren <em>Children</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Node#getParent <em>Parent</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Node#getToken <em>Token</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Node#getModelElement <em>Model Element</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Node#getGrammarElement <em>Grammar Element</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Node#getLine <em>Line</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Node#getStart <em>Start</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Node#getEnd <em>End</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.parser.parsetree.Node#getErrors <em>Errors</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode()
 * @model
 * @generated
 */
public interface Node extends EObject {
	/**
	 * Returns the value of the '<em><b>Children</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.parser.parsetree.Node}.
	 * It is bidirectional and its opposite is '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getParent <em>Parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Children</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Children</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode_Children()
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getParent
	 * @model type="org.openarchitectureware.xtext.parser.parsetree.Node" opposite="parent" containment="true"
	 * @generated
	 */
	EList getChildren();

	/**
	 * Returns the value of the '<em><b>Parent</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parent</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parent</em>' container reference.
	 * @see #setParent(Node)
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode_Parent()
	 * @see org.openarchitectureware.xtext.parser.parsetree.Node#getChildren
	 * @model opposite="children" transient="false"
	 * @generated
	 */
	Node getParent();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getParent <em>Parent</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parent</em>' container reference.
	 * @see #getParent()
	 * @generated
	 */
	void setParent(Node value);

	/**
	 * Returns the value of the '<em><b>Token</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Token</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Token</em>' attribute.
	 * @see #setToken(Token)
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode_Token()
	 * @model dataType="org.openarchitectureware.xtext.parser.parsetree.Token"
	 * @generated
	 */
	Token getToken();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getToken <em>Token</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Token</em>' attribute.
	 * @see #getToken()
	 * @generated
	 */
	void setToken(Token value);

	/**
	 * Returns the value of the '<em><b>Model Element</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Model Element</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Model Element</em>' reference.
	 * @see #setModelElement(EObject)
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode_ModelElement()
	 * @model
	 * @generated
	 */
	EObject getModelElement();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getModelElement <em>Model Element</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Model Element</em>' reference.
	 * @see #getModelElement()
	 * @generated
	 */
	void setModelElement(EObject value);

	/**
	 * Returns the value of the '<em><b>Grammar Element</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Grammar Element</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Grammar Element</em>' reference.
	 * @see #setGrammarElement(EObject)
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode_GrammarElement()
	 * @model
	 * @generated
	 */
	EObject getGrammarElement();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getGrammarElement <em>Grammar Element</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Grammar Element</em>' reference.
	 * @see #getGrammarElement()
	 * @generated
	 */
	void setGrammarElement(EObject value);

	/**
	 * Returns the value of the '<em><b>Line</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Line</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Line</em>' attribute.
	 * @see #setLine(int)
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode_Line()
	 * @model
	 * @generated
	 */
	int getLine();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getLine <em>Line</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Line</em>' attribute.
	 * @see #getLine()
	 * @generated
	 */
	void setLine(int value);

	/**
	 * Returns the value of the '<em><b>Start</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start</em>' attribute.
	 * @see #setStart(int)
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode_Start()
	 * @model
	 * @generated
	 */
	int getStart();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getStart <em>Start</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start</em>' attribute.
	 * @see #getStart()
	 * @generated
	 */
	void setStart(int value);

	/**
	 * Returns the value of the '<em><b>End</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>End</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End</em>' attribute.
	 * @see #setEnd(int)
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode_End()
	 * @model
	 * @generated
	 */
	int getEnd();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.parser.parsetree.Node#getEnd <em>End</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End</em>' attribute.
	 * @see #getEnd()
	 * @generated
	 */
	void setEnd(int value);

	/**
	 * Returns the value of the '<em><b>Errors</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.parser.parsetree.Error}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Errors</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Errors</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.parser.parsetree.ParsetreePackage#getNode_Errors()
	 * @model type="org.openarchitectureware.xtext.parser.parsetree.Error" containment="true"
	 * @generated
	 */
	EList getErrors();

} // Node
