package org.openarchitectureware.xtext.resource;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.impl.ResourceImpl;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.workflow.util.ResourceLoader;
import org.openarchitectureware.workflow.util.ResourceLoaderFactory;
import org.openarchitectureware.xtend.XtendFacade;
import org.openarchitectureware.xtext.parser.ErrorMsg;
import org.openarchitectureware.xtext.parser.IXtextParser;
import org.openarchitectureware.xtext.parser.impl.AbstractXtextParser;
import org.openarchitectureware.xtext.parser.model.NodeUtil;


public abstract class AbstractXtextResource extends ResourceImpl implements IXtextResource {
	private IXtextParser p = null;
	private String formattingExtension;
	private ResourceLoader resourceLoader;
	private boolean isLinked;

	public static final String LINK_ON_LOAD_OPTION = "Link Load Option";
	
	public AbstractXtextResource(URI uri) {
		super(uri);
		isLinked = false;
	}

	@Override
	protected void doLoad(InputStream inputStream, Map<?, ?> options)
			throws IOException {
		isLinked = false;
		p = createParser(inputStream);
		getContents().clear();
		EObject modelElement = NodeUtil.getModelElement(p.getRootNode());
		if (modelElement != null) {
			getContents().add(modelElement);
			if(isLinkOnLoadOption(options)) {
				p.preLinking();
				p.doLinking();
				p.postLinking();
				isLinked = true;
			}
		}
		for (final ErrorMsg msg : p.getParseErrors()) {
			getErrors().add(new Diagnostic() {
				public int getColumn() {
					return msg.getStart();
				}

				public int getLine() {
					return msg.getLine();
				}

				public String getLocation() {
					return getURI().toString();
				}

				public String getMessage() {
					return msg.getMsg();
				}});
		}
	}
	
	@Override
	protected void doUnload() {
		isLinked = false;
		super.doUnload();
	}
	
	private boolean isLinkOnLoadOption(Map<?,?> options) {
		if(options == null) {
			return true;
		}
		Object value = options.get(LINK_ON_LOAD_OPTION);
		return value == null | value == Boolean.TRUE;
	}
	
	protected String getFormattingExtension() {
		return formattingExtension;
	}

	protected void setFormattingExtension(String formattingExtension) {
		this.formattingExtension = formattingExtension;
	}

	protected void setResourceLoader(ResourceLoader resourceLoader) {
		this.resourceLoader=resourceLoader;
	}
 	
	@Override
	public void doSave(OutputStream outputStream, Map<?, ?> options) throws IOException {
		ResourceLoader cl = ResourceLoaderFactory.createResourceLoader();
		try {
			ResourceLoaderFactory.setCurrentThreadResourceLoader(resourceLoader);
			ExecutionContext ctx = AbstractXtextParser.getExecutionContext();
			XtendFacade facade = XtendFacade.create(ctx, getFormattingExtension());
			String r = (String) facade.call("format", getContents());
			outputStream.write(r.getBytes());
		} catch (Exception e) {
			throw new RuntimeException("Error while save resource "+uri.toString()+" : "+e.getMessage(),e);
		} finally {
			ResourceLoaderFactory.setCurrentThreadResourceLoader(cl);
		}
	}
	
	public IXtextParser getParser() {
		return p;
	}
	
	protected abstract IXtextParser createParser(InputStream inputStream);


	protected void handleError(Exception e) {
		throw new RuntimeException(e);
	}

	public static String throwNoFormatterException() {
		throw new UnsupportedOperationException("Unable to save resource: No formatter specified.");
	}
	
	public boolean isLinked() {
		return isLinked;
	}
}
