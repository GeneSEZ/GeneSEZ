package org.openarchitectureware.xtext.parser;

import java.util.List;

import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.xtext.parser.parsetree.Node;

public interface IXtextParser {
	List<ErrorMsg> getParseErrors();

	Node getRootNode();

	Issues doCheck();

	void preLinking();

	void doLinking();

	void postLinking();

}
