/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.MultiLineRule;
import org.eclipse.jface.text.rules.SingleLineRule;
import org.openarchitectureware.xtext.editor.scanning.AbstractPartitionScanner;

public class GeneratedPartitionScanner extends AbstractPartitionScanner {

	@Override
	public List<IPredicateRule> getRules() {
		final List<IPredicateRule> rules = new ArrayList<IPredicateRule>();

		rules.add(new MultiLineRule("/*", "*/", comment));
		rules.add(new SingleLineRule("//", "", comment));

		rules.add(new MultiLineRule("\"", "\"", string, '\\'));
		rules.add(new MultiLineRule("'", "'", string, '\\'));
		return rules;
	}

	protected IToken getSingleLineCommentToken(final String string) {
		return comment;
	}

	protected IToken getStringToken(final String start, final String end) {
		return string;
	}

}
