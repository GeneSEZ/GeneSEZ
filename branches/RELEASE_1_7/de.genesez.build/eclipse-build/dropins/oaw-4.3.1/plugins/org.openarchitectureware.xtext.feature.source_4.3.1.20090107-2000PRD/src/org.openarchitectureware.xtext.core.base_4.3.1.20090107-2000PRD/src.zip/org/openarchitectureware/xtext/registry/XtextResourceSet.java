/*******************************************************************************
 * Copyright (c) 2008 itemis AG (http://www.itemis.eu) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 *******************************************************************************/
package org.openarchitectureware.xtext.registry;

import java.util.HashMap;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.URIConverter;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.resource.impl.URIConverterImpl;

/**
 * A resource set that is capable of resolving classpath URIs.
 * 
 * @author Jan K�hnlein
 */
public class XtextResourceSet extends ResourceSetImpl {

    private IClasspathUriResolver resolver;

    private Object classpathURIContext;

    private boolean isRecursiveLink = true;
    
    public XtextResourceSet() {
    	setURIResourceMap(new HashMap<URI,Resource>());
    }

    private URI resolveClasspathURI(URI uri) {
        return getClasspathUriResolver().resolve(getClasspathURIContext(), uri);
    }

    @Override
    public URIConverter getURIConverter() {
        if (uriConverter == null) {
            uriConverter = new URIConverterImpl() {
                @Override
                public URI normalize(URI uri) {
                    if (ClasspathUriUtil.isClassapthUri(uri)) {
                        return XtextResourceSet.this.resolveClasspathURI(uri);
                    }
                    return super.normalize(uri);
                }
            };
        }
        return uriConverter;
    }

    public Object getClasspathURIContext() {
        return classpathURIContext;
    }

    public void setClasspathURIContext(Object classpathURIContext) {
        this.classpathURIContext = classpathURIContext;
    }

    public IClasspathUriResolver getClasspathUriResolver() {
        if (resolver == null) {
            resolver = new ClassloaderClasspathUriResolver();
        }
        return resolver;
    }

    public void setClasspathUriResolver(IClasspathUriResolver resolver) {
        this.resolver = resolver;
    }

	public boolean isRecursiveLink() {
		return isRecursiveLink;
	}

	public void setRecursiveLink(boolean isRecursiveLink) {
		this.isRecursiveLink = isRecursiveLink;
	}
    

}
