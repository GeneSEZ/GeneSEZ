/**
 * <copyright>
 * </copyright>
 *
 * $Id: XtextFile.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>File</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.XtextFile#getImports <em>Imports</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.XtextFile#getMmImports <em>Mm Imports</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.XtextFile#isCommentsDisabledFlag <em>Comments Disabled Flag</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.XtextFile#getName <em>Name</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.XtextFile#getNsURI <em>Ns URI</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.XtextFile#getRules <em>Rules</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.XtextFile#isPreventMMGeneration <em>Prevent MM Generation</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getXtextFile()
 * @model
 * @generated
 */
public interface XtextFile extends EObject {
	/**
	 * Returns the value of the '<em><b>Imports</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.Import}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Imports</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Imports</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.XtextPackage#getXtextFile_Imports()
	 * @model containment="true"
	 * @generated
	 */
	EList<Import> getImports();

	/**
	 * Returns the value of the '<em><b>Mm Imports</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.MetamodelImport}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mm Imports</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mm Imports</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.XtextPackage#getXtextFile_MmImports()
	 * @model containment="true"
	 * @generated
	 */
	EList<MetamodelImport> getMmImports();

	/**
	 * Returns the value of the '<em><b>Comments Disabled Flag</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Comments Disabled Flag</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Comments Disabled Flag</em>' attribute.
	 * @see #setCommentsDisabledFlag(boolean)
	 * @see org.openarchitectureware.xtext.XtextPackage#getXtextFile_CommentsDisabledFlag()
	 * @model
	 * @generated
	 */
	boolean isCommentsDisabledFlag();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.XtextFile#isCommentsDisabledFlag <em>Comments Disabled Flag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Comments Disabled Flag</em>' attribute.
	 * @see #isCommentsDisabledFlag()
	 * @generated
	 */
	void setCommentsDisabledFlag(boolean value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see org.openarchitectureware.xtext.XtextPackage#getXtextFile_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.XtextFile#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Ns URI</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ns URI</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ns URI</em>' attribute.
	 * @see #setNsURI(String)
	 * @see org.openarchitectureware.xtext.XtextPackage#getXtextFile_NsURI()
	 * @model
	 * @generated
	 */
	String getNsURI();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.XtextFile#getNsURI <em>Ns URI</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ns URI</em>' attribute.
	 * @see #getNsURI()
	 * @generated
	 */
	void setNsURI(String value);

	/**
	 * Returns the value of the '<em><b>Rules</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.Rule}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Rules</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Rules</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.XtextPackage#getXtextFile_Rules()
	 * @model containment="true"
	 * @generated
	 */
	EList<Rule> getRules();

	/**
	 * Returns the value of the '<em><b>Prevent MM Generation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Prevent MM Generation</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Prevent MM Generation</em>' attribute.
	 * @see #setPreventMMGeneration(boolean)
	 * @see org.openarchitectureware.xtext.XtextPackage#getXtextFile_PreventMMGeneration()
	 * @model
	 * @generated
	 */
	boolean isPreventMMGeneration();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.XtextFile#isPreventMMGeneration <em>Prevent MM Generation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Prevent MM Generation</em>' attribute.
	 * @see #isPreventMMGeneration()
	 * @generated
	 */
	void setPreventMMGeneration(boolean value);

} // XtextFile
