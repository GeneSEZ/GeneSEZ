/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/

package org.antlr;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent2;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;
import org.openarchitectureware.workflow.util.ResourceLoaderFactory;

public class WorkflowComponent extends AbstractWorkflowComponent2 {

	private static final String COMPONENT_NAME = "AntLR";

	Log log = LogFactory.getLog(getClass());

	private List<String> args = new ArrayList<String>();

	private String grammar;

	private boolean useResourceLoader = false;

	/**
	 * Sets if a resource loader is used for file loading or not.
	 * 
	 * @param useResourceLoader
	 *            If <code>true</code>, a resource loader is used for file
	 *            loading, otherwise not.
	 */
	public void setUseResourceLoader(boolean useResourceLoader) {
		this.useResourceLoader = useResourceLoader;
	}

	/**
	 * Adds an argument.
	 * 
	 * @param arg
	 *            the argument
	 */
	public void addArg(String arg) {
		log.info(arg);
		args.add(arg);
	}

	/**
	 * Sets the grammar.
	 * 
	 * @param grammarName
	 *            name of grammar.
	 */
	public void setGrammar(String grammarName) {
		log.info("grammar : " + grammarName);
		this.grammar = grammarName;
	}

	@Override
	protected void checkConfigurationInternal(Issues issues) {
		if (grammar == null) {
			issues.addError("No grammar specified");
		}
	}

	@Override
	protected void invokeInternal(WorkflowContext arg0, ProgressMonitor arg1, Issues arg2) {
		String grammarFile = grammar;
		if (useResourceLoader) {
			try {
				URI uri = ResourceLoaderFactory.createResourceLoader().getResource(grammar).toURI();
				grammarFile = new File(uri).getAbsolutePath();
			}
			catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		args.add(0, grammarFile);
		String rgs = "";
		for (String arg : args) {
			rgs += arg + " ";
		}
		log.info("starting Antlr with arguments : " + rgs);
		org.antlr.Tool antlr = new org.antlr.Tool(args.toArray(new String[args.size()]));
		antlr.process();
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getComponentName()
	 */
	public String getComponentName() {
		return COMPONENT_NAME;
	}
}
