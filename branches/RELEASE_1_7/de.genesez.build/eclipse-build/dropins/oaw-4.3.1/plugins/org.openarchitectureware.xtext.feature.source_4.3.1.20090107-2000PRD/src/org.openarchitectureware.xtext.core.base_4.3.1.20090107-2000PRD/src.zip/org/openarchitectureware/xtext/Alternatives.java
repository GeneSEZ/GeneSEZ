/**
 * <copyright>
 * </copyright>
 *
 * $Id: Alternatives.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Alternatives</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.Alternatives#getAlternatives <em>Alternatives</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getAlternatives()
 * @model
 * @generated
 */
public interface Alternatives extends AbstractToken {
	/**
	 * Returns the value of the '<em><b>Alternatives</b></em>' containment reference list.
	 * The list contents are of type {@link org.openarchitectureware.xtext.Element}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Alternatives</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Alternatives</em>' containment reference list.
	 * @see org.openarchitectureware.xtext.XtextPackage#getAlternatives_Alternatives()
	 * @model containment="true"
	 * @generated
	 */
	EList<Element> getAlternatives();

} // Alternatives
