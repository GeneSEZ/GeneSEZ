/**
 * <copyright>
 * </copyright>
 *
 * $Id: XtextFileImpl.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.openarchitectureware.xtext.Import;
import org.openarchitectureware.xtext.MetamodelImport;
import org.openarchitectureware.xtext.Rule;
import org.openarchitectureware.xtext.XtextFile;
import org.openarchitectureware.xtext.XtextPackage;


/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>File</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.impl.XtextFileImpl#getImports <em>Imports</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.impl.XtextFileImpl#getMmImports <em>Mm Imports</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.impl.XtextFileImpl#isCommentsDisabledFlag <em>Comments Disabled Flag</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.impl.XtextFileImpl#getName <em>Name</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.impl.XtextFileImpl#getNsURI <em>Ns URI</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.impl.XtextFileImpl#getRules <em>Rules</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.impl.XtextFileImpl#isPreventMMGeneration <em>Prevent MM Generation</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class XtextFileImpl extends EObjectImpl implements XtextFile {
	/**
	 * The cached value of the '{@link #getImports() <em>Imports</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImports()
	 * @generated
	 * @ordered
	 */
	protected EList<Import> imports;

	/**
	 * The cached value of the '{@link #getMmImports() <em>Mm Imports</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMmImports()
	 * @generated
	 * @ordered
	 */
	protected EList<MetamodelImport> mmImports;

	/**
	 * The default value of the '{@link #isCommentsDisabledFlag() <em>Comments Disabled Flag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isCommentsDisabledFlag()
	 * @generated
	 * @ordered
	 */
	protected static final boolean COMMENTS_DISABLED_FLAG_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isCommentsDisabledFlag() <em>Comments Disabled Flag</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isCommentsDisabledFlag()
	 * @generated
	 * @ordered
	 */
	protected boolean commentsDisabledFlag = COMMENTS_DISABLED_FLAG_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getNsURI() <em>Ns URI</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNsURI()
	 * @generated
	 * @ordered
	 */
	protected static final String NS_URI_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getNsURI() <em>Ns URI</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNsURI()
	 * @generated
	 * @ordered
	 */
	protected String nsURI = NS_URI_EDEFAULT;

	/**
	 * The cached value of the '{@link #getRules() <em>Rules</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRules()
	 * @generated
	 * @ordered
	 */
	protected EList<Rule> rules;

	/**
	 * The default value of the '{@link #isPreventMMGeneration() <em>Prevent MM Generation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isPreventMMGeneration()
	 * @generated
	 * @ordered
	 */
	protected static final boolean PREVENT_MM_GENERATION_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isPreventMMGeneration() <em>Prevent MM Generation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isPreventMMGeneration()
	 * @generated
	 * @ordered
	 */
	protected boolean preventMMGeneration = PREVENT_MM_GENERATION_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected XtextFileImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return XtextPackage.Literals.XTEXT_FILE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Import> getImports() {
		if (imports == null) {
			imports = new EObjectContainmentEList<Import>(Import.class, this, XtextPackage.XTEXT_FILE__IMPORTS);
		}
		return imports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<MetamodelImport> getMmImports() {
		if (mmImports == null) {
			mmImports = new EObjectContainmentEList<MetamodelImport>(MetamodelImport.class, this, XtextPackage.XTEXT_FILE__MM_IMPORTS);
		}
		return mmImports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isCommentsDisabledFlag() {
		return commentsDisabledFlag;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCommentsDisabledFlag(boolean newCommentsDisabledFlag) {
		boolean oldCommentsDisabledFlag = commentsDisabledFlag;
		commentsDisabledFlag = newCommentsDisabledFlag;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, XtextPackage.XTEXT_FILE__COMMENTS_DISABLED_FLAG, oldCommentsDisabledFlag, commentsDisabledFlag));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, XtextPackage.XTEXT_FILE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getNsURI() {
		return nsURI;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNsURI(String newNsURI) {
		String oldNsURI = nsURI;
		nsURI = newNsURI;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, XtextPackage.XTEXT_FILE__NS_URI, oldNsURI, nsURI));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Rule> getRules() {
		if (rules == null) {
			rules = new EObjectContainmentEList<Rule>(Rule.class, this, XtextPackage.XTEXT_FILE__RULES);
		}
		return rules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isPreventMMGeneration() {
		return preventMMGeneration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPreventMMGeneration(boolean newPreventMMGeneration) {
		boolean oldPreventMMGeneration = preventMMGeneration;
		preventMMGeneration = newPreventMMGeneration;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, XtextPackage.XTEXT_FILE__PREVENT_MM_GENERATION, oldPreventMMGeneration, preventMMGeneration));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case XtextPackage.XTEXT_FILE__IMPORTS:
				return ((InternalEList<?>)getImports()).basicRemove(otherEnd, msgs);
			case XtextPackage.XTEXT_FILE__MM_IMPORTS:
				return ((InternalEList<?>)getMmImports()).basicRemove(otherEnd, msgs);
			case XtextPackage.XTEXT_FILE__RULES:
				return ((InternalEList<?>)getRules()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case XtextPackage.XTEXT_FILE__IMPORTS:
				return getImports();
			case XtextPackage.XTEXT_FILE__MM_IMPORTS:
				return getMmImports();
			case XtextPackage.XTEXT_FILE__COMMENTS_DISABLED_FLAG:
				return isCommentsDisabledFlag() ? Boolean.TRUE : Boolean.FALSE;
			case XtextPackage.XTEXT_FILE__NAME:
				return getName();
			case XtextPackage.XTEXT_FILE__NS_URI:
				return getNsURI();
			case XtextPackage.XTEXT_FILE__RULES:
				return getRules();
			case XtextPackage.XTEXT_FILE__PREVENT_MM_GENERATION:
				return isPreventMMGeneration() ? Boolean.TRUE : Boolean.FALSE;
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case XtextPackage.XTEXT_FILE__IMPORTS:
				getImports().clear();
				getImports().addAll((Collection<? extends Import>)newValue);
				return;
			case XtextPackage.XTEXT_FILE__MM_IMPORTS:
				getMmImports().clear();
				getMmImports().addAll((Collection<? extends MetamodelImport>)newValue);
				return;
			case XtextPackage.XTEXT_FILE__COMMENTS_DISABLED_FLAG:
				setCommentsDisabledFlag(((Boolean)newValue).booleanValue());
				return;
			case XtextPackage.XTEXT_FILE__NAME:
				setName((String)newValue);
				return;
			case XtextPackage.XTEXT_FILE__NS_URI:
				setNsURI((String)newValue);
				return;
			case XtextPackage.XTEXT_FILE__RULES:
				getRules().clear();
				getRules().addAll((Collection<? extends Rule>)newValue);
				return;
			case XtextPackage.XTEXT_FILE__PREVENT_MM_GENERATION:
				setPreventMMGeneration(((Boolean)newValue).booleanValue());
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case XtextPackage.XTEXT_FILE__IMPORTS:
				getImports().clear();
				return;
			case XtextPackage.XTEXT_FILE__MM_IMPORTS:
				getMmImports().clear();
				return;
			case XtextPackage.XTEXT_FILE__COMMENTS_DISABLED_FLAG:
				setCommentsDisabledFlag(COMMENTS_DISABLED_FLAG_EDEFAULT);
				return;
			case XtextPackage.XTEXT_FILE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case XtextPackage.XTEXT_FILE__NS_URI:
				setNsURI(NS_URI_EDEFAULT);
				return;
			case XtextPackage.XTEXT_FILE__RULES:
				getRules().clear();
				return;
			case XtextPackage.XTEXT_FILE__PREVENT_MM_GENERATION:
				setPreventMMGeneration(PREVENT_MM_GENERATION_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case XtextPackage.XTEXT_FILE__IMPORTS:
				return imports != null && !imports.isEmpty();
			case XtextPackage.XTEXT_FILE__MM_IMPORTS:
				return mmImports != null && !mmImports.isEmpty();
			case XtextPackage.XTEXT_FILE__COMMENTS_DISABLED_FLAG:
				return commentsDisabledFlag != COMMENTS_DISABLED_FLAG_EDEFAULT;
			case XtextPackage.XTEXT_FILE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case XtextPackage.XTEXT_FILE__NS_URI:
				return NS_URI_EDEFAULT == null ? nsURI != null : !NS_URI_EDEFAULT.equals(nsURI);
			case XtextPackage.XTEXT_FILE__RULES:
				return rules != null && !rules.isEmpty();
			case XtextPackage.XTEXT_FILE__PREVENT_MM_GENERATION:
				return preventMMGeneration != PREVENT_MM_GENERATION_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (commentsDisabledFlag: ");
		result.append(commentsDisabledFlag);
		result.append(", name: ");
		result.append(name);
		result.append(", nsURI: ");
		result.append(nsURI);
		result.append(", preventMMGeneration: ");
		result.append(preventMMGeneration);
		result.append(')');
		return result.toString();
	}

} //XtextFileImpl
