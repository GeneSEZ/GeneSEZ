/**
 * <copyright>
 * </copyright>
 *
 * $Id: XtextPackage.java,v 1.4 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.openarchitectureware.xtext.XtextFactory
 * @model kind="package"
 * @generated
 */
public interface XtextPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "xtext";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.openarchitectureware.org/xtext";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "org.openarchitectureware.xtext";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	XtextPackage eINSTANCE = org.openarchitectureware.xtext.impl.XtextPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.XtextFileImpl <em>File</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.XtextFileImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getXtextFile()
	 * @generated
	 */
	int XTEXT_FILE = 0;

	/**
	 * The feature id for the '<em><b>Imports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int XTEXT_FILE__IMPORTS = 0;

	/**
	 * The feature id for the '<em><b>Mm Imports</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int XTEXT_FILE__MM_IMPORTS = 1;

	/**
	 * The feature id for the '<em><b>Comments Disabled Flag</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int XTEXT_FILE__COMMENTS_DISABLED_FLAG = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int XTEXT_FILE__NAME = 3;

	/**
	 * The feature id for the '<em><b>Ns URI</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int XTEXT_FILE__NS_URI = 4;

	/**
	 * The feature id for the '<em><b>Rules</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int XTEXT_FILE__RULES = 5;

	/**
	 * The feature id for the '<em><b>Prevent MM Generation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int XTEXT_FILE__PREVENT_MM_GENERATION = 6;

	/**
	 * The number of structural features of the '<em>File</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int XTEXT_FILE_FEATURE_COUNT = 7;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.RuleImpl <em>Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.RuleImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getRule()
	 * @generated
	 */
	int RULE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE__NAME = 0;

	/**
	 * The number of structural features of the '<em>Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.NativeLexerRuleImpl <em>Native Lexer Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.NativeLexerRuleImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getNativeLexerRule()
	 * @generated
	 */
	int NATIVE_LEXER_RULE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATIVE_LEXER_RULE__NAME = RULE__NAME;

	/**
	 * The feature id for the '<em><b>Impl</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATIVE_LEXER_RULE__IMPL = RULE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Native Lexer Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NATIVE_LEXER_RULE_FEATURE_COUNT = RULE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.RuleWithTypeImpl <em>Rule With Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.RuleWithTypeImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getRuleWithType()
	 * @generated
	 */
	int RULE_WITH_TYPE = 19;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_WITH_TYPE__NAME = RULE__NAME;

	/**
	 * The feature id for the '<em><b>Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_WITH_TYPE__TYPE = RULE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Rule With Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_WITH_TYPE_FEATURE_COUNT = RULE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.TypeRuleImpl <em>Type Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.TypeRuleImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getTypeRule()
	 * @generated
	 */
	int TYPE_RULE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TYPE_RULE__NAME = RULE_WITH_TYPE__NAME;

	/**
	 * The feature id for the '<em><b>Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TYPE_RULE__TYPE = RULE_WITH_TYPE__TYPE;

	/**
	 * The feature id for the '<em><b>Content</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TYPE_RULE__CONTENT = RULE_WITH_TYPE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Extends</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TYPE_RULE__EXTENDS = RULE_WITH_TYPE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Type Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TYPE_RULE_FEATURE_COUNT = RULE_WITH_TYPE_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.TypeNameImpl <em>Type Name</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.TypeNameImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getTypeName()
	 * @generated
	 */
	int TYPE_NAME = 4;

	/**
	 * The feature id for the '<em><b>Alias</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TYPE_NAME__ALIAS = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TYPE_NAME__NAME = 1;

	/**
	 * The number of structural features of the '<em>Type Name</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TYPE_NAME_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.StringRuleImpl <em>String Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.StringRuleImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getStringRule()
	 * @generated
	 */
	int STRING_RULE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_RULE__NAME = RULE__NAME;

	/**
	 * The feature id for the '<em><b>Content</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_RULE__CONTENT = RULE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>String Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRING_RULE_FEATURE_COUNT = RULE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.EnumRuleImpl <em>Enum Rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.EnumRuleImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getEnumRule()
	 * @generated
	 */
	int ENUM_RULE = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUM_RULE__NAME = RULE_WITH_TYPE__NAME;

	/**
	 * The feature id for the '<em><b>Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUM_RULE__TYPE = RULE_WITH_TYPE__TYPE;

	/**
	 * The feature id for the '<em><b>Literals</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUM_RULE__LITERALS = RULE_WITH_TYPE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Enum Rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUM_RULE_FEATURE_COUNT = RULE_WITH_TYPE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.ElementImpl <em>Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.ElementImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getElement()
	 * @generated
	 */
	int ELEMENT = 8;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__CARDINALITY = 0;

	/**
	 * The number of structural features of the '<em>Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_FEATURE_COUNT = 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.AbstractTokenImpl <em>Abstract Token</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.AbstractTokenImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getAbstractToken()
	 * @generated
	 */
	int ABSTRACT_TOKEN = 12;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_TOKEN__CARDINALITY = ELEMENT__CARDINALITY;

	/**
	 * The number of structural features of the '<em>Abstract Token</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_TOKEN_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.EnumLiteralImpl <em>Enum Literal</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.EnumLiteralImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getEnumLiteral()
	 * @generated
	 */
	int ENUM_LITERAL = 7;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUM_LITERAL__CARDINALITY = ABSTRACT_TOKEN__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Keyword</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUM_LITERAL__KEYWORD = ABSTRACT_TOKEN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUM_LITERAL__NAME = ABSTRACT_TOKEN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Enum Literal</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENUM_LITERAL_FEATURE_COUNT = ABSTRACT_TOKEN_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.GroupImpl <em>Group</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.GroupImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getGroup()
	 * @generated
	 */
	int GROUP = 9;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GROUP__CARDINALITY = ELEMENT__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GROUP__CHILDREN = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Group</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GROUP_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.AlternativesImpl <em>Alternatives</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.AlternativesImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getAlternatives()
	 * @generated
	 */
	int ALTERNATIVES = 10;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVES__CARDINALITY = ABSTRACT_TOKEN__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Alternatives</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVES__ALTERNATIVES = ABSTRACT_TOKEN_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Alternatives</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALTERNATIVES_FEATURE_COUNT = ABSTRACT_TOKEN_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.AssignmentImpl <em>Assignment</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.AssignmentImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getAssignment()
	 * @generated
	 */
	int ASSIGNMENT = 11;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSIGNMENT__CARDINALITY = ELEMENT__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Feature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSIGNMENT__FEATURE = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Token</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSIGNMENT__TOKEN = ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Operator</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSIGNMENT__OPERATOR = ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Assignment</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ASSIGNMENT_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.RuleNameImpl <em>Rule Name</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.RuleNameImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getRuleName()
	 * @generated
	 */
	int RULE_NAME = 13;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_NAME__CARDINALITY = ABSTRACT_TOKEN__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_NAME__NAME = ABSTRACT_TOKEN_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Rule Name</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RULE_NAME_FEATURE_COUNT = ABSTRACT_TOKEN_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.KeywordImpl <em>Keyword</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.KeywordImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getKeyword()
	 * @generated
	 */
	int KEYWORD = 14;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KEYWORD__CARDINALITY = ABSTRACT_TOKEN__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KEYWORD__VALUE = ABSTRACT_TOKEN_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Keyword</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int KEYWORD_FEATURE_COUNT = ABSTRACT_TOKEN_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.CrossReferenceImpl <em>Cross Reference</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.CrossReferenceImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getCrossReference()
	 * @generated
	 */
	int CROSS_REFERENCE = 15;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROSS_REFERENCE__CARDINALITY = ABSTRACT_TOKEN__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Feature</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROSS_REFERENCE__FEATURE = ABSTRACT_TOKEN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Rule Name</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROSS_REFERENCE__RULE_NAME = ABSTRACT_TOKEN_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Type</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROSS_REFERENCE__TYPE = ABSTRACT_TOKEN_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Cross Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CROSS_REFERENCE_FEATURE_COUNT = ABSTRACT_TOKEN_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.FileRefImpl <em>File Ref</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.FileRefImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getFileRef()
	 * @generated
	 */
	int FILE_REF = 16;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_REF__CARDINALITY = ABSTRACT_TOKEN__CARDINALITY;

	/**
	 * The number of structural features of the '<em>File Ref</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FILE_REF_FEATURE_COUNT = ABSTRACT_TOKEN_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.ImportImpl <em>Import</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.ImportImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getImport()
	 * @generated
	 */
	int IMPORT = 17;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMPORT__CARDINALITY = ABSTRACT_TOKEN__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMPORT__LOCATION = ABSTRACT_TOKEN_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Import</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMPORT_FEATURE_COUNT = ABSTRACT_TOKEN_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.impl.MetamodelImportImpl <em>Metamodel Import</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.impl.MetamodelImportImpl
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getMetamodelImport()
	 * @generated
	 */
	int METAMODEL_IMPORT = 18;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL_IMPORT__CARDINALITY = ABSTRACT_TOKEN__CARDINALITY;

	/**
	 * The feature id for the '<em><b>Location</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL_IMPORT__LOCATION = ABSTRACT_TOKEN_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Alias</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL_IMPORT__ALIAS = ABSTRACT_TOKEN_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Metamodel Import</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METAMODEL_IMPORT_FEATURE_COUNT = ABSTRACT_TOKEN_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.AssignOperator <em>Assign Operator</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.AssignOperator
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getAssignOperator()
	 * @generated
	 */
	int ASSIGN_OPERATOR = 20;

	/**
	 * The meta object id for the '{@link org.openarchitectureware.xtext.CardinalityType <em>Cardinality Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.openarchitectureware.xtext.CardinalityType
	 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getCardinalityType()
	 * @generated
	 */
	int CARDINALITY_TYPE = 21;


	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.XtextFile <em>File</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>File</em>'.
	 * @see org.openarchitectureware.xtext.XtextFile
	 * @generated
	 */
	EClass getXtextFile();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.XtextFile#getImports <em>Imports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Imports</em>'.
	 * @see org.openarchitectureware.xtext.XtextFile#getImports()
	 * @see #getXtextFile()
	 * @generated
	 */
	EReference getXtextFile_Imports();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.XtextFile#getMmImports <em>Mm Imports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Mm Imports</em>'.
	 * @see org.openarchitectureware.xtext.XtextFile#getMmImports()
	 * @see #getXtextFile()
	 * @generated
	 */
	EReference getXtextFile_MmImports();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.XtextFile#isCommentsDisabledFlag <em>Comments Disabled Flag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Comments Disabled Flag</em>'.
	 * @see org.openarchitectureware.xtext.XtextFile#isCommentsDisabledFlag()
	 * @see #getXtextFile()
	 * @generated
	 */
	EAttribute getXtextFile_CommentsDisabledFlag();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.XtextFile#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.openarchitectureware.xtext.XtextFile#getName()
	 * @see #getXtextFile()
	 * @generated
	 */
	EAttribute getXtextFile_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.XtextFile#getNsURI <em>Ns URI</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ns URI</em>'.
	 * @see org.openarchitectureware.xtext.XtextFile#getNsURI()
	 * @see #getXtextFile()
	 * @generated
	 */
	EAttribute getXtextFile_NsURI();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.XtextFile#getRules <em>Rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Rules</em>'.
	 * @see org.openarchitectureware.xtext.XtextFile#getRules()
	 * @see #getXtextFile()
	 * @generated
	 */
	EReference getXtextFile_Rules();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.XtextFile#isPreventMMGeneration <em>Prevent MM Generation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Prevent MM Generation</em>'.
	 * @see org.openarchitectureware.xtext.XtextFile#isPreventMMGeneration()
	 * @see #getXtextFile()
	 * @generated
	 */
	EAttribute getXtextFile_PreventMMGeneration();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.Rule <em>Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rule</em>'.
	 * @see org.openarchitectureware.xtext.Rule
	 * @generated
	 */
	EClass getRule();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.Rule#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.openarchitectureware.xtext.Rule#getName()
	 * @see #getRule()
	 * @generated
	 */
	EAttribute getRule_Name();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.NativeLexerRule <em>Native Lexer Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Native Lexer Rule</em>'.
	 * @see org.openarchitectureware.xtext.NativeLexerRule
	 * @generated
	 */
	EClass getNativeLexerRule();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.NativeLexerRule#getImpl <em>Impl</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Impl</em>'.
	 * @see org.openarchitectureware.xtext.NativeLexerRule#getImpl()
	 * @see #getNativeLexerRule()
	 * @generated
	 */
	EAttribute getNativeLexerRule_Impl();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.TypeRule <em>Type Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Type Rule</em>'.
	 * @see org.openarchitectureware.xtext.TypeRule
	 * @generated
	 */
	EClass getTypeRule();

	/**
	 * Returns the meta object for the containment reference '{@link org.openarchitectureware.xtext.TypeRule#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Content</em>'.
	 * @see org.openarchitectureware.xtext.TypeRule#getContent()
	 * @see #getTypeRule()
	 * @generated
	 */
	EReference getTypeRule_Content();

	/**
	 * Returns the meta object for the attribute list '{@link org.openarchitectureware.xtext.TypeRule#getExtends <em>Extends</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Extends</em>'.
	 * @see org.openarchitectureware.xtext.TypeRule#getExtends()
	 * @see #getTypeRule()
	 * @generated
	 */
	EAttribute getTypeRule_Extends();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.TypeName <em>Type Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Type Name</em>'.
	 * @see org.openarchitectureware.xtext.TypeName
	 * @generated
	 */
	EClass getTypeName();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.TypeName#getAlias <em>Alias</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Alias</em>'.
	 * @see org.openarchitectureware.xtext.TypeName#getAlias()
	 * @see #getTypeName()
	 * @generated
	 */
	EAttribute getTypeName_Alias();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.TypeName#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.openarchitectureware.xtext.TypeName#getName()
	 * @see #getTypeName()
	 * @generated
	 */
	EAttribute getTypeName_Name();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.StringRule <em>String Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>String Rule</em>'.
	 * @see org.openarchitectureware.xtext.StringRule
	 * @generated
	 */
	EClass getStringRule();

	/**
	 * Returns the meta object for the containment reference '{@link org.openarchitectureware.xtext.StringRule#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Content</em>'.
	 * @see org.openarchitectureware.xtext.StringRule#getContent()
	 * @see #getStringRule()
	 * @generated
	 */
	EReference getStringRule_Content();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.EnumRule <em>Enum Rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enum Rule</em>'.
	 * @see org.openarchitectureware.xtext.EnumRule
	 * @generated
	 */
	EClass getEnumRule();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.EnumRule#getLiterals <em>Literals</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Literals</em>'.
	 * @see org.openarchitectureware.xtext.EnumRule#getLiterals()
	 * @see #getEnumRule()
	 * @generated
	 */
	EReference getEnumRule_Literals();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.EnumLiteral <em>Enum Literal</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enum Literal</em>'.
	 * @see org.openarchitectureware.xtext.EnumLiteral
	 * @generated
	 */
	EClass getEnumLiteral();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.EnumLiteral#getKeyword <em>Keyword</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Keyword</em>'.
	 * @see org.openarchitectureware.xtext.EnumLiteral#getKeyword()
	 * @see #getEnumLiteral()
	 * @generated
	 */
	EAttribute getEnumLiteral_Keyword();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.EnumLiteral#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.openarchitectureware.xtext.EnumLiteral#getName()
	 * @see #getEnumLiteral()
	 * @generated
	 */
	EAttribute getEnumLiteral_Name();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.Element <em>Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Element</em>'.
	 * @see org.openarchitectureware.xtext.Element
	 * @generated
	 */
	EClass getElement();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.Element#getCardinality <em>Cardinality</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cardinality</em>'.
	 * @see org.openarchitectureware.xtext.Element#getCardinality()
	 * @see #getElement()
	 * @generated
	 */
	EAttribute getElement_Cardinality();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.Group <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Group</em>'.
	 * @see org.openarchitectureware.xtext.Group
	 * @generated
	 */
	EClass getGroup();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.Group#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Children</em>'.
	 * @see org.openarchitectureware.xtext.Group#getChildren()
	 * @see #getGroup()
	 * @generated
	 */
	EReference getGroup_Children();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.Alternatives <em>Alternatives</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Alternatives</em>'.
	 * @see org.openarchitectureware.xtext.Alternatives
	 * @generated
	 */
	EClass getAlternatives();

	/**
	 * Returns the meta object for the containment reference list '{@link org.openarchitectureware.xtext.Alternatives#getAlternatives <em>Alternatives</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Alternatives</em>'.
	 * @see org.openarchitectureware.xtext.Alternatives#getAlternatives()
	 * @see #getAlternatives()
	 * @generated
	 */
	EReference getAlternatives_Alternatives();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.Assignment <em>Assignment</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Assignment</em>'.
	 * @see org.openarchitectureware.xtext.Assignment
	 * @generated
	 */
	EClass getAssignment();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.Assignment#getFeature <em>Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Feature</em>'.
	 * @see org.openarchitectureware.xtext.Assignment#getFeature()
	 * @see #getAssignment()
	 * @generated
	 */
	EAttribute getAssignment_Feature();

	/**
	 * Returns the meta object for the containment reference '{@link org.openarchitectureware.xtext.Assignment#getToken <em>Token</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Token</em>'.
	 * @see org.openarchitectureware.xtext.Assignment#getToken()
	 * @see #getAssignment()
	 * @generated
	 */
	EReference getAssignment_Token();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.Assignment#getOperator <em>Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Operator</em>'.
	 * @see org.openarchitectureware.xtext.Assignment#getOperator()
	 * @see #getAssignment()
	 * @generated
	 */
	EAttribute getAssignment_Operator();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.AbstractToken <em>Abstract Token</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Token</em>'.
	 * @see org.openarchitectureware.xtext.AbstractToken
	 * @generated
	 */
	EClass getAbstractToken();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.RuleName <em>Rule Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rule Name</em>'.
	 * @see org.openarchitectureware.xtext.RuleName
	 * @generated
	 */
	EClass getRuleName();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.RuleName#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.openarchitectureware.xtext.RuleName#getName()
	 * @see #getRuleName()
	 * @generated
	 */
	EAttribute getRuleName_Name();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.Keyword <em>Keyword</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Keyword</em>'.
	 * @see org.openarchitectureware.xtext.Keyword
	 * @generated
	 */
	EClass getKeyword();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.Keyword#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see org.openarchitectureware.xtext.Keyword#getValue()
	 * @see #getKeyword()
	 * @generated
	 */
	EAttribute getKeyword_Value();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.CrossReference <em>Cross Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cross Reference</em>'.
	 * @see org.openarchitectureware.xtext.CrossReference
	 * @generated
	 */
	EClass getCrossReference();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.CrossReference#getFeature <em>Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Feature</em>'.
	 * @see org.openarchitectureware.xtext.CrossReference#getFeature()
	 * @see #getCrossReference()
	 * @generated
	 */
	EAttribute getCrossReference_Feature();

	/**
	 * Returns the meta object for the containment reference '{@link org.openarchitectureware.xtext.CrossReference#getRuleName <em>Rule Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Rule Name</em>'.
	 * @see org.openarchitectureware.xtext.CrossReference#getRuleName()
	 * @see #getCrossReference()
	 * @generated
	 */
	EReference getCrossReference_RuleName();

	/**
	 * Returns the meta object for the containment reference '{@link org.openarchitectureware.xtext.CrossReference#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Type</em>'.
	 * @see org.openarchitectureware.xtext.CrossReference#getType()
	 * @see #getCrossReference()
	 * @generated
	 */
	EReference getCrossReference_Type();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.FileRef <em>File Ref</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>File Ref</em>'.
	 * @see org.openarchitectureware.xtext.FileRef
	 * @generated
	 */
	EClass getFileRef();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.Import <em>Import</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Import</em>'.
	 * @see org.openarchitectureware.xtext.Import
	 * @generated
	 */
	EClass getImport();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.Import#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see org.openarchitectureware.xtext.Import#getLocation()
	 * @see #getImport()
	 * @generated
	 */
	EAttribute getImport_Location();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.MetamodelImport <em>Metamodel Import</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Metamodel Import</em>'.
	 * @see org.openarchitectureware.xtext.MetamodelImport
	 * @generated
	 */
	EClass getMetamodelImport();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.MetamodelImport#getLocation <em>Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location</em>'.
	 * @see org.openarchitectureware.xtext.MetamodelImport#getLocation()
	 * @see #getMetamodelImport()
	 * @generated
	 */
	EAttribute getMetamodelImport_Location();

	/**
	 * Returns the meta object for the attribute '{@link org.openarchitectureware.xtext.MetamodelImport#getAlias <em>Alias</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Alias</em>'.
	 * @see org.openarchitectureware.xtext.MetamodelImport#getAlias()
	 * @see #getMetamodelImport()
	 * @generated
	 */
	EAttribute getMetamodelImport_Alias();

	/**
	 * Returns the meta object for class '{@link org.openarchitectureware.xtext.RuleWithType <em>Rule With Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rule With Type</em>'.
	 * @see org.openarchitectureware.xtext.RuleWithType
	 * @generated
	 */
	EClass getRuleWithType();

	/**
	 * Returns the meta object for the containment reference '{@link org.openarchitectureware.xtext.RuleWithType#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Type</em>'.
	 * @see org.openarchitectureware.xtext.RuleWithType#getType()
	 * @see #getRuleWithType()
	 * @generated
	 */
	EReference getRuleWithType_Type();

	/**
	 * Returns the meta object for enum '{@link org.openarchitectureware.xtext.AssignOperator <em>Assign Operator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Assign Operator</em>'.
	 * @see org.openarchitectureware.xtext.AssignOperator
	 * @generated
	 */
	EEnum getAssignOperator();

	/**
	 * Returns the meta object for enum '{@link org.openarchitectureware.xtext.CardinalityType <em>Cardinality Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Cardinality Type</em>'.
	 * @see org.openarchitectureware.xtext.CardinalityType
	 * @generated
	 */
	EEnum getCardinalityType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	XtextFactory getXtextFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.XtextFileImpl <em>File</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.XtextFileImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getXtextFile()
		 * @generated
		 */
		EClass XTEXT_FILE = eINSTANCE.getXtextFile();

		/**
		 * The meta object literal for the '<em><b>Imports</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference XTEXT_FILE__IMPORTS = eINSTANCE.getXtextFile_Imports();

		/**
		 * The meta object literal for the '<em><b>Mm Imports</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference XTEXT_FILE__MM_IMPORTS = eINSTANCE.getXtextFile_MmImports();

		/**
		 * The meta object literal for the '<em><b>Comments Disabled Flag</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute XTEXT_FILE__COMMENTS_DISABLED_FLAG = eINSTANCE.getXtextFile_CommentsDisabledFlag();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute XTEXT_FILE__NAME = eINSTANCE.getXtextFile_Name();

		/**
		 * The meta object literal for the '<em><b>Ns URI</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute XTEXT_FILE__NS_URI = eINSTANCE.getXtextFile_NsURI();

		/**
		 * The meta object literal for the '<em><b>Rules</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference XTEXT_FILE__RULES = eINSTANCE.getXtextFile_Rules();

		/**
		 * The meta object literal for the '<em><b>Prevent MM Generation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute XTEXT_FILE__PREVENT_MM_GENERATION = eINSTANCE.getXtextFile_PreventMMGeneration();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.RuleImpl <em>Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.RuleImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getRule()
		 * @generated
		 */
		EClass RULE = eINSTANCE.getRule();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RULE__NAME = eINSTANCE.getRule_Name();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.NativeLexerRuleImpl <em>Native Lexer Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.NativeLexerRuleImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getNativeLexerRule()
		 * @generated
		 */
		EClass NATIVE_LEXER_RULE = eINSTANCE.getNativeLexerRule();

		/**
		 * The meta object literal for the '<em><b>Impl</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NATIVE_LEXER_RULE__IMPL = eINSTANCE.getNativeLexerRule_Impl();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.TypeRuleImpl <em>Type Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.TypeRuleImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getTypeRule()
		 * @generated
		 */
		EClass TYPE_RULE = eINSTANCE.getTypeRule();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TYPE_RULE__CONTENT = eINSTANCE.getTypeRule_Content();

		/**
		 * The meta object literal for the '<em><b>Extends</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TYPE_RULE__EXTENDS = eINSTANCE.getTypeRule_Extends();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.TypeNameImpl <em>Type Name</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.TypeNameImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getTypeName()
		 * @generated
		 */
		EClass TYPE_NAME = eINSTANCE.getTypeName();

		/**
		 * The meta object literal for the '<em><b>Alias</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TYPE_NAME__ALIAS = eINSTANCE.getTypeName_Alias();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TYPE_NAME__NAME = eINSTANCE.getTypeName_Name();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.StringRuleImpl <em>String Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.StringRuleImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getStringRule()
		 * @generated
		 */
		EClass STRING_RULE = eINSTANCE.getStringRule();

		/**
		 * The meta object literal for the '<em><b>Content</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STRING_RULE__CONTENT = eINSTANCE.getStringRule_Content();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.EnumRuleImpl <em>Enum Rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.EnumRuleImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getEnumRule()
		 * @generated
		 */
		EClass ENUM_RULE = eINSTANCE.getEnumRule();

		/**
		 * The meta object literal for the '<em><b>Literals</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENUM_RULE__LITERALS = eINSTANCE.getEnumRule_Literals();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.EnumLiteralImpl <em>Enum Literal</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.EnumLiteralImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getEnumLiteral()
		 * @generated
		 */
		EClass ENUM_LITERAL = eINSTANCE.getEnumLiteral();

		/**
		 * The meta object literal for the '<em><b>Keyword</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUM_LITERAL__KEYWORD = eINSTANCE.getEnumLiteral_Keyword();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENUM_LITERAL__NAME = eINSTANCE.getEnumLiteral_Name();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.ElementImpl <em>Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.ElementImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getElement()
		 * @generated
		 */
		EClass ELEMENT = eINSTANCE.getElement();

		/**
		 * The meta object literal for the '<em><b>Cardinality</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENT__CARDINALITY = eINSTANCE.getElement_Cardinality();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.GroupImpl <em>Group</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.GroupImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getGroup()
		 * @generated
		 */
		EClass GROUP = eINSTANCE.getGroup();

		/**
		 * The meta object literal for the '<em><b>Children</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GROUP__CHILDREN = eINSTANCE.getGroup_Children();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.AlternativesImpl <em>Alternatives</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.AlternativesImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getAlternatives()
		 * @generated
		 */
		EClass ALTERNATIVES = eINSTANCE.getAlternatives();

		/**
		 * The meta object literal for the '<em><b>Alternatives</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ALTERNATIVES__ALTERNATIVES = eINSTANCE.getAlternatives_Alternatives();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.AssignmentImpl <em>Assignment</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.AssignmentImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getAssignment()
		 * @generated
		 */
		EClass ASSIGNMENT = eINSTANCE.getAssignment();

		/**
		 * The meta object literal for the '<em><b>Feature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSIGNMENT__FEATURE = eINSTANCE.getAssignment_Feature();

		/**
		 * The meta object literal for the '<em><b>Token</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ASSIGNMENT__TOKEN = eINSTANCE.getAssignment_Token();

		/**
		 * The meta object literal for the '<em><b>Operator</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ASSIGNMENT__OPERATOR = eINSTANCE.getAssignment_Operator();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.AbstractTokenImpl <em>Abstract Token</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.AbstractTokenImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getAbstractToken()
		 * @generated
		 */
		EClass ABSTRACT_TOKEN = eINSTANCE.getAbstractToken();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.RuleNameImpl <em>Rule Name</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.RuleNameImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getRuleName()
		 * @generated
		 */
		EClass RULE_NAME = eINSTANCE.getRuleName();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute RULE_NAME__NAME = eINSTANCE.getRuleName_Name();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.KeywordImpl <em>Keyword</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.KeywordImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getKeyword()
		 * @generated
		 */
		EClass KEYWORD = eINSTANCE.getKeyword();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute KEYWORD__VALUE = eINSTANCE.getKeyword_Value();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.CrossReferenceImpl <em>Cross Reference</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.CrossReferenceImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getCrossReference()
		 * @generated
		 */
		EClass CROSS_REFERENCE = eINSTANCE.getCrossReference();

		/**
		 * The meta object literal for the '<em><b>Feature</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CROSS_REFERENCE__FEATURE = eINSTANCE.getCrossReference_Feature();

		/**
		 * The meta object literal for the '<em><b>Rule Name</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CROSS_REFERENCE__RULE_NAME = eINSTANCE.getCrossReference_RuleName();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CROSS_REFERENCE__TYPE = eINSTANCE.getCrossReference_Type();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.FileRefImpl <em>File Ref</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.FileRefImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getFileRef()
		 * @generated
		 */
		EClass FILE_REF = eINSTANCE.getFileRef();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.ImportImpl <em>Import</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.ImportImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getImport()
		 * @generated
		 */
		EClass IMPORT = eINSTANCE.getImport();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IMPORT__LOCATION = eINSTANCE.getImport_Location();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.MetamodelImportImpl <em>Metamodel Import</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.MetamodelImportImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getMetamodelImport()
		 * @generated
		 */
		EClass METAMODEL_IMPORT = eINSTANCE.getMetamodelImport();

		/**
		 * The meta object literal for the '<em><b>Location</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METAMODEL_IMPORT__LOCATION = eINSTANCE.getMetamodelImport_Location();

		/**
		 * The meta object literal for the '<em><b>Alias</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METAMODEL_IMPORT__ALIAS = eINSTANCE.getMetamodelImport_Alias();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.impl.RuleWithTypeImpl <em>Rule With Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.impl.RuleWithTypeImpl
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getRuleWithType()
		 * @generated
		 */
		EClass RULE_WITH_TYPE = eINSTANCE.getRuleWithType();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RULE_WITH_TYPE__TYPE = eINSTANCE.getRuleWithType_Type();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.AssignOperator <em>Assign Operator</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.AssignOperator
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getAssignOperator()
		 * @generated
		 */
		EEnum ASSIGN_OPERATOR = eINSTANCE.getAssignOperator();

		/**
		 * The meta object literal for the '{@link org.openarchitectureware.xtext.CardinalityType <em>Cardinality Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.openarchitectureware.xtext.CardinalityType
		 * @see org.openarchitectureware.xtext.impl.XtextPackageImpl#getCardinalityType()
		 * @generated
		 */
		EEnum CARDINALITY_TYPE = eINSTANCE.getCardinalityType();

	}

} //XtextPackage
