/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext.parser.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EEnumLiteral;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.openarchitectureware.xtext.parser.TypeResolver;

/**
 * @author Bernd Kolb
 * 
 */
public class EcoreModelFactory {

	private EPackage pack;
	private final Map<String, String> importedMMs = new HashMap<String, String>(
			2);

	public EcoreModelFactory(EPackage pack) {
		this.pack = pack;
	}

	public void addImport(String alias, String location) {
		if (alias == null) {
			alias = "";
		}
		importedMMs.put(alias, location);
	}

	/**
	 */
	public EObject create(String name) {
		return create(null, name);
	}

	public EObject create(String alias, String name) {
		EClass clazz = TypeResolver.findEClass(alias, name, importedMMs);
		if (clazz != null) {
			return clazz.getEPackage().getEFactoryInstance().create(clazz);
		}
		EClassifier clzz = pack.getEClassifier(name);
		if (clzz instanceof EClass) {
			return pack.getEFactoryInstance().create((EClass) clzz);
		}
		throw new IllegalArgumentException("Unknown type "+name);
	}

	@SuppressWarnings("unchecked")
	public void add(EObject o, String featureName, Object arg, boolean useParseAdapter) {
		if (!useParseAdapter) {
			add(o, featureName, arg);
			return;
		}
		ParseStringAdapter.getAdapter(o).add(featureName, arg);
	}

	@SuppressWarnings("unchecked")
	public void add(EObject o, String featureName, Object arg) {
		if (arg==null)
			return;
		EStructuralFeature esf = featureForName(o, featureName);
		if (esf.getUpperBound() != -1)
			throw new IllegalArgumentException("The feature '" + featureName
					+ "' has no upperBound -1");
		((Collection) (o).eGet(esf)).add(arg);
	}

	private EStructuralFeature featureForName(EObject o, String featureName) {
		if (o == null)
			throw new NullPointerException("EObject");
		EClass clazz = (o).eClass();
		EStructuralFeature esf = clazz.getEStructuralFeature(featureName);
		if (esf == null)
			throw new IllegalArgumentException("The feature '" + featureName
					+ "' is not defined for type " + clazz.getName());
		return esf;
	}

	public void set(EObject o, String featureName, Object arg, boolean useParseAdapter) {
		if (!useParseAdapter) {
			set(o, featureName, arg);
			return;
		}
		ParseStringAdapter.getAdapter(o).put(featureName, arg);
	}

	public void set(EObject o, String featureName, Object arg) {
		EStructuralFeature esf = featureForName(o, featureName);
		(o).eSet(esf, arg);
	}

	/**
	 * @deprecated use {@link EcoreModelFactory#enumLit(String, String, String)}
	 *             instead
	 */
	public Object enumLit(String enumname, String litname) {
		return enumLit(null, enumname, litname);
	}

	public Enumerator enumLit(String alias, String enumname, String litname) {
		EEnum en = TypeResolver.findEEnum(alias, enumname, importedMMs);
		if (en == null) {
		EClassifier clzz = pack.getEClassifier(enumname);
		if (clzz instanceof EEnum) {
				en = (EEnum) clzz;
			}
		}
		if (en != null) {
			EEnumLiteral elit = en.getEEnumLiteral(litname);
			if (elit != null)
				return elit.getInstance();
		}
		throw new IllegalArgumentException(
				"Couldn't find Enumeration with name '" + enumname + "'.");
	}

}
