/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/

package org.openarchitectureware.xtext.parser.model;

import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.Token;
import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.ecore.EObject;
import org.openarchitectureware.xtext.parser.parsetree.Error;
import org.openarchitectureware.xtext.parser.parsetree.Node;
import org.openarchitectureware.xtext.parser.parsetree.ParsetreeFactory;

public class ParseTreeManager {

	private Node current = null;

	public ParseTreeManager() {
		// create the root.
		current = ParsetreeFactory.eINSTANCE.createNode();
		current.setLine(1);
	}

	public void invokeRule(EObject grammarElement, int line, int start) {
		Node rn = ParsetreeFactory.eINSTANCE.createNode();
		rn.setGrammarElement(grammarElement);
		rn.setLine(line);
		rn.setStart(start);
		if (current != null) {
			rn.setParent(current);
		}
		current = rn;
	}

	public void setModelElement(EObject value) {
		current.setModelElement(value);
		value.eAdapters().add(new NodeAdapter(current));
	}

	// public void setValue(Object o) {
	//		
	// }

	public <T> T ruleFinished(T o, int end) {
		current.setEnd(end);
		if (o instanceof Token) {
			current.setToken((Token) o);
		} else if (o instanceof EObject) {
			current.setModelElement((EObject) o);
		} else {

		}
		if (current.getParent() != null) {
			Node parent = (Node) current.getParent();
			getRangeAdapter(parent).add(current);
			current = (Node) current.getParent();

		}
		return o;
	}

	private RangeAdapter getRangeAdapter(Node parent) {
		for (Adapter a : parent.eAdapters()) {
			if (a instanceof RangeAdapter) {
				return (RangeAdapter) a;

			}
		}
		RangeAdapter ra = new RangeAdapter();
		parent.eAdapters().add(ra);
		return ra;
	}

	public Node getCurrent() {
		return this.current;
	}

	@SuppressWarnings("unchecked")
	public void addError(String message, RecognitionException ex) {
		Error e = ParsetreeFactory.eINSTANCE.createError();
		e.setMessage(message);
		e.setException(ex);
		current.getErrors().add(e);
	}

}
