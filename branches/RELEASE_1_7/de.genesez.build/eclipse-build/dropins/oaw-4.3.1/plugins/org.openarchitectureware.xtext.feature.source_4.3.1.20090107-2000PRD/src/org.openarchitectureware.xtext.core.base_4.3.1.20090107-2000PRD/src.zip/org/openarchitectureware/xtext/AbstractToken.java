/**
 * <copyright>
 * </copyright>
 *
 * $Id: AbstractToken.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Token</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getAbstractToken()
 * @model
 * @generated
 */
public interface AbstractToken extends Element {
} // AbstractToken
