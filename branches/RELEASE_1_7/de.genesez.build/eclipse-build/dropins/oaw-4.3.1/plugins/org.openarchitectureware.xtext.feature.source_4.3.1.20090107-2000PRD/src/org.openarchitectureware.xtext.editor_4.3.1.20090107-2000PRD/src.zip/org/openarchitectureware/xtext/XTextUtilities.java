/*******************************************************************************
 * Copyright (c) 2007 2008 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare
 *******************************************************************************/
package org.openarchitectureware.xtext;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.antlr.runtime.RecognitionException;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.rules.IPartitionTokenScanner;
import org.openarchitectureware.xtext.parser.IXtextParser;
import org.openarchitectureware.xtext.parser.XtextParser;

public class XTextUtilities extends AbstractLanguageUtilities {

	public IXtextParser internalParse(InputStream in) throws IOException,
			RecognitionException {
		return new XtextParser(in);
	}

	public EPackage getEPackage() {
		return XtextPackage.eINSTANCE;
	}

	public String getFileExtension() {
		return "xtxt";
	}

	ArrayList<String> keywords = new ArrayList<String>(Arrays
			.asList(new String[] { "importGrammar", "grammar_name",
					"grammar_nsURI", "commentsDisabled", "String", "INT",
					"STRING", "URI", "Enum", "ID", "Native",
					"preventMMGeneration", "importMetamodel", "as"}));

	public List<String> allKeywords() {
		return keywords;
	}

	public ClassLoader getClassLoader() {
		return this.getClass().getClassLoader();
	}

	public IPartitionTokenScanner getPartitionScanner() {
		return new GeneratedPartitionScanner();
	}

	@Override
	public AbstractXtextEditorPlugin getXtextEditorPlugin() {
		return XTextEditorPlugin.getDefault();
	}

	@Override
	public String getPackageForExtensions() {
		return "org::openarchitectureware::xtext";
	}

	public XtextFile getXtextFile() {
		return null;
	}

	@Override
	public IContentAssistProcessor getContentAssistProcessor() {
		return new XtextGrammarContentAssistProcessor(this);
	}

}
