package org.openarchitectureware.xtext.registry;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.openarchitectureware.xtext.resource.AbstractXtextResource;

/**
 * Utility class to handle resource loading. The name is for historical reasons
 * as no more caching is performed.
 * 
 * @author koehnlein
 */
public class CachingModelLoad {

	private static Log log = LogFactory.getLog(CachingModelLoad.class);

	private static ResourceSet defaultResourceSet = new XtextResourceSet();

	/**
	 * Loads the resource with the given URI into the same resource set as the
	 * contextElement. If the ResourceSet is an {@link XtextResourceSet}, it is
	 * capable of resolving classpath relative URIs. If forceLinking if set to
	 * true, the loaded resource is linked. This may cause further resources to
	 * be loaded and linked. Disabling linking can significantly improve memory
	 * consumption and performance, but the loaded resource will not have any
	 * cross references set.
	 * 
	 * @param uri
	 *            the URI of the resource to be loaded.
	 * @param contextElement
	 *            an element whose resource set is used to load the resource.
	 *            Even though there is a default resource set that is used if
	 *            the contextElement is null, you should always provide the
	 *            contextElement.
	 * @param forceLinking
	 *            if set to true, the loaded resource is linked.
	 * @return the contents of the loaded resource.
	 */
	public static List<EObject> load(String uri, EObject contextElement,
			Boolean forceLinking) {
		Resource contextResource = contextElement.eResource();
		if (contextResource == null) {
			throw new IllegalArgumentException(
					"Context EObject must be in a Resource");
		}
		ResourceSet resourceSet = getResourceSet(contextResource
				.getResourceSet());
		Resource res = internalLoad(URI.createURI(uri), null, resourceSet,
				false, forceLinking);
		return res != null ? res.getContents() : Collections
				.<EObject> emptyList();
	}

	/**
	 * Loads the resource with the given URI into the resourceSet. If the
	 * ResourceSet is an {@link XtextResourceSet}, it is capable of resolving
	 * classpath relative URIs. If forceLinking if set to true, the loaded
	 * resource is linked. This may cause further resources to be loaded and
	 * linked. Disabling linking can significantly improve memory consumption
	 * and performance, but the loaded resource will not have any cross
	 * references set.
	 * 
	 * @param uri
	 *            the URI of the resource to be loaded.
	 * @param resourceSet
	 *            the resourceSet to load the resource into.
	 * @param forceReload
	 *            if true, the resource is reloaded if already present in the
	 *            resourceSet.
	 * @param forceLinking
	 *            if set to true, the loaded resource is linked.
	 * @return the loaded resource.
	 */
	public static Resource loadResource(URI uri, ResourceSet resourceSet,
			boolean forceReload, boolean forceLinking) {
		Resource res = internalLoad(uri, null, getResourceSet(resourceSet),
				forceReload, forceLinking);
		return res;
	}

	/**
	 * Loads the resource from the given inputStream into the resourceSet. If
	 * the ResourceSet is an {@link XtextResourceSet}, it is capable of
	 * resolving classpath relative URIs. If forceLinking if set to true, the
	 * loaded resource is linked. This may cause further resources to be loaded
	 * and linked. Disabling linking can significantly improve memory
	 * consumption and performance, but the loaded resource will not have any
	 * cross references set.
	 * 
	 * @param uri
	 *            the URI of the resource to be loaded.
	 * @param in
	 *            the input stream to read the contents from.
	 * @param resourceSet
	 *            the resourceSet to load the resource into.
	 * @param forceLinking
	 *            if set to true, the loaded resource is linked.
	 * @return the loaded resource.
	 */
	public static Resource loadResource(URI uri, InputStream in,
			ResourceSet resourceSet, boolean forceLinking) {
		Resource res = internalLoad(uri, in, getResourceSet(resourceSet), true,
				forceLinking);
		return res;
	}

	private static ResourceSet getResourceSet(ResourceSet resourceSet) {
		if (resourceSet == null) {
			log.warn("Passed ResourceSet is null. Using default ResourceSet");
			return defaultResourceSet;
		}
		return resourceSet;
	}

	private static synchronized Resource internalLoad(URI uri, InputStream in,
			ResourceSet resourceSet, boolean isForceReload, boolean forceLinking) {
		if (uri == null)
			return null;
		Object defaultIsLoadOnDemand = null;
		Map<Object, Object> loadOptions = resourceSet.getLoadOptions();
		try {
			if (resourceSet instanceof XtextResourceSet) {
				XtextResourceSet xtextResourceSet = (XtextResourceSet) resourceSet;
				boolean doLink = xtextResourceSet.isRecursiveLink()
						| forceLinking;
				defaultIsLoadOnDemand = loadOptions.put(
						AbstractXtextResource.LINK_ON_LOAD_OPTION, doLink);
			}
			Resource res = resourceSet.getResource(uri, false);
			if (res != null && isForceReload) {
				return internalReloadResource(uri, in, res, loadOptions);
			}
			if (res == null) {
				return internalLoadResource(uri, in, resourceSet, loadOptions);
			}
			return res;
		} catch (Exception e) {
			log.error("Error loading resource", e);
			// ignore - null indicates that there is a problem with the
			// uri
			return null;
		} finally {
			if (defaultIsLoadOnDemand == null) {
				loadOptions.remove(AbstractXtextResource.LINK_ON_LOAD_OPTION);
			} else {
				loadOptions.put(AbstractXtextResource.LINK_ON_LOAD_OPTION,
						defaultIsLoadOnDemand);
			}
		}
	}

	private static Resource internalLoadResource(URI uri, InputStream in,
			ResourceSet resourceSet, Map<Object, Object> loadOptions)
			throws IOException {
		Resource res = resourceSet.createResource(uri);
		internalDoLoadResource(uri, in, res, loadOptions);
		return res;
	}

	private static Resource internalReloadResource(URI uri, InputStream in,
			Resource res, Map<Object, Object> loadOptions) throws IOException {
		if (res.isLoaded()) {
			if (log.isDebugEnabled())
				log.debug("unloading..." + uri);
			res.unload();
		}
		internalDoLoadResource(uri, in, res, loadOptions);
		return res;
	}

	private static void internalDoLoadResource(URI uri, InputStream in,
			Resource res, Map<Object, Object> loadOptions) throws IOException {
		if (log.isDebugEnabled())
			log.debug("parsing..." + uri);
		if (in != null) {
			res.load(in, loadOptions);
		} else {
			res.load(loadOptions);
		}
	}
}
