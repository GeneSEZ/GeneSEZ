/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare 
 *******************************************************************************/
package org.openarchitectureware.xtext.xtext2ecore;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.m2t.type.emf.EmfRegistryMetaModel;
import org.openarchitectureware.xtend.XtendFacade;
import org.openarchitectureware.xtext.XtextFile;

public class Xtext2Ecore {

	public EPackage transform(XtextFile xf) {
		String pack = getClass().getPackage().getName().replaceAll("\\.", "::");
		XtendFacade facade = XtendFacade.create(new String []{pack+"::Xtext2Ecore", pack+"::EcoreNormalization"});
		facade.registerMetaModel(new EmfRegistryMetaModel());
		EPackage result = (EPackage) facade.call("toEPackage", xf);
		facade.call("normalize", result);
		return result;
	}
}
