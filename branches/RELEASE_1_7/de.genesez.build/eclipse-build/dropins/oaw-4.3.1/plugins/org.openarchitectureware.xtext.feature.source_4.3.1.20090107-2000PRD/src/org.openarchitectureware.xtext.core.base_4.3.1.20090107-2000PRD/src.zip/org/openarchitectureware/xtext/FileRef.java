/**
 * <copyright>
 * </copyright>
 *
 * $Id: FileRef.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>File Ref</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getFileRef()
 * @model
 * @generated
 */
public interface FileRef extends AbstractToken {
} // FileRef
