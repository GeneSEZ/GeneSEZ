package org.openarchitectureware.xtext.parser.impl;

import org.antlr.runtime.CommonToken;
import org.antlr.runtime.MismatchedTokenException;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.Token;
import org.openarchitectureware.xtext.parser.ErrorMsg;

public class AntlrUtil {
	public static ErrorMsg create(RecognitionException ex, String[] tokenNames) {
		String msg = "Parse error";
		try {
		if (ex instanceof MismatchedTokenException) {
			MismatchedTokenException mte = (MismatchedTokenException) ex;
			if (ex.token.getType()==-1){
				msg = "Unexpected end of file! Expecting "+tokenNames[mte.expecting];
			} else if (tokenNames!=null && ex.token!=null && ex.token.getText()!=null) {
				msg = "Unexpected token '"+ex.token.getText()+"' (type: "+tokenNames[ex.getUnexpectedType()]+") - expecting : "+(mte.expecting==-1 ? "end of File" : tokenNames[mte.expecting]);
			}
		} else if (ex.token!=null && ex.token.getText()!=null)
			msg = "Unexpected token '"+ex.token.getText()+"' (type: "+tokenNames[ex.getUnexpectedType()]+")";
		} catch (Exception e) {
			// ignore
		}
		return create(msg,ex,tokenNames);
	}
	public static ErrorMsg create(String msg,RecognitionException ex, String[] tokenNames) {
		int length = 1;
		if (ex.token!=null && ex.token.getText()!=null) {
			length = ex.token.getText().length();
		}
		if (ex.token!=null) {
			Token t = ex.token;
			if (t instanceof CommonToken) {
				CommonToken ct = (CommonToken) t;
				return new ErrorMsg(msg,ct.getStartIndex(),ct.getStopIndex()-ct.getStartIndex(),ct.getLine());
			}
		}
		return new ErrorMsg(msg,ex.index>=0?ex.index:0,length,ex.line);
	}
}
