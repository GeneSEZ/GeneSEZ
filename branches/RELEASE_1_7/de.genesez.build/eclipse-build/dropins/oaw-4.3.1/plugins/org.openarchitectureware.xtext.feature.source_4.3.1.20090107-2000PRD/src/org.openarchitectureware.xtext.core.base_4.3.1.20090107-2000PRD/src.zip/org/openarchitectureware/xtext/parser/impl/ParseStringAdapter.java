package org.openarchitectureware.xtext.parser.impl;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.impl.AdapterImpl;
import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.ecore.EObject;

public class ParseStringAdapter extends AdapterImpl {

	private final Map<String, Object> properties = new HashMap<String, Object>();

	public static Collection find(final EObject o, final String s) {
		for (final Adapter a : o.eAdapters()) {
			if (a instanceof ParseStringAdapter) {
				final ParseStringAdapter psa = (ParseStringAdapter) a;
				Collection coll = psa.get(s);
				if (coll != null)
					return coll;
			}
		}
		return Collections.EMPTY_LIST;
	}

	public static String findString(final EObject o, final String s) {
		for (final Adapter a : o.eAdapters()) {
			if (a instanceof ParseStringAdapter) {
				final ParseStringAdapter psa = (ParseStringAdapter) a;
				return psa.getAsString(s);
			}
		}
		return null;
	}

	public static ParseStringAdapter getAdapter(final EObject o) {
		for (final Adapter a : o.eAdapters()) {
			if (a instanceof ParseStringAdapter)
				return (ParseStringAdapter) a;
		}
		final ParseStringAdapter parseStringAdapter = new ParseStringAdapter();
		o.eAdapters().add(parseStringAdapter);
		return parseStringAdapter;
	}

	public void add(final String featureName, final Object arg) {
		List l = (List) properties.get(featureName);
		if (l == null) {
			l = new BasicEList();
			properties.put(featureName, l);
		}
		l.add(arg);
	}

	public void put(final String propertyName, final Object arg) {
		properties.put(propertyName, arg);
	}

	private Collection get(final String s) {
		Collection result = (Collection) properties.get(s);
		if (result == null)
			return Collections.EMPTY_LIST;

		return result;
	}

	private String getAsString(final String s) {
		final Object obj = properties.get(s);
		if (obj == null)
			return null;

		return obj.toString();
	}

}
