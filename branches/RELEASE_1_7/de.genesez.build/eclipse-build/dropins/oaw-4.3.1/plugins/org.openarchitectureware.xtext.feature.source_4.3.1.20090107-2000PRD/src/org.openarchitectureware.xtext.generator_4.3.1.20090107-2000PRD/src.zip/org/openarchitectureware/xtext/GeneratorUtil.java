/*
 * Copyright (c) 2008 itemis AG and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 */

package org.openarchitectureware.xtext;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author Patrick Schoenbach - Initial API and implementation
 * @version $Revision: 1.2 $
 */

public final class GeneratorUtil {

	public static String contextName(final Rule rule) {
		if (rule == null)
			return null;

		if (rule instanceof RuleWithType)
			return ((RuleWithType) rule).getType().getName();

		return rule.getName();
	}

	public static Set<Rule> uniqueRules(final List list) {
		if (list == null)
			return null;

		final Set<Rule> result = new HashSet<Rule>();
		final Set<String> typeNames = new HashSet<String>();
		for (final Object obj : list) {
			if (obj instanceof TypeRule) {
				final TypeRule r = (TypeRule) obj;
				final String name = r.getType().getName();
				if (!typeNames.contains(name)) {
					typeNames.add(name);
					result.add(r);
				}
			}
		}
		return result;
	}

	public static Set<TypeRule> uniqueTypeRules(final List list) {
		final Set<Rule> rules = uniqueRules(list);
		if (rules == null)
			return null;

		final Set<TypeRule> result = new HashSet<TypeRule>();
		for (final Rule r : rules) {
			if (r instanceof TypeRule) {
				result.add((TypeRule) r);
			}
		}
		return result;
	}
}
