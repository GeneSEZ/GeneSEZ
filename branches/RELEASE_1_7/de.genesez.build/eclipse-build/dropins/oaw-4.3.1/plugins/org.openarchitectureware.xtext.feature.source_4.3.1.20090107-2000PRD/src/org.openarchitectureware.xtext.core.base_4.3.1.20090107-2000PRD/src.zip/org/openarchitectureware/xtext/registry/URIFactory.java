package org.openarchitectureware.xtext.registry;

import org.eclipse.emf.common.util.URI;

/**
 * @deprecated Initially thought as a hook to resolve classpath URIs.
 *             Superseeded by new {@link ICachingModelLoadAccess}
 */
public interface URIFactory {
	URI createURI(String s);
}
