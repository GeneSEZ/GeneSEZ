package org.openarchitectureware.xtext.resource;

public interface IXtextResourceFactory {
	// Currently only a marker interface
}
