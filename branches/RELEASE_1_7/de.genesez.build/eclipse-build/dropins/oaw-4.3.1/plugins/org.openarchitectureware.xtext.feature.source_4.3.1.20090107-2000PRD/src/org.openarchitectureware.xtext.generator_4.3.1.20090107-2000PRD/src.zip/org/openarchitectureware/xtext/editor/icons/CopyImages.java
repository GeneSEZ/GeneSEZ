/*******************************************************************************
 * Copyright (c) 2007 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare 
 *******************************************************************************/

package org.openarchitectureware.xtext.editor.icons;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.openarchitectureware.workflow.WorkflowContext;
import org.openarchitectureware.workflow.issues.Issues;
import org.openarchitectureware.workflow.lib.AbstractWorkflowComponent2;
import org.openarchitectureware.workflow.monitor.ProgressMonitor;
import org.openarchitectureware.workflow.util.ResourceLoaderFactory;

public class CopyImages extends AbstractWorkflowComponent2 {

	private static final String COMPONENT_NAME = "Image Copier";

	private Log log = LogFactory.getLog(getClass());

	private String targetDir = null;

	/**
	 * Sets the target directory.
	 * 
	 * @param targetDir
	 *            the directory
	 */
	public void setTargetDir(String targetDir) {
		this.targetDir = targetDir;
	}

	@Override
	protected void checkConfigurationInternal(Issues issues) {
		if (targetDir == null || !new File(targetDir).getParentFile().exists()) {
			issues.addError("Property targetDir not configured properly");
		}
	}

	@Override
	protected void invokeInternal(WorkflowContext ctx, ProgressMonitor monitor, Issues issues) {
		copyFiles(new String[] { "uri.gif", "default.gif", "file.gif", "keyword.gif", "newfile_wiz.png",
				"newprj_wiz.png", "template.gif", "notFound.gif" });
	}

	private void copyFiles(String[] files) {
		File target = new File(targetDir);
		if (!target.exists()) {
			target.mkdir();
		}
		for (String file : files) {
			File copy = new File(target.getAbsolutePath() + File.separatorChar + file);
			if (!copy.exists()) {
				String uri = "org/openarchitectureware/xtext/editor/icons/" + file;
				InputStream is = ResourceLoaderFactory.createResourceLoader().getResourceAsStream(uri);
				try {
					copy.createNewFile();
					FileOutputStream fwr = new FileOutputStream(copy);
					byte[] buff = new byte[1024];
					int read;
					while ((read = is.read(buff)) != -1) {
						fwr.write(buff, 0, read);
					}
					if (log.isDebugEnabled()) {
						log.debug("Copied " + copy);
					}
				}
				catch (IOException e) {
					log.error(e);
				}
			}
		}
	}

	public String getComponentName() {
		return COMPONENT_NAME;
	}
}
