package org.openarchitectureware.xtext.resource;

import org.openarchitectureware.xtext.parser.IXtextParser;

public interface IXtextResource extends org.eclipse.emf.ecore.resource.Resource {
	IXtextParser getParser();
}
