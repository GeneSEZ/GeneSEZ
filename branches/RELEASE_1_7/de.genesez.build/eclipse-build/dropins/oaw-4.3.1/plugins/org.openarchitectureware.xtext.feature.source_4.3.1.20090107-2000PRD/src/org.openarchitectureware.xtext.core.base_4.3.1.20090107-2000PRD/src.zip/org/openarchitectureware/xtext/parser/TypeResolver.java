package org.openarchitectureware.xtext.parser;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.openarchitectureware.xtext.EnumRule;
import org.openarchitectureware.xtext.MetamodelImport;
import org.openarchitectureware.xtext.TypeName;
import org.openarchitectureware.xtext.TypeRule;

public class TypeResolver {

	private static ResourceSetImpl resourceSet = new ResourceSetImpl();
	
	static {
		resourceSet.setURIResourceMap(new HashMap<URI, Resource>());
	}

	public static ResourceSetImpl getResourceSet() {
		return resourceSet;
	}
	
	
	 public static EClass findEClass(String alias, String name, Map<String, String> imports){
	    	EClassifier classifier = findClassifier(alias, name, imports);
	    	if (classifier instanceof EClass) {
	    		return (EClass) classifier;
			}
	    	return null;
	    }
	    
	    public static EEnum findEEnum(String alias, String enumName, Map<String, String> imports){
	    	EClassifier classifier = findClassifier(alias, enumName, imports);
	    	if (classifier instanceof EEnum) {
	    		return (EEnum) classifier;
			}
	    	return null;
	    }

		private static EClassifier findClassifier(String alias, String name,
				Map<String, String> imports) {
			if ( imports == null) {
				return null;
			}
			if ( alias == null) {
				alias="";
			}

			String location = imports.get(alias);
	    	if (location== null) {
	    		return null;
	    	}
	    	EPackage pack = findEPackage(location);
	    	// ENDTODO
	    	if (pack== null) {
	    		throw new IllegalArgumentException("Package with NsURI "+ location +" does not exist or is not a ecore file");
	    	}
	    	EClassifier classifier = pack.getEClassifier(name);
			return classifier;
		}


		private static EPackage findEPackage(String location) {
			EPackage pack = EPackage.Registry.INSTANCE.getEPackage(location);
	    	//TODO Maybe we should not do this....
	    	if (pack== null) {
	    		Resource res = resourceSet.getResource(URI.createURI(location), true);
	    		EObject object = res.getContents().get(0);
	    		if (object instanceof EPackage) {
					pack = (EPackage) object;
				}
	    	}
			return pack;
		}


		public static EPackage findEPackage(MetamodelImport i) {
			return findEPackage(i.getLocation());
		}
		
		public static EClass findEClass(TypeRule rule,
				Collection<MetamodelImport> imports) {
			return findEClass(rule.getType(), imports);
		}

		public static EClass findEClass(TypeName rule,
				Collection<MetamodelImport> imports) {
			return TypeResolver.findEClass(rule.getAlias(), rule.getName(),
					convertToMap(imports));
		}

		public static EEnum findEEnum(EnumRule rule,
				Collection<MetamodelImport> imports) {
			return null!=rule.getType() ? TypeResolver.findEEnum(rule.getType().getAlias(), rule.getType()
					.getName(), convertToMap(imports)):null;
		}

		public static EEnum findEEnum(TypeName rule,
				Collection<MetamodelImport> imports) {
			return TypeResolver.findEEnum(rule.getAlias(), rule.getName(),
					convertToMap(imports));
		}
		
		private static Map<String, String> convertToMap(
				Collection<MetamodelImport> imports) {
			Map<String, String> map = new HashMap<String, String>();
			for (MetamodelImport metamodelImport : imports) {
				map.put(metamodelImport.getAlias() == null ? "" : metamodelImport
						.getAlias(), metamodelImport.getLocation());
			}
			return map;
		}

}
