package org.openarchitectureware.xtext.parser.model;

import java.util.Set;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.openarchitectureware.xtext.*;

public class XtextGrammarUtil {

	public static Rule getContainingRule(final Element ass) {
		if (ass.eContainer() instanceof Rule)
			return (Rule) ass.eContainer();
		return getContainingRule((Element) ass.eContainer());
	}

	public static Assignment getContainingAssignment(final AbstractToken ele) {
		if (ele == null)
			return null;
		if (ele.eContainer() instanceof Assignment) {
			final Assignment ass = (Assignment) ele.eContainer();
			if (ass.getToken() == ele)
				return ass;
		}
		return null;
	}

	public static Element getContainingElement(final Element ele) {
		if (ele.eContainer() instanceof Element)
			return (Element) ele.eContainer();
		return null;
	}

	public static Element getNext(final Element element) {
		Element child = element;
		Element container = getContainingElement(child);
		while (container != null && !(container instanceof Group)) {
			child = container;
			container = getContainingElement(child);
		}
		if (container != null) {
			final EList<EObject> contents = container.eContents();
			final int indexOf = contents.indexOf(child);
			if (contents.size() >= indexOf) {
				final EObject object = contents.get(indexOf + 1);
				return (Element) object;
			}
		}
		return null;
	}

	public static boolean isCompatible(final AbstractToken at1, final AbstractToken at2) {
		return getTokenName(at1).equals(getTokenName(at2));
	}

	public static String getTokenName(final AbstractToken at) {
		if (at == null)
			return null;
		if (at instanceof Keyword)
			return ((Keyword) at).getValue();
		else if (at instanceof RuleName)
			return ((RuleName) at).getName();
		else if (at instanceof CrossReference) {
			final CrossReference cr = (CrossReference) at;
			if (cr.getRuleName() == null)
				return "ID";
			return cr.getRuleName().getName();
		}
		else if (at instanceof FileRef)
			return "STRING";
		throw new IllegalArgumentException(at.getClass().getSimpleName() + " not handled");
	}

	@SuppressWarnings("unchecked")
	public static Rule findRule(final RuleName rn) {
		final XtextFile f = getXtextFile(rn);
		final EList<Rule> rules = f.getRules();
		for (final Rule r : rules) {
			if (r.getName().equals(rn.getName()))
				return r;
		}
		return null;
	}

	public static XtextFile getXtextFile(final EObject rn) {
		return (XtextFile) EcoreUtil.getRootContainer(rn);
	}

	public static boolean isMultiMax(final Element element) {
		boolean isMulti = false;
		if (element.getCardinality() != null) {
			isMulti = element.getCardinality() == CardinalityType.ANY
					|| element.getCardinality() == CardinalityType.ONEORMORE;
		}
		Group g = getGroup(element);
		while (g != null) {
			isMulti = g.getCardinality() == CardinalityType.ANY || g.getCardinality() == CardinalityType.ONEORMORE;
			g = getGroup(g);
		}
		return isMulti;
	}

	private static Group getGroup(final Element element) {
		if (element == null)
			return null;
		if (element instanceof Group)
			return (Group) element;
		return getGroup(getContainingElement(element));
	}

	public static boolean isOptional(final Element element) {
		boolean isMulti = false;
		if (element.getCardinality() != null) {
			isMulti = element.getCardinality() == CardinalityType.ANY
					|| element.getCardinality() == CardinalityType.OPTIONAL;
		}
		return isMulti;
	}

	public static boolean isCompatible(final Set<AbstractToken> possibleTokens, final Set<AbstractToken> possibleTokens2) {
		for (final AbstractToken at : possibleTokens) {
			for (final AbstractToken at2 : possibleTokens2) {
				if (isCompatible(at, at2))
					return true;
			}
		}
		return false;
	}

	public static Element normalize(final Object e) {
		if (e instanceof Element)
			return normalize((Element) e);
		throw new IllegalArgumentException();
	}

	public static Element normalize(final Element e) {
		final CardinalityType cardinalityType = e.getCardinality();
		Element result = null;
		if (e instanceof Group && ((Group) e).getChildren().size() == 1) {
			result = normalize(((Group) e).getChildren().get(0));
		}
		else if (e instanceof Alternatives && ((Alternatives) e).getAlternatives().size() == 1) {
			result = normalize(((Alternatives) e).getAlternatives().get(0));
		}
		if (result != null && result != e && cardinalityType != CardinalityType.NULL) {
			if (result.getCardinality() != CardinalityType.NULL)
				throw new IllegalStateException();
			result.setCardinality(cardinalityType);
			return result;
		}
		return result != null ? result : e;
	}

}
