/**
 * <copyright>
 * </copyright>
 *
 * $Id: TypeRule.java,v 1.2 2008/12/23 21:58:05 pschoenb Exp $
 */
package org.openarchitectureware.xtext;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Type Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.openarchitectureware.xtext.TypeRule#getContent <em>Content</em>}</li>
 *   <li>{@link org.openarchitectureware.xtext.TypeRule#getExtends <em>Extends</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.openarchitectureware.xtext.XtextPackage#getTypeRule()
 * @model
 * @generated
 */
public interface TypeRule extends RuleWithType {
	/**
	 * Returns the value of the '<em><b>Content</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Content</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Content</em>' containment reference.
	 * @see #setContent(Element)
	 * @see org.openarchitectureware.xtext.XtextPackage#getTypeRule_Content()
	 * @model containment="true"
	 * @generated
	 */
	Element getContent();

	/**
	 * Sets the value of the '{@link org.openarchitectureware.xtext.TypeRule#getContent <em>Content</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Content</em>' containment reference.
	 * @see #getContent()
	 * @generated
	 */
	void setContent(Element value);

	/**
	 * Returns the value of the '<em><b>Extends</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Extends</em>' attribute list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extends</em>' attribute list.
	 * @see org.openarchitectureware.xtext.XtextPackage#getTypeRule_Extends()
	 * @model
	 * @generated
	 */
	EList<String> getExtends();

} // TypeRule
