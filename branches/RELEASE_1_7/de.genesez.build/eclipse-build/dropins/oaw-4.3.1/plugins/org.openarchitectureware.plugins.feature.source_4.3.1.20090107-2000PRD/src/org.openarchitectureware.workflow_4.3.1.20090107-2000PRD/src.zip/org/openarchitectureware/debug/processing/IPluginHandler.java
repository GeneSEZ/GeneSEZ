/*******************************************************************************
 * Copyright (c) 2005, 2007 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Clemens Kadura (zAJKa) - Initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.debug.processing;

import org.openarchitectureware.debug.communication.Connection;

/**
 * base interface for handlers that support the debugger on the eclipse side
 */
public interface IPluginHandler {
	public void setConnection(Connection connection);

	public void setDebugModelManager(DebugModelManager dmm);
}
