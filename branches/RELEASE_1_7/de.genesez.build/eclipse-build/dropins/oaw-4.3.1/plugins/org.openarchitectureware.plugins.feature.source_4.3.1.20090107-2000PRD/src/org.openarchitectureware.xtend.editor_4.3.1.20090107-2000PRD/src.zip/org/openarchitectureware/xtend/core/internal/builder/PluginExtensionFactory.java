/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xtend.core.internal.builder;

import java.util.List;

import org.eclipse.jdt.core.IJavaProject;
import org.openarchitectureware.expression.ast.DeclaredParameter;
import org.openarchitectureware.expression.ast.Identifier;
import org.openarchitectureware.xtend.ast.JavaExtensionStatement;
import org.openarchitectureware.xtend.parser.ExtensionFactory;

public class PluginExtensionFactory extends ExtensionFactory {

    private IJavaProject jp;

    public PluginExtensionFactory(final IJavaProject jp, final String name) {
        super(name);
        this.jp = jp;
    }

    @Override
    public JavaExtensionStatement createJavaExtension(Identifier name, Identifier type, List<DeclaredParameter> params, 
    		Identifier javaType, Identifier javaMethod, List<Identifier> javaParamTypes, Identifier cached, Identifier priv) {
        return (JavaExtensionStatement) handle(new PluginJavaExtensionStatement(jp,
                name, nonNull(params), type, javaType, javaMethod, nonNull(javaParamTypes), cached != null,
                priv != null));
    }
}
