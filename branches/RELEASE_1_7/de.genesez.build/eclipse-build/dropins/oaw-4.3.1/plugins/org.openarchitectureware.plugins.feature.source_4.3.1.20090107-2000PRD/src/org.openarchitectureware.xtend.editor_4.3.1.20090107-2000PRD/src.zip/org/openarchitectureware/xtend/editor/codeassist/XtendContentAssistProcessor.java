/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/

package org.openarchitectureware.xtend.editor.codeassist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContextInformation;
import org.eclipse.jface.text.contentassist.IContextInformationValidator;
import org.eclipse.ui.IEditorPart;
import org.openarchitectureware.OawPlugin;
import org.openarchitectureware.core.IOawProject;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.codeassist.ExpressionProposalComputer;
import org.openarchitectureware.expression.codeassist.ExtensionImportProposalComputer;
import org.openarchitectureware.expression.codeassist.ProposalFactory;
import org.openarchitectureware.expression.codeassist.TypeProposalComputer;
import org.openarchitectureware.expression.editor.codeassist.AbstractOawContentAssistProcessor;
import org.openarchitectureware.expression.editor.codeassist.ProposalComparator;
import org.openarchitectureware.expression.editor.codeassist.ProposalFactoryEclipseImpl;
import org.openarchitectureware.xpand2.codeassist.NamespaceProposalComputer;
import org.openarchitectureware.xtend.XtendFile;
import org.openarchitectureware.xtend.ast.Extension;
import org.openarchitectureware.xtend.codeassist.FastAnalyzer;
import org.openarchitectureware.xtend.codeassist.Partition;
import org.openarchitectureware.xtend.core.IXtendResource;

/**
 * @author Sven Efftinge (http://www.efftinge.de)
 */
public class XtendContentAssistProcessor extends AbstractOawContentAssistProcessor implements IContentAssistProcessor {

	public XtendContentAssistProcessor(final IEditorPart editor) {
		super(editor);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected ICompletionProposal[] internalComputeCompletionProposals(final ITextViewer viewer,
			final int documentOffset) {
		String part = viewer.getDocument().get().substring(0, documentOffset);
		ExecutionContext ctx = OawPlugin.getExecutionContext(getJavaProject());
		final IOawResource res = OawPlugin.getOawModelManager().findOawResource(getFile());
		List<Extension> extensions = new ArrayList<Extension>();
		if (res instanceof IXtendResource) {
			extensions = ((IXtendResource) res).getExtensions();
		}
		final Partition p = FastAnalyzer.computePartition(part);
		final ProposalFactory factory = new ProposalFactoryEclipseImpl(documentOffset);
		List<? extends ICompletionProposal> proposals = new ArrayList<ICompletionProposal>();
		if (p == Partition.EXPRESSION) {
			ctx = FastAnalyzer.computeExecutionContext(part, ctx, extensions);
			final int i = part.lastIndexOf(';');
			if (i != -1) {
				part = part.substring(i);
			}
			proposals = (List<? extends ICompletionProposal>) new ExpressionProposalComputer().computeProposals(part,
					ctx, factory);
		} else if (p == Partition.TYPE_DECLARATION) {
			ctx = FastAnalyzer.computeExecutionContext(part, ctx, extensions);
			proposals = (List<? extends ICompletionProposal>) new TypeProposalComputer().computeProposals(part, ctx,
					factory);
		} else if (p == Partition.EXTENSION_IMPORT) {
			IOawProject project = OawPlugin.getOawModelManager().findProject(getFile());
			IOawResource[] resources = project.getAllRegisteredResources();
			Set<String> extensionNames = new HashSet<String>();
			for (IOawResource resource : resources) {
				if (resource instanceof XtendFile) {
					extensionNames.add(resource.getFullyQualifiedName());
				}
			}
			proposals = (List<? extends ICompletionProposal>) new ExtensionImportProposalComputer().computeProposals(
					part, ctx, factory, extensionNames);
		} else if (p == Partition.NAMESPACE_IMPORT) {
			ctx = FastAnalyzer.computeExecutionContext(part, ctx, extensions);
			proposals = (List<? extends ICompletionProposal>) new NamespaceProposalComputer().computeProposals(part, ctx, factory);
			
		}
		Collections.sort(proposals, new ProposalComparator());
		return proposals.toArray(new ICompletionProposal[proposals.size()]);
	}

	/**
	 * {@inheritDoc}
	 */
	public IContextInformation[] computeContextInformation(final ITextViewer viewer, final int documentOffset) {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public char[] getCompletionProposalAutoActivationCharacters() {
		return new char[] { '.' };
	}

	/**
	 * {@inheritDoc}
	 */
	public char[] getContextInformationAutoActivationCharacters() {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public String getErrorMessage() {
		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public IContextInformationValidator getContextInformationValidator() {
		return null;
	}

}
