/*******************************************************************************
 * Copyright (c) 2005, 2006 committers of openArchitectureWare and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     committers of openArchitectureWare - initial API and implementation
 *******************************************************************************/
package org.openarchitectureware.workflow.view;

import java.util.ArrayList;

import org.eclipse.core.resources.IFile;
import org.eclipse.debug.core.ILaunchConfiguration;
import org.eclipse.debug.ui.DebugUITools;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.List;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.part.ViewPart;

public class LaunchView extends ViewPart {

    private static LaunchView instance = null;

    private List list;

    private java.util.List<LaunchInfo> data = null;

    public static LaunchView currentInstance() {
        return instance;
    }

    public LaunchView() {
        super();
    }

    @Override
    public void createPartControl(final Composite parent) {
        instance = this;
        list = new List(parent, SWT.H_SCROLL | SWT.V_SCROLL);
        final Action runAction = new Action() {
            @Override
            public ImageDescriptor getImageDescriptor() {
                return ImageDescriptor.createFromFile(getClass(), "run.gif");
            }

            @Override
            public void run() {
                runSelection();
            }
        };
        final Action clearAction = new Action() {
            @Override
            public ImageDescriptor getImageDescriptor() {
                return ImageDescriptor.createFromFile(getClass(), "clear.gif");
            }

            @Override
            public void run() {
                list.removeAll();
                list.update();
                data.clear();
            }
        };
        final Action removeAction = new Action() {
            @Override
            public ImageDescriptor getImageDescriptor() {
                return ImageDescriptor.createFromFile(getClass(), "remove.gif");
            }

            @Override
            public void run() {
                int current = list.getSelectionIndex();
                if (current >= 0) {
                    list.remove(current);
                    list.update();
                    data.remove(current);
                }
            }
        };
        final IActionBars bars = getViewSite().getActionBars();
        final IToolBarManager mgr = bars.getToolBarManager();
        mgr.add(runAction);
        mgr.add(removeAction);
        mgr.add(clearAction);

        list.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseDoubleClick(final MouseEvent e) {
                runSelection();
            }

        });
        data = new ArrayList<LaunchInfo>();
    }

    private void runSelection() {
        final int current = list.getSelectionIndex();
        if (current >= 0) {
            final LaunchInfo info = (LaunchInfo) data.get(current);
            DebugUITools.launch(info.config, info.mode);
        }
    }

    public static void addConfiguration(final ILaunchConfiguration config, final String mode, final IFile file) {
        if (instance == null)
            return;
        instance.addConfigurationInternal(config, mode, file);
    }

    class LaunchInfo {
        public ILaunchConfiguration config;

        public String mode;

        public IFile file;

        public LaunchInfo(final ILaunchConfiguration config, final String mode, final IFile file) {
            this.config = config;
            this.mode = mode;
            this.file = file;
        }
    }

    public void addConfigurationInternal(final ILaunchConfiguration config, final String mode, final IFile file) {
        if (!data.contains(config)) {
            final LaunchInfo info = new LaunchInfo(config, mode, file);
            data.add(info);
            list.add(makeNiceString(info));
            list.update();
        }

    }

    private String makeNiceString(final LaunchInfo info) {
        final String name = info.file.getName();
        final String project = info.file.getFullPath().segment(0);
        final String str = name + " - " + project;
        return str;
    }

    @Override
    public void setFocus() {
        // TODO Auto-generated method stub

    }

}
