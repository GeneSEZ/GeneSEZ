/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xtend.core.internal.builder;

import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IStorage;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.openarchitectureware.ResourceContributorBase;
import org.openarchitectureware.core.IOawResource;
import org.openarchitectureware.expression.Resource;
import org.openarchitectureware.xtend.XtendFile;
import org.openarchitectureware.xtend.core.internal.XtendResourceImpl;
import org.openarchitectureware.xtend.internal.XtendLog;
import org.openarchitectureware.xtend.parser.ExtensionFactory;
import org.openarchitectureware.xtend.parser.ParseFacade;

public class XtendResourceParser extends ResourceContributorBase {
	@Override
	protected IOawResource createOawResource(Resource resource, IStorage source) {
		return new XtendResourceImpl((XtendFile)resource, source, this);
	}

	@Override
	public Resource parse(IStorage source, String fqn) {
		ExtensionFactory f = new ExtensionFactory(fqn);
		if (source instanceof IResource) {
			IResource res = (IResource) source;
			IJavaProject project = JavaCore.create(res.getProject());
			f = new PluginExtensionFactory(project,fqn);
		}
        return ParseFacade.file(createReader(source), fqn, getErrorHandler(source), f);
	}

	public String getFileExtension() {
        return XtendFile.FILE_EXTENSION;
    }

	@Override
	protected void logError(String message, Throwable t) {
		XtendLog.logError(message, t);
	}

	@Override
	protected void logInfo(String message) {
		XtendLog.logInfo(message);
	}
}
