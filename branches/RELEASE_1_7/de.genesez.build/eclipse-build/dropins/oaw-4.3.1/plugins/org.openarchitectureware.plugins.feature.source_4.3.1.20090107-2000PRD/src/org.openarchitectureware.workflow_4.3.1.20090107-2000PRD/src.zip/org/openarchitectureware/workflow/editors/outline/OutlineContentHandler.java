package org.openarchitectureware.workflow.editors.outline;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.BadPositionCategoryException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.Position;
import org.openarchitectureware.workflow.editors.parser.XMLAttribute;
import org.openarchitectureware.workflow.editors.parser.XMLElement;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class OutlineContentHandler extends DefaultHandler implements ContentHandler {

	private XMLElement rootElement;
	
	private XMLElement dtdElement;

	private Locator locator;

	private IDocument document;

	private String positionCategory;

	public OutlineContentHandler() {
		super();
	}

	public void setDocumentLocator(Locator locator) {
		this.locator = locator;
	}

	public void startElement(String namespace, String localname, String qName, Attributes attributes)
			throws SAXException {

		int lineNumber = locator.getLineNumber() - 1;
		XMLElement element = new XMLElement(localname);

		int startPosition = getOffsetFromLine(lineNumber);
		Position position = new Position(startPosition);

		addPosition(position);
		element.setPosition(position);

		if (rootElement == null) {
			rootElement = element;
		}

		if (attributes != null) {
			int attributeLength = attributes.getLength();
			for (int i = 0; i < attributeLength; i++) {
				String value = attributes.getValue(i);
				String localName = attributes.getLocalName(i);

				element.addChildAttribute(new XMLAttribute(localName, value));
			}
		}

		if (dtdElement != null)
			dtdElement.addChildElement(element);

		dtdElement = element;

	}

	public void endElement(String namespace, String localname, String qName) throws SAXException {

		int lineNumber = locator.getLineNumber();
		int endPosition = getOffsetFromLine(lineNumber);

		if (dtdElement != null) {

			Position position = dtdElement.getPosition();
			int length = endPosition - position.getOffset();
			position.setLength(length);

			dtdElement = dtdElement.getParent();

		}
	}

	private void addPosition(Position position) {
		try {
			document.addPosition(positionCategory, position);
		} catch (BadLocationException e) {
			e.printStackTrace();
		} catch (BadPositionCategoryException e) {
			e.printStackTrace();
		}
	}

	public void endDocument() throws SAXException {
		super.endDocument();
	}

	private int getOffsetFromLine(int lineNumber) {
		int offset = 0;
		try {
			offset = document.getLineOffset(lineNumber);
		} catch (BadLocationException e) {
			try {
				offset = document.getLineOffset(lineNumber - 1);
			} catch (BadLocationException e1) {
			}
		}
		return offset;
	}

	public XMLElement getRootElement() {
		return rootElement;
	}

	public void setDocument(IDocument document) {
		this.document = document;
	}

	public void setPositionCategory(String positionCategory) {
		this.positionCategory = positionCategory;
	}

}