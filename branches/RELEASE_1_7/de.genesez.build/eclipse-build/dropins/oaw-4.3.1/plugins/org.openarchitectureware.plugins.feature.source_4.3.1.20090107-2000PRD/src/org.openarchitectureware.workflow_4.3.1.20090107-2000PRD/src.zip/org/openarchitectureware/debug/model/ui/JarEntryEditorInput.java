package org.openarchitectureware.debug.model.ui;

import org.eclipse.core.resources.IStorage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.ui.IEditorRegistry;
import org.eclipse.ui.IPersistableElement;
import org.eclipse.ui.IStorageEditorInput;
import org.eclipse.ui.PlatformUI;

/**
 * An EditorInput for a JarEntryFile.
 * copied from org.eclipse.jdt.internal.ui.javaeditor.JarEntryEditorInput 
 */
public class JarEntryEditorInput implements IStorageEditorInput {

	private IStorage fJarEntryFile;

	public JarEntryEditorInput(IStorage jarEntryFile) {
		fJarEntryFile = jarEntryFile;
	}

	@Override
	public boolean equals(final Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof JarEntryEditorInput))
			return false;
		final JarEntryEditorInput other = (JarEntryEditorInput) obj;
		return fJarEntryFile.equals(other.fJarEntryFile);
	}

	public IPersistableElement getPersistable() {
		return null;
	}

	public String getName() {
		return fJarEntryFile.getName();
	}

	public String getFullPath() {
		return fJarEntryFile.getFullPath().toString();
	}

	public String getContentType() {
		return fJarEntryFile.getFullPath().getFileExtension();
	}

	public String getToolTipText() {
		//TODO: ER: add corresponding plugin to the text
		// as it is for Files; This would be new, since it is also
		// not available in Java
		return fJarEntryFile.getFullPath().makeRelative().toString();
	}

	public ImageDescriptor getImageDescriptor() {
		IEditorRegistry registry = PlatformUI.getWorkbench()
				.getEditorRegistry();
		return registry.getImageDescriptor(fJarEntryFile.getFullPath()
				.getFileExtension());
	}

	public boolean exists() {
		// JAR entries can't be deleted
		return true;
	}

	@SuppressWarnings("unchecked")
	public Object getAdapter(Class adapter) {
		if (adapter == IStorage.class) {
			return fJarEntryFile;
		}
        return fJarEntryFile.getAdapter(adapter);
	}

	public IStorage getStorage() {
		return fJarEntryFile;
	}

}
