package org.openarchitectureware.xtend.ast;

import java.util.List;

import org.openarchitectureware.expression.ast.DeclaredParameter;
import org.openarchitectureware.expression.ast.Expression;
import org.openarchitectureware.expression.ast.Identifier;

/**
 * 
 * @author steven
 *
 */
public abstract class AbstractExtensionDefinition extends AbstractExtension{
	
	public AbstractExtensionDefinition(final Identifier name, final Identifier returnType, final List<DeclaredParameter> formalParameters,
			final boolean cached, final boolean isPrivate) {
		super(name, returnType, formalParameters, cached, isPrivate);
	}
	
	abstract public Expression getExpression();
}
