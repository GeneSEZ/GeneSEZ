package org.openarchitectureware.xtend.ast;

import java.util.List;

import org.openarchitectureware.expression.ast.AbstractVisitor;
import org.openarchitectureware.expression.ast.ISyntaxElement;

public class AbstractXtendVisitor extends AbstractVisitor {

	@Override
	public Object visit(ISyntaxElement ele) {
		Object result = null;
		if (result == null && ele instanceof Around) {
			result = visitAround((Around) ele);
		}
		if (result == null && ele instanceof Check) {
			result = visitCheck((Check) ele);
		}
		if (result == null && ele instanceof CreateExtensionStatement) {
			result = visitCreateExtensionStatement((CreateExtensionStatement) ele);
		}
		if (result == null && ele instanceof ExpressionExtensionStatement) {
			result = visitExpressionExtensionStatement((ExpressionExtensionStatement) ele);
		}
		if (result == null && ele instanceof ExtensionFile) {
			result = visitExtensionFile((ExtensionFile) ele);
		}
		if (result == null && ele instanceof ImportStatement) {
			result = visitImportStatement((ImportStatement) ele);
		}
		if (result == null && ele instanceof JavaExtensionStatement) {
			result = visitJavaExtensionStatement((JavaExtensionStatement) ele);
		}
		return null;
	}

	protected void visitChild(ISyntaxElement child) {
		if (child != null) {
			child.accept(this);
		}
	}

	protected void visitChildren(List<? extends ISyntaxElement> children) {
		if (children != null) {
			for (ISyntaxElement child : children) {
				visitChild(child);
			}
		}
	}

	protected Object visitAround(Around node) {
		return node;
	}

	protected Object visitCheck(Check node) {
		return node;
	}

	protected Object visitCreateExtensionStatement(CreateExtensionStatement node) {
		return node;
	}

	protected Object visitExpressionExtensionStatement(ExpressionExtensionStatement node) {
		return node;
	}

	protected Object visitExtensionFile(ExtensionFile node) {
		visitChildren(node.getArounds());
		visitChildren(node.getChecks());
		visitChildren(node.getExtensions());
		visitChildren(node.getExtImports());
		visitChildren(node.getNsImports());
		return node;
	}

	protected Object visitImportStatement(ImportStatement node) {
		return node;
	}

	protected Object visitJavaExtensionStatement(JavaExtensionStatement node) {
		return node;
	}
}
