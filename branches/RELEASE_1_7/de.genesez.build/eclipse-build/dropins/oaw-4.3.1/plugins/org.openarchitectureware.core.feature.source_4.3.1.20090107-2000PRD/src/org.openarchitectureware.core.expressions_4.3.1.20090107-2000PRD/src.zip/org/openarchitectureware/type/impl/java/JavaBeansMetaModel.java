package org.openarchitectureware.type.impl.java;

import org.openarchitectureware.type.impl.java.beans.JavaBeansStrategy;


public class JavaBeansMetaModel extends JavaMetaModel {
    public JavaBeansMetaModel () {
        setTypeStrategy(new JavaBeansStrategy ());
    }
}
