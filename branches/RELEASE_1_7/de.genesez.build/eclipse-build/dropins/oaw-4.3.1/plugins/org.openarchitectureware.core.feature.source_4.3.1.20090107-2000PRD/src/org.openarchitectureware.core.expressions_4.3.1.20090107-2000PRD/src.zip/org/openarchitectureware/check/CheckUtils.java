/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.check;

import org.openarchitectureware.expression.parser.SyntaxConstants;

public class CheckUtils {

    public static final String FILE_EXTENSION = "chk";

    private static final String SLASH = "/";

    public static final String NS_DELIM = SyntaxConstants.NS_DELIM;

    public final static String getJavaResourceName(final String fqn) {
        return fqn.replaceAll(NS_DELIM, SLASH) + "." + FILE_EXTENSION;
    }

}
