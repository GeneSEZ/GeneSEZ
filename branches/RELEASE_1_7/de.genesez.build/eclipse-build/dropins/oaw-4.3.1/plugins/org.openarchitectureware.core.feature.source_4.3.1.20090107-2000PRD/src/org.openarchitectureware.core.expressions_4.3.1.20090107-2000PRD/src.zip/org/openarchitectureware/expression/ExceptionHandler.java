package org.openarchitectureware.expression;

import java.util.Map;

import org.openarchitectureware.expression.ast.SyntaxElement;

public interface ExceptionHandler {
	void handleRuntimeException (RuntimeException ex, SyntaxElement element, ExecutionContext ctx, Map<String,Object> additionalContextInfo);
}
