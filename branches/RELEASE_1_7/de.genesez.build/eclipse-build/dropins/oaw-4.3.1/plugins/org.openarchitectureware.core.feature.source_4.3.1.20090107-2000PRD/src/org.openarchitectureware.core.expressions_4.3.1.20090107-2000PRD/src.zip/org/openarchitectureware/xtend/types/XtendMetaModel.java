package org.openarchitectureware.xtend.types;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.openarchitectureware.expression.TypeSystem;
import org.openarchitectureware.type.MetaModel;
import org.openarchitectureware.type.Type;

public class XtendMetaModel implements MetaModel {

	private final Map<String, Type> types = new HashMap<String, Type>();

	public XtendMetaModel(TypeSystem ts) {
		setTypeSystem(ts);
		AdviceContextType t = new AdviceContextType(ts);
		types.put(t.getName(), t);
	}

	/**
	 * @see org.openarchitectureware.type.MetaModel#getKnownTypes()
	 */
	public Set<? extends Type> getKnownTypes() {
		return new HashSet<Type>(types.values());
	}

	/**
	 * Returns the name of the metamodel.
	 * 
	 * @return name of metamodel
	 */
	public String getName() {
		return "xtend";
	}

	/**
	 * @see org.openarchitectureware.type.MetaModel#getType(java.lang.Object)
	 */
	public Type getType(Object obj) {
		Type bestMatch = null;
		for (Type aType : getKnownTypes()) {
			if (aType.isInstance(obj)) {
				if (bestMatch == null || bestMatch.isAssignableFrom(aType)) {
					bestMatch = aType;
				}
			}
		}
		return bestMatch;
	}

	/**
	 * @see org.openarchitectureware.type.MetaModel#getTypeForName(java.lang.String)
	 */
	public Type getTypeForName(String typeName) {
		return types.get(typeName);
	}

	private TypeSystem ts = null;

	/**
	 * @see org.openarchitectureware.type.MetaModel#getTypeSystem()
	 */
	public TypeSystem getTypeSystem() {
		return ts;
	}

	/**
	 * @see org.openarchitectureware.type.MetaModel#setTypeSystem(org.openarchitectureware.expression.TypeSystem)
	 */
	public void setTypeSystem(TypeSystem typeSystem) {
		ts = typeSystem;
	}

	/**
	 * @see org.openarchitectureware.type.MetaModel#getNamespaces()
	 */
	public Set<String> getNamespaces() {
		return new HashSet<String>();
	}
}
