package org.openarchitectureware.expression.ast;


public abstract class AbstractVisitor {
	abstract public Object visit(final ISyntaxElement ele);
}
