package org.openarchitectureware.expression;

import java.util.ArrayList;
import java.util.List;

import org.openarchitectureware.expression.AbstractExpressionsUsingWorkflowComponent.GlobalVarDef;
import org.openarchitectureware.type.MetaModel;
import org.openarchitectureware.workflow.WorkflowComponent;
import org.openarchitectureware.workflow.ao.AbstractWorkflowAdvice;
import org.openarchitectureware.workflow.issues.Issues;

/**
 * Base class for workflow advices for components which use expressions.
 * 
 * @author Karsten Thoms
 * @since 4.3.1
 */
public abstract class AbstractExpressionsUsingWorkflowAdvice extends AbstractWorkflowAdvice {
	protected final List<MetaModel> metaModels = new ArrayList<MetaModel>();

	private List<GlobalVarDef> globalVarDefs = new ArrayList<GlobalVarDef>();

	/**
	 * Adds a metamodel.
	 * 
	 * @param metaModel
	 *            the metamodel.
	 */
	public void addMetaModel(final MetaModel metaModel) {
		assert metaModel != null;
		metaModels.add(metaModel);
	}

	/**
	 * Adds a global variable definition.
	 * 
	 * @param def
	 *            the definition
	 */
	public void addGlobalVarDef(GlobalVarDef def) {
		globalVarDefs.add(def);
	}

	/**
	 * @see org.openarchitectureware.workflow.ao.AbstractWorkflowAdvice#weave(org.openarchitectureware.workflow.WorkflowComponent,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	@Override
	public void weave(WorkflowComponent c, Issues issues) {
		if (!(c instanceof AbstractExpressionsUsingWorkflowComponent)) {
			issues.addError(this, "advice target is not a expression based WorkflowComponent component.");
		}
		else {
			AbstractExpressionsUsingWorkflowComponent wc = (AbstractExpressionsUsingWorkflowComponent) c;
			for (MetaModel metamodel : metaModels) {
				wc.addMetaModel(metamodel);
			}
			for (GlobalVarDef globalVar : globalVarDefs) {
				wc.addGlobalVarDef(globalVar);
			}
		}
	}
}
