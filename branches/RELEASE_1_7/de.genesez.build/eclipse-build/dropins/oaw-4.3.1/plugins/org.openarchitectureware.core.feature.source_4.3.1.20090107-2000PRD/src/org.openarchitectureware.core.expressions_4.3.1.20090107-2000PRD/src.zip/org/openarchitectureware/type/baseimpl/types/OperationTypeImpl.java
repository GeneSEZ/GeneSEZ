/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.type.baseimpl.types;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.openarchitectureware.expression.TypeSystem;
import org.openarchitectureware.type.Feature;
import org.openarchitectureware.type.Operation;
import org.openarchitectureware.type.Type;
import org.openarchitectureware.type.baseimpl.OperationImpl;

public final class OperationTypeImpl extends FeatureTypeImpl implements Type {

    public OperationTypeImpl(final TypeSystem ts, final String name) {
        super(ts, name);
    }

    @Override
    public boolean isInstance(final Object o) {
        return o instanceof Operation;
    }

    @Override
    public Object newInstance() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean isAbstract() {
        return true;
    }

    @Override
    public Set<Type> getSuperTypes() {
        return Collections.singleton(getTypeSystem().getFeatureType());
    }

    @Override
    public Feature[] getContributedFeatures() {
        return new Feature[] {
                new OperationImpl(this, "evaluate", getTypeSystem().getObjectType(),
                        getTypeSystem().getObjectType(), getTypeSystem().getListType(null)) {

                    @Override
                    public Object evaluateInternal(final Object target, final Object[] params) {
                        return ((Operation) target).evaluate(target, ((List<?>) params[0]).toArray());
                    }

                },
                new OperationImpl(this, "getParameterTypes",
                        getTypeSystem().getListType(getTypeSystem().getTypeType())) {

                    @Override
                    public Object evaluateInternal(final Object target, final Object[] params) {
                        return ((Operation) target).getParameterTypes();
                    }

                } };
    }
}
