/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xtend;

import java.util.List;
import java.util.Set;

import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.Resource;
import org.openarchitectureware.expression.ResourceManager;
import org.openarchitectureware.xtend.ast.Around;
import org.openarchitectureware.xtend.ast.Extension;

public interface XtendFile extends Resource {

    public static final String FILE_EXTENSION = "ext";

    List<Extension> getExtensions();
    
    List<Around> getArounds();

    List<Extension> getPublicExtensions(ResourceManager resourceManager,ExecutionContext ctx);

    /**
     * This method is public only for technical reasons - do not call directly!
     */
    List<Extension> getPublicExtensions(ResourceManager resourceManager,  ExecutionContext ctx, Set<String> flowoverCache);

    void analyze(ExecutionContext ctx, Set<AnalysationIssue> issues);

}
