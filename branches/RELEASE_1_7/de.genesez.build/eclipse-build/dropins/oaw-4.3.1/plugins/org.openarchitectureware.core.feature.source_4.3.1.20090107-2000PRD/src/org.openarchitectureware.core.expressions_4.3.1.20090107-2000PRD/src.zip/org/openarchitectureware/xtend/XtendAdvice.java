/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.xtend;

import java.util.ArrayList;
import java.util.List;

import org.openarchitectureware.expression.AbstractExpressionsUsingWorkflowAdvice;
import org.openarchitectureware.workflow.WorkflowComponent;
import org.openarchitectureware.workflow.issues.Issues;

public class XtendAdvice extends AbstractExpressionsUsingWorkflowAdvice {

	private static final String COMPONENT_NAME = "Xtend Advice";

	private List<String> extensionAdvices = new ArrayList<String>();

	/**
	 * Adds an extension advice.
	 * 
	 * @param extensionAdvice
	 *            the extension advice
	 */
	public void addExtensionAdvice(String extensionAdvice) {
		this.extensionAdvices.add(extensionAdvice);
	}

	/**
	 * @see org.openarchitectureware.expression.AbstractExpressionsUsingWorkflowAdvice#weave(org.openarchitectureware.workflow.WorkflowComponent,
	 *      org.openarchitectureware.workflow.issues.Issues)
	 */
	@Override
	public void weave(WorkflowComponent c, Issues issues) {
		super.weave(c, issues);
		if (!(c instanceof XtendComponent)) {
			issues.addError(this, "advice target is not an XtendComponent.");
		}
		else {
			XtendComponent xc = (XtendComponent) c;
			for (String advice : extensionAdvices) {
				xc.addExtensionAdvice(advice);
			}
		}
	}

	/**
	 * @see org.openarchitectureware.workflow.lib.AbstractWorkflowComponent#getLogMessage()
	 */
	@Override
	public String getLogMessage() {
		return "extensionAdvices: " + buildList(extensionAdvices);
	}

	/**
	 * @see org.openarchitectureware.workflow.WorkflowComponent#getComponentName()
	 */
	public String getComponentName() {
		return COMPONENT_NAME;
	}
}
