package org.openarchitectureware.expression;

import org.openarchitectureware.expression.ast.SyntaxElement;

public interface NullEvaluationHandler {
	public Object handleNullEvaluation(SyntaxElement element, ExecutionContext ctx);
}
