package org.openarchitectureware.xtend.parser;

public interface OawError {
	public int getStart();
	public int getEnd();
	public int getLine();
	public String getMessage();
}
