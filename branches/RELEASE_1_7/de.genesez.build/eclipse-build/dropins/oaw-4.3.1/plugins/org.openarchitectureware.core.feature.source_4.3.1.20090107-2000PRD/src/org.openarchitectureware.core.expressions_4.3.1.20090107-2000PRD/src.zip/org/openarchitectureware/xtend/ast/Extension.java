package org.openarchitectureware.xtend.ast;

import java.util.List;
import java.util.Set;

import org.openarchitectureware.expression.AnalysationIssue;
import org.openarchitectureware.expression.ExecutionContext;
import org.openarchitectureware.expression.ast.DeclaredParameter;
import org.openarchitectureware.expression.ast.ISyntaxElement;
import org.openarchitectureware.expression.ast.Identifier;
import org.openarchitectureware.type.ParameterizedCallable;
import org.openarchitectureware.type.Type;

public interface Extension extends ParameterizedCallable, ISyntaxElement {

	public List<DeclaredParameter> getFormalParameters();

	public String getName();

	public Type getReturnType(final Type[] parameters, ExecutionContext ctx,
			final Set<AnalysationIssue> issues);

	public void analyze(ExecutionContext ctx, final Set<AnalysationIssue> issues);

	public Object evaluate(final Object[] parameters, ExecutionContext ctx);

	public ExtensionFile getExtensionFile();

	public List<String> getParameterNames();

	public void init(final ExecutionContext ctx);

	public Type getReturnType();

	public List<Type> getParameterTypes();

	public Identifier getReturnTypeIdentifier();

	public String toString();

	public String toOutlineString();

	public boolean isPrivate();

	public boolean isCached();

	public void setExtensionFile(ExtensionFile file);

	public String getQualifiedName();

}