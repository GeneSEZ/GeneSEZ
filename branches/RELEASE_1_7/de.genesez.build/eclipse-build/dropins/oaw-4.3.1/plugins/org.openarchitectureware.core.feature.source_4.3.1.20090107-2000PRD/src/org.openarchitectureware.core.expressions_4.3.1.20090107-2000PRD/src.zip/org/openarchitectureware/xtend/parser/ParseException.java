package org.openarchitectureware.xtend.parser;

@SuppressWarnings("serial")
public class ParseException extends RuntimeException {
	public ParseException(OawError e) {
		super(e.toString());
	}
}
