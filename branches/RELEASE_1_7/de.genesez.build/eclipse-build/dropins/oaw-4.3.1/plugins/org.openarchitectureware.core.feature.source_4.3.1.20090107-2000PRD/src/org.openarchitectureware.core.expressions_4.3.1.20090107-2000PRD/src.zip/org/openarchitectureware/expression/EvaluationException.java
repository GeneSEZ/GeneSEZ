/*
 * <copyright>
 *
 * Copyright (c) 2005-2006 Sven Efftinge (http://www.efftinge.de) and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Sven Efftinge (http://www.efftinge.de) - Initial API and implementation
 *
 * </copyright>
 */
package org.openarchitectureware.expression;

import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;

import org.openarchitectureware.expression.ast.SyntaxElement;
import org.openarchitectureware.workflow.util.Pair;

/**
 * @author Sven Efftinge (http://www.efftinge.de)
 * @author Arno Haase
 */
public class EvaluationException extends RuntimeException {

	private static final long serialVersionUID = 3781834199930386623L;

	private List<Pair<SyntaxElement, ExecutionContext>> oawStackTrace = new Stack<Pair<SyntaxElement, ExecutionContext>>();

	public EvaluationException(final String msg, final SyntaxElement element,
			final ExecutionContext ctx) {
		super(msg);
		addStackElement(element, ctx);
	}

	public EvaluationException(final Throwable ex, final SyntaxElement element,
			final ExecutionContext ctx) {
		super((ex.getMessage() == null ? ex.getClass().getName() : ex
				.getMessage()), ex);
		addStackElement(element, ctx);
	}

	public void addStackElement(SyntaxElement ele, ExecutionContext ctx) {
		this.oawStackTrace.add(new Pair<SyntaxElement, ExecutionContext>(ele,
				ctx));
	}

	@Override
	public String toString() {
		StringBuffer result = new StringBuffer("EvaluationException : "
				+ getMessage() + "\n");
		for (Pair<SyntaxElement, ExecutionContext> ele : oawStackTrace) {
			result.append(getLocationString(ele.getFirst())).append("\n");
		}
		return result.toString();
	}

	public List<Pair<SyntaxElement, ExecutionContext>> getOawStackTrace() {
		return oawStackTrace;
	}

	static String getLocationString(SyntaxElement element) {
		StringBuffer b = new StringBuffer("\t");
		if (element != null) {
			if (element.getFileName() != null) {
				b.append(element.getFileName().replaceAll("/", "::"));
			}
			b.append("[" + element.getStart() + ","
					+ (element.getEnd() - element.getStart()) + "] on line "
					+ element.getLine() + " '" + element + "'");
		} else {
			b.append("Internal error : element was null");
		}
		return b.toString();
	}

	public final static java.util.regex.Pattern P = java.util.regex.Pattern
			.compile("([\\w::]+)\\.(\\w+)\\[(\\d+),(\\d+)\\]");

	public static String getOawNamespace(String oawId) {
		Matcher m = P.matcher(oawId);
		m.find();
		return m.group(1);
	}

	public static String getOawExtension(String oawId) {
		Matcher m = P.matcher(oawId);
		m.find();
		return m.group(2);
	}

	public static Integer getOffSet(String oawId) {
		Matcher m = P.matcher(oawId);
		m.find();
		return Integer.valueOf(m.group(3));
	}

	public static Integer getLength(String oawId) {
		Matcher m = P.matcher(oawId);
		m.find();
		return Integer.valueOf(m.group(4));
	}

}
