package forms;

/* 
 *	Do not place import/include statements above this comment, just below. 
 * 	@FILE-ID : (_17_0_6_7ac024e_1366642644597_179853_1989) 
 */

/**
 * Please describe the responsibility of your class in your modeling tool.
 */
public abstract class AbstractForm implements Form {
	
	protected Object theShape;
	
	/* PROTECTED REGION ID(java.class.own.code.implementation._17_0_6_7ac024e_1366642644597_179853_1989) ENABLED START */
	// TODO: put your own implementation code here
	/* PROTECTED REGION END */
}
