package game;

/* 
 *	Do not place import/include statements above this comment, just below. 
 * 	@FILE-ID : (_17_0_6_7ac024e_1365595984144_837258_1997) 
 */

/**
 * Please describe the responsibility of your class in your modeling tool.
 */
public class Starter {
	
	/**
	 * Method stub for further implementation.
	 */
	public static void main(String[] args) {
		/* PROTECTED REGION ID(java.implementation._17_0_6_7ac024e_1365597591056_438726_2073) ENABLED START */
		new Scene();
		/* PROTECTED REGION END */
	}
	
	/* PROTECTED REGION ID(java.class.own.code.implementation._17_0_6_7ac024e_1365595984144_837258_1997) ENABLED START */
	
	/* PROTECTED REGION END */
}
