<?php

/* PROTECTED REGION ID(php.own.imports._16_0_b6f02e1_1249464686421_483321_976) ENABLED START */
// TODO: put your further include + require statements here
/* PROTECTED REGION END */

/**
 * @author	nicher
 * @package	de.genesez.example.java.forms
 */
class Color   {
	
	
	
	
	

	
	
	
	// -- own code implementation -------------------------------------------
	/* PROTECTED REGION ID(php.class.own.code.implementation._16_0_b6f02e1_1249464686421_483321_976) ENABLED START */
	// TODO: put your further code implementations for class 'Color' here
	/* PROTECTED REGION END */
}
?>
